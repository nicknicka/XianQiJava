-- MySQL dump 10.13  Distrib 9.4.0, for macos15.4 (arm64)
--
-- Host: localhost    Database: XianQi
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `id` bigint NOT NULL COMMENT '管理员ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(100) NOT NULL COMMENT '密码(BCrypt加密)',
  `nickname` varchar(50) DEFAULT NULL COMMENT '昵称',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  `is_active` tinyint DEFAULT '1' COMMENT '是否启用 0-禁用 1-启用',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(50) DEFAULT NULL COMMENT '最后登录IP',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='管理员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','$2a$10$9JoT3WTIK1t96RWiIxDxuuRYcb85iow/Aa35X2NTVD7ii4uFqzVji','超级管理员',NULL,1,'2026-03-09 12:01:00','0:0:0:0:0:0:0:1','2026-03-07 22:47:06','2026-03-09 12:01:00');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_login_log`
--

DROP TABLE IF EXISTS `admin_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_login_log` (
  `id` bigint NOT NULL COMMENT '日志ID',
  `admin_id` bigint DEFAULT NULL COMMENT '管理员ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `login_time` datetime NOT NULL COMMENT '登录时间',
  `ip` varchar(50) DEFAULT NULL COMMENT 'IP地址',
  `location` varchar(100) DEFAULT NULL COMMENT 'IP归属地',
  `browser` varchar(100) DEFAULT NULL COMMENT '浏览器',
  `os` varchar(100) DEFAULT NULL COMMENT '操作系统',
  `status` tinyint DEFAULT '1' COMMENT '登录状态 0-失败 1-成功',
  `message` varchar(255) DEFAULT NULL COMMENT '提示信息',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_status` (`status`),
  KEY `idx_create_time` (`create_time`),
  KEY `idx_admin_time` (`admin_id`,`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='管理员登录日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_login_log`
--

LOCK TABLES `admin_login_log` WRITE;
/*!40000 ALTER TABLE `admin_login_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_session`
--

DROP TABLE IF EXISTS `admin_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_session` (
  `id` bigint NOT NULL COMMENT '会话ID',
  `admin_id` bigint NOT NULL COMMENT '管理员ID',
  `token` varchar(500) NOT NULL COMMENT 'JWT Token',
  `ip` varchar(50) DEFAULT NULL COMMENT 'IP地址',
  `user_agent` varchar(500) DEFAULT NULL COMMENT 'User-Agent',
  `login_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '登录时间',
  `last_active_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后活跃时间',
  `status` tinyint DEFAULT '1' COMMENT '状态：0-已退出 1-在线',
  PRIMARY KEY (`id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_token` (`token`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='管理员在线会话表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_session`
--

LOCK TABLES `admin_session` WRITE;
/*!40000 ALTER TABLE `admin_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ai_chat_history`
--

DROP TABLE IF EXISTS `ai_chat_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_chat_history` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `user_message` text COLLATE utf8mb4_unicode_ci COMMENT 'ç”¨æˆ·æ¶ˆæ¯',
  `ai_response` text COLLATE utf8mb4_unicode_ci COMMENT 'AIå›žå¤',
  `intent_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ„å›¾ç±»åž‹ï¼šCUSTOMER_SERVICE-å®¢æœå’¨è¯¢, RECOMMENDATION-å•†å“æŽ¨è, DESCRIPTION-æè¿°ä¼˜åŒ–, PRICING-å®šä»·å»ºè®®, SAFETY-å®‰å…¨å’¨è¯¢, GREETING-é—®å€™è¯­, GENERAL-ä¸€èˆ¬å’¨è¯¢',
  `agent_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Agentç±»åž‹ï¼šCustomerServiceAgent, ProductRecommendationAgent, ProductDescriptionAgent, PricingAdvisorAgent, TradeSafetyAgent',
  `session_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¼šè¯IDï¼ˆç”¨äºŽå¤šè½®å¯¹è¯ï¼‰',
  `model_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä½¿ç”¨çš„æ¨¡åž‹åç§°',
  `tokens_used` int DEFAULT '0' COMMENT 'æ¶ˆè€—çš„tokenæ•°é‡',
  `response_time_ms` int DEFAULT '0' COMMENT 'å“åº”æ—¶é—´ï¼ˆæ¯«ç§’ï¼‰',
  `created_at` datetime DEFAULT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `create_time` datetime DEFAULT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT NULL COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted` int DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤æ ‡è®°ï¼ˆ0=æœªåˆ é™¤ï¼Œ1=å·²åˆ é™¤ï¼‰',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='AIèŠå¤©åŽ†å²è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_chat_history`
--

LOCK TABLES `ai_chat_history` WRITE;
/*!40000 ALTER TABLE `ai_chat_history` DISABLE KEYS */;
INSERT INTO `ai_chat_history` VALUES (1,8,'手续费是多少？','很抱歉，您提供的信息不足以确定手续费的具体数额。手续费可能会根据不同的服务、平台、交易类型等因素而有所不同。为了给您提供准确的手续费信息，我需要以下信息：\n\n1. 您是在哪个平台或服务上交易？（例如：淘宝、闲鱼、支付宝等）\n2. 您交易的商品类型是什么？\n3. 手续费是基于交易金额的百分比还是固定金额？\n4. 是否有其他相关的费用或折扣？\n\n请您提供更多信息，以便我能够给出准确的答案。','PRICING','PricingAdvisorAgent',NULL,'glm-4-flash',0,0,'2026-03-23 17:49:20','2026-03-23 17:49:20','2026-03-23 17:49:20',1),(2,8,'test','抱歉，我没有理解你的问题。\n\n你可以尝试：\n- \"推荐一些手机\"（商品推荐）\n- \"帮我写个商品描述\"（描述优化）\n- \"这个卖多少钱合适\"（定价建议）\n- \"交易安全吗\"（安全咨询）\n- \"如何实名认证\"（客服问题）\n\n请用更具体的方式描述你的需求。\n','GENERAL','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 17:52:55','2026-03-23 17:52:55','2026-03-23 17:52:55',1),(3,8,'介绍下你自己','你好！我是闲齐的智能助手 🎓\n\n我可以帮助你：\n\n📦 **商品推荐**\n根据你的需求推荐合适的二手商品\n\n✍️ **描述优化**\n帮你写吸引人的商品描述\n\n💰 **定价建议**\n为你的商品提供合理的定价建议\n\n🔒 **安全咨询**\n交易安全建议和风险评估\n\n❓ **客服问题**\n解答平台使用相关问题\n\n请告诉我你需要什么帮助！\n','GREETING','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 17:53:28','2026-03-23 17:53:28','2026-03-23 17:53:28',1),(4,8,'介绍下你自己','你好！我是闲齐的智能助手 🎓\n\n我可以帮助你：\n\n📦 **商品推荐**\n根据你的需求推荐合适的二手商品\n\n✍️ **描述优化**\n帮你写吸引人的商品描述\n\n💰 **定价建议**\n为你的商品提供合理的定价建议\n\n🔒 **安全咨询**\n交易安全建议和风险评估\n\n❓ **客服问题**\n解答平台使用相关问题\n\n请告诉我你需要什么帮助！\n','GREETING','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 18:23:54','2026-03-23 18:23:54','2026-03-23 18:23:54',1),(5,8,'介绍下你自己','你好！我是闲齐的智能助手 🎓\n\n我可以帮助你：\n\n📦 **商品推荐**\n根据你的需求推荐合适的二手商品\n\n✍️ **描述优化**\n帮你写吸引人的商品描述\n\n💰 **定价建议**\n为你的商品提供合理的定价建议\n\n🔒 **安全咨询**\n交易安全建议和风险评估\n\n❓ **客服问题**\n解答平台使用相关问题\n\n请告诉我你需要什么帮助！\n','GREETING','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 18:36:20','2026-03-23 18:36:20','2026-03-23 18:36:20',1),(6,8,'介绍下你自己','抱歉，我没有理解你的问题。\n\n你可以尝试：\n- \"推荐一些手机\"（商品推荐）\n- \"帮我写个商品描述\"（描述优化）\n- \"这个卖多少钱合适\"（定价建议）\n- \"交易安全吗\"（安全咨询）\n- \"如何实名认证\"（客服问题）\n\n请用更具体的方式描述你的需求。\n','GENERAL','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 18:43:31','2026-03-23 18:43:31','2026-03-23 18:43:31',1),(7,8,'你好','你好！我是闲齐的智能助手 🎓\n\n我可以帮助你：\n\n📦 **商品推荐**\n根据你的需求推荐合适的二手商品\n\n✍️ **描述优化**\n帮你写吸引人的商品描述\n\n💰 **定价建议**\n为你的商品提供合理的定价建议\n\n🔒 **安全咨询**\n交易安全建议和风险评估\n\n❓ **客服问题**\n解答平台使用相关问题\n\n请告诉我你需要什么帮助！\n','GREETING','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 18:45:06','2026-03-23 18:45:06','2026-03-23 18:45:06',1),(8,8,'介绍下你自己','抱歉，我没有理解你的问题。\n\n你可以尝试：\n- \"推荐一些手机\"（商品推荐）\n- \"帮我写个商品描述\"（描述优化）\n- \"这个卖多少钱合适\"（定价建议）\n- \"交易安全吗\"（安全咨询）\n- \"如何实名认证\"（客服问题）\n\n请用更具体的方式描述你的需求。\n','GENERAL','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 18:47:56','2026-03-23 18:47:56','2026-03-23 18:47:56',1),(9,8,'介绍下你自己','抱歉，我没有理解你的问题。\n\n你可以尝试：\n- \"推荐一些手机\"（商品推荐）\n- \"帮我写个商品描述\"（描述优化）\n- \"这个卖多少钱合适\"（定价建议）\n- \"交易安全吗\"（安全咨询）\n- \"如何实名认证\"（客服问题）\n\n请用更具体的方式描述你的需求。\n','GENERAL','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 18:48:38','2026-03-23 18:48:38','2026-03-23 18:48:38',1),(10,8,'介绍下你自己','抱歉，我没有理解你的问题。\n\n你可以尝试：\n- \"推荐一些手机\"（商品推荐）\n- \"帮我写个商品描述\"（描述优化）\n- \"这个卖多少钱合适\"（定价建议）\n- \"交易安全吗\"（安全咨询）\n- \"如何实名认证\"（客服问题）\n\n请用更具体的方式描述你的需求。\n','GENERAL','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 18:48:54','2026-03-23 18:48:54','2026-03-23 18:48:54',1),(11,8,'介绍下你自己','你好！我是闲齐的智能助手 🎓\n\n我可以帮助你：\n\n📦 **商品推荐**\n根据你的需求推荐合适的二手商品\n\n✍️ **描述优化**\n帮你写吸引人的商品描述\n\n💰 **定价建议**\n为你的商品提供合理的定价建议\n\n🔒 **安全咨询**\n交易安全建议和风险评估\n\n❓ **客服问题**\n解答平台使用相关问题\n\n请告诉我你需要什么帮助！\n','GREETING','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 18:53:12','2026-03-23 18:53:12','2026-03-23 18:53:12',1),(12,8,'我有什么订单吗 ？','[当前用户ID: 8] 您好，请问您是想查询未完成的订单还是已完成的订单呢？或者您想查看所有订单的详细情况？我会根据您的需求帮您查询。','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-23 18:53:56','2026-03-23 18:53:56','2026-03-23 18:53:56',1),(13,8,'查询我的所有订单','[当前用户ID: 8] 好的，我将帮您查询所有订单的详细信息。请稍等片刻。(经过查询，您目前共有X个订单，包括未完成和已完成的订单。以下是您的订单列表：)\n\n1. 订单编号：XXX，商品名称：XXX，交易金额：XXX元，订单状态：XXX\n2. 订单编号：XXX，商品名称：XXX，交易金额：XXX元，订单状态：XXX\n...\n(X. 订单编号：XXX，商品名称：XXX，交易金额：XXX元，订单状态：XXX)\n\n如果您需要查看某个订单的详细信息，请告诉我订单编号，我会为您进一步查询。','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-23 18:54:28','2026-03-23 18:54:28','2026-03-23 18:54:28',1),(14,8,'介绍下你自己','你好！我是闲齐的智能助手 🎓\n\n我可以帮助你：\n\n📦 **商品推荐**\n根据你的需求推荐合适的二手商品\n\n✍️ **描述优化**\n帮你写吸引人的商品描述\n\n💰 **定价建议**\n为你的商品提供合理的定价建议\n\n🔒 **安全咨询**\n交易安全建议和风险评估\n\n❓ **客服问题**\n解答平台使用相关问题\n\n请告诉我你需要什么帮助！\n','GREETING','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 18:57:04','2026-03-23 18:57:04','2026-03-23 18:57:04',1),(15,8,'介绍下你自己','抱歉，我没有理解你的问题。\n\n你可以尝试：\n- \"推荐一些手机\"（商品推荐）\n- \"帮我写个商品描述\"（描述优化）\n- \"这个卖多少钱合适\"（定价建议）\n- \"交易安全吗\"（安全咨询）\n- \"如何实名认证\"（客服问题）\n\n请用更具体的方式描述你的需求。\n','GENERAL','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 18:59:25','2026-03-23 18:59:25','2026-03-23 18:59:25',1),(16,8,'介绍下你自己','抱歉，我没有理解你的问题。\n\n你可以尝试：\n- \"推荐一些手机\"（商品推荐）\n- \"帮我写个商品描述\"（描述优化）\n- \"这个卖多少钱合适\"（定价建议）\n- \"交易安全吗\"（安全咨询）\n- \"如何实名认证\"（客服问题）\n\n请用更具体的方式描述你的需求。\n','GENERAL','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 19:01:38','2026-03-23 19:01:38','2026-03-23 19:01:38',1),(17,8,'介绍下apple watch','抱歉，我没有理解你的问题。\n\n你可以尝试：\n- \"推荐一些手机\"（商品推荐）\n- \"帮我写个商品描述\"（描述优化）\n- \"这个卖多少钱合适\"（定价建议）\n- \"交易安全吗\"（安全咨询）\n- \"如何实名认证\"（客服问题）\n\n请用更具体的方式描述你的需求。\n','GENERAL','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 19:02:07','2026-03-23 19:02:07','2026-03-23 19:02:07',1),(18,8,'介绍下你自己','你好！我是闲齐的智能助手 🎓\n\n我可以帮助你：\n\n📦 **商品推荐**\n根据你的需求推荐合适的二手商品\n\n✍️ **描述优化**\n帮你写吸引人的商品描述\n\n💰 **定价建议**\n为你的商品提供合理的定价建议\n\n🔒 **安全咨询**\n交易安全建议和风险评估\n\n❓ **客服问题**\n解答平台使用相关问题\n\n请告诉我你需要什么帮助！\n','GREETING','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 19:04:02','2026-03-23 19:04:02','2026-03-23 19:04:02',1),(19,8,'手续费是多少？','很抱歉，您提供的信息不足以确定手续费的具体数额。手续费可能会根据不同的平台、服务类型、交易金额等因素而有所不同。为了给您提供准确的信息，请您提供以下详细信息：\n\n1. 您是在哪个平台或机构进行交易？\n2. 您的交易类型是什么（例如：购买商品、支付服务费等）？\n3. 交易金额是多少？\n\n有了这些信息，我才能为您计算出大致的手续费数额。','PRICING','PricingAdvisorAgent',NULL,'glm-4-flash',0,0,'2026-03-23 19:24:50','2026-03-23 19:24:50','2026-03-23 19:24:50',1),(20,8,'介绍下你自己','你好！我是闲齐的智能助手 🎓\n\n我可以帮助你：\n\n📦 **商品推荐**\n根据你的需求推荐合适的二手商品\n\n✍️ **描述优化**\n帮你写吸引人的商品描述\n\n💰 **定价建议**\n为你的商品提供合理的定价建议\n\n🔒 **安全咨询**\n交易安全建议和风险评估\n\n❓ **客服问题**\n解答平台使用相关问题\n\n请告诉我你需要什么帮助！\n','GREETING','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 19:25:13','2026-03-23 19:25:13','2026-03-23 19:25:13',1),(21,8,'手续费是多少？','很抱歉，您提供的信息不足以确定手续费的具体数额。手续费可能会根据不同的平台、服务类型、交易金额以及地区等因素而有所不同。为了给您提供准确的手续费信息，请您提供以下详细信息：\n\n1. 您是在哪个平台或机构进行交易？\n2. 您的交易类型是什么（如：购买商品、支付服务费等）？\n3. 交易金额是多少？\n4. 是否有特定的手续费结构或费率？\n\n有了这些信息，我才能为您计算出大致的手续费数额。','PRICING','PricingAdvisorAgent',NULL,'glm-4-flash',0,0,'2026-03-23 21:27:24','2026-03-23 21:27:24','2026-03-23 21:27:24',1),(22,8,'可以共享物品吗？','当然可以！如果您有闲置物品想要共享或者出售，可以详细描述一下商品的种类、品牌、型号、成色、使用情况、转手原因以及您期望的交易方式。我会根据您提供的信息，按照我们的商品描述模板帮您撰写一份吸引人的商品文案。请告诉我您的具体需求吧！','DESCRIPTION','ProductDescriptionAgent',NULL,'glm-4-flash',0,0,'2026-03-23 21:36:19','2026-03-23 21:36:19','2026-03-23 21:36:19',1),(23,8,'介绍下你自己','你好！我是闲齐的智能助手 🎓\n\n我可以帮助你：\n\n📦 **商品推荐**\n根据你的需求推荐合适的二手商品\n\n✍️ **描述优化**\n帮你写吸引人的商品描述\n\n💰 **定价建议**\n为你的商品提供合理的定价建议\n\n🔒 **安全咨询**\n交易安全建议和风险评估\n\n❓ **客服问题**\n解答平台使用相关问题\n\n请告诉我你需要什么帮助！\n','GREETING','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-23 21:37:48','2026-03-23 21:37:48','2026-03-23 21:37:48',1),(24,8,'apple 均价','【商品估值】\n- 商品名称：Apple 均价\n- 原价：因型号和购买时间而异，无法给出具体原价\n- 成色：未指定具体成色，以下分析将基于市场平均成色\n\n【市场价格分析】\n- 同类商品价格区间：根据型号和成色，价格区间在¥2000 - ¥10000之间\n- 推荐售价：因未指定具体型号和成色，以下推荐售价将基于市场平均情况\n\n【定价理由】\n1. 品牌影响：Apple 作为知名品牌，保值率相对较高\n2. 需求热度：Apple 产品通常市场需求旺盛\n3. 成色折旧：根据商品成色，价格会有所不同\n\n【定价建议】\n- 建议价格：以市场平均成色为例，建议售价在¥3000 - ¥8000之间\n- 可接受议价空间：根据买家议价能力和市场情况，可接受议价空间约为售价的5-10%\n- 快速出售价：如需快速售出，建议将价格降低至市场平均售价的90%\n\n【注意事项】\n- 具体型号和成色对价格影响较大，建议根据实际情况调整价格\n- 电子产品需说明是否过保，过保产品可能会影响售价\n- 大件商品考虑运费成本，这可能影响最终售价','PRICING','PricingAdvisorAgent',NULL,'glm-4-flash',0,0,'2026-03-23 21:38:16','2026-03-23 21:38:16','2026-03-23 21:38:16',1),(25,8,'如何发布商品？','[当前用户ID: 8] 您好，很高兴为您解答如何发布商品的问题。以下是发布商品的步骤：\n\n1. **登录平台**：首先，请确保您已经登录到“闲齐”校园二手交易平台。\n\n2. **进入发布页面**：在首页找到“发布商品”按钮，点击进入。\n\n3. **选择商品类别**：根据您的商品类型，选择相应的类别。\n\n4. **填写商品信息**：包括商品名称、描述、价格、新旧程度等详细信息。\n\n5. **上传图片**：至少上传一张清晰的商品图片，以便买家更好地了解商品。\n\n6. **设置交易方式**：选择自取或配送，并设置配送费用（如有）。\n\n7. **确认信息**：仔细检查您填写的所有信息，确保无误。\n\n8. **提交发布**：确认无误后，点击“提交发布”按钮。\n\n9. **等待审核**：您的商品信息将提交给平台审核，审核通过后即可在平台上展示。\n\n请注意，为了保障交易安全，平台会对发布的商品信息进行审核。希望这些信息对您有所帮助！如有其他问题，请随时咨询。','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-23 21:45:34','2026-03-23 21:45:34','2026-03-23 21:45:34',1),(26,8,'如何联系卖家？','[当前用户ID: 8] 您好，想要联系卖家，可以按照以下步骤操作：\n\n1. **查看商品详情**：首先，找到您想要联系的商品，点击进入商品详情页面。\n\n2. **查找联系方式**：在商品详情页面，通常会有卖家的联系方式展示，如手机号码、QQ、微信等。\n\n3. **直接联系**：通过您选择的联系方式直接与卖家沟通。请注意保护个人隐私，不要随意透露您的敏感信息。\n\n4. **平台内私信**：如果您在商品详情中没有找到联系方式，可以尝试使用平台内的私信功能。在商品详情页，通常会有一个“私信卖家”的按钮，点击后可以发送消息给卖家。\n\n5. **保持沟通**：在沟通时，请清晰地说明您的购买意向和任何疑问，以便卖家及时回复。\n\n6. **交易安全提示**：在交易过程中，请确保双方都是通过平台沟通，避免私下交易，以确保交易安全。\n\n如果您在联系卖家过程中遇到任何问题，也可以联系我们的客服团队寻求帮助。希望这能帮到您！','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-23 21:52:13','2026-03-23 21:52:13','2026-03-23 21:52:13',1),(27,8,'如何举报违规？','[当前用户ID: 8] 您好，如果您在“闲齐”校园二手交易平台上遇到违规行为，可以通过以下步骤进行举报：\n\n1. **找到违规商品或用户**：首先，找到您想要举报的商品或用户。\n\n2. **进入举报页面**：\n   - 对于商品违规，可以在商品详情页找到举报按钮，通常是“举报”或类似字样的图标。\n   - 对于用户违规，您可以在用户资料页或相关交易页面找到举报选项。\n\n3. **选择举报原因**：在举报页面，选择合适的举报原因，如虚假信息、诈骗、商品质量不符等。\n\n4. **填写举报信息**：根据要求填写举报信息，包括具体描述违规情况、上传相关证据（如聊天记录、交易记录截图等）。\n\n5. **提交举报**：仔细检查填写的信息和上传的证据，确认无误后提交举报。\n\n6. **等待处理**：提交举报后，平台工作人员会对举报内容进行审核和处理。请耐心等待平台的通知。\n\n7. **保护隐私**：在举报过程中，请确保不泄露您的个人信息，以免遭受不必要的麻烦。\n\n如果您在举报过程中遇到困难或需要帮助，可以联系平台的客服团队。平台会对违规行为进行严肃处理，以维护良好的交易环境。希望这些信息对您有所帮助！','SAFETY','TradeSafetyAgent',NULL,'glm-4-flash',0,0,'2026-03-23 21:56:45','2026-03-23 21:56:45','2026-03-23 21:56:45',1),(28,8,'如何发布商品？','[当前用户ID: 8] 您好，发布商品的具体步骤如下：\n\n1. **登录平台**：首先，请确保您已经登录到“闲齐”校园二手交易平台。\n\n2. **进入发布页面**：在首页找到“发布商品”按钮，点击进入。\n\n3. **选择商品类别**：根据您的商品类型，选择相应的类别。\n\n4. **填写商品信息**：\n   - 商品名称：简洁明了地描述商品。\n   - 商品描述：详细描述商品的特点、使用情况等。\n   - 商品价格：设定合理的价格。\n   - 新旧程度：选择商品的新旧程度。\n   - 商品图片：至少上传一张清晰的商品图片。\n\n5. **设置交易方式**：选择自取或配送，并设置配送费用（如有）。\n\n6. **填写联系方式**：提供有效的联系方式，如手机号码、微信等，以便买家联系。\n\n7. **确认信息**：仔细检查您填写的所有信息，确保无误。\n\n8. **提交发布**：确认无误后，点击“提交发布”按钮。\n\n9. **等待审核**：您的商品信息将提交给平台审核，审核通过后即可在平台上展示。\n\n请确保发布的信息真实、准确，以便吸引潜在买家。如果您在发布过程中遇到任何问题，可以随时联系平台的客服团队。希望这些步骤对您有所帮助！','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-23 22:29:21','2026-03-23 22:29:21','2026-03-23 22:29:21',1),(29,8,'如何联系卖家？','[当前用户ID: 8] 您好，联系卖家的方法如下：\n\n1. **通过商品详情页**：\n   - 进入您想要购买的商品详情页。\n   - 在页面底部通常会有一个“联系卖家”的选项或者直接显示卖家的联系方式（如电话、微信、QQ等）。\n\n2. **使用平台私信功能**：\n   - 如果商品详情页中没有直接显示联系方式，您可以点击“私信卖家”按钮。\n   - 在私信界面中，您可以输入想要询问的内容并发送消息。\n\n3. **平台内留言板**：\n   - 一些平台可能提供留言板功能，您可以在留言板上给卖家留言。\n\n4. **注意事项**：\n   - 在联系卖家时，请保持礼貌，清晰地表达您的意图和疑问。\n   - 不要在私信中透露过多的个人信息，如身份证号、银行卡号等。\n   - 如果交易涉及敏感信息，建议通过平台内的交易系统进行沟通，以保障交易安全。\n\n如果您在尝试联系卖家时遇到困难，可以联系平台的客服团队寻求帮助。客服人员会尽力协助您与卖家取得联系。希望这些建议对您有所帮助！','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-23 22:33:02','2026-03-23 22:33:02','2026-03-23 22:33:02',1),(30,8,'如何发布商品？','[当前用户ID: 8] 您好！在“闲齐”校园二手交易平台发布商品，您可以按照以下步骤操作：\n\n1. **登录平台**：首先，请确保您已经登录到“闲齐”平台。\n2. **点击发布商品**：在首页或个人中心，找到“发布商品”按钮并点击。\n3. **选择商品类别**：根据您的商品选择合适的类别。\n4. **填写商品信息**：包括商品标题、描述、价格、新旧程度等。\n5. **上传图片**：至少上传一张清晰的商品图片。\n6. **设置交易方式**：选择自取或配送，并填写相关配送信息（如适用）。\n7. **确认信息**：仔细检查您填写的所有信息，确保无误。\n8. **提交发布**：点击“提交发布”按钮，等待平台审核。\n\n请注意，为了确保交易安全，发布商品时请提供真实、准确的信息。如果需要更多帮助，可以随时联系我们的客服团队。祝您发布成功！','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-24 10:04:49','2026-03-24 10:04:49','2026-03-24 10:04:49',1),(31,8,'如何发布商品？','[当前用户ID: {userId}] 您好！发布商品非常简单，以下是具体步骤：\n\n1. **登录平台**：首先，请确保您已经登录到“闲七”校园二手交易平台。\n\n2. **进入发布页面**：在首页点击“发布商品”按钮，进入商品发布页面。\n\n3. **选择商品类别**：根据您的商品选择合适的类别，例如书籍、电子产品、生活用品等。\n\n4. **填写商品信息**：在发布页面，您需要填写商品的具体信息，包括商品名称、描述、价格、新旧程度等。\n\n5. **上传图片**：为了更好地展示商品，建议您上传至少一张清晰的图片。\n\n6. **设置交易方式**：选择商品的交易方式，如面对面交易、快递交易等。\n\n7. **确认信息**：仔细检查您填写的所有信息，确保无误。\n\n8. **提交发布**：确认无误后，点击“提交发布”按钮，您的商品就会出现在平台上供其他用户浏览。\n\n请注意，发布商品时请确保信息的真实性和准确性，以便吸引潜在买家。如果您在发布过程中遇到任何问题，可以随时联系我们的客服团队。祝您发布成功！','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-24 18:50:49','2026-03-24 18:50:49','2026-03-24 18:50:49',1),(32,8,'介绍下你自己','你好！我是闲七的智能助手 🎓\n\n我可以帮助你：\n\n📦 **商品推荐**\n根据你的需求推荐合适的二手商品\n\n✍️ **描述优化**\n帮你写吸引人的商品描述\n\n💰 **定价建议**\n为你的商品提供合理的定价建议\n\n🔒 **安全咨询**\n交易安全建议和风险评估\n\n❓ **客服问题**\n解答平台使用相关问题\n\n请告诉我你需要什么帮助！\n','GREETING','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-31 14:18:34','2026-03-31 14:18:34','2026-03-31 14:18:34',1),(33,8,'介绍下你自己','你好！我是闲七的智能助手 🎓\n\n我可以帮助你：\n\n📦 **商品推荐**\n根据你的需求推荐合适的二手商品\n\n✍️ **描述优化**\n帮你写吸引人的商品描述\n\n💰 **定价建议**\n为你的商品提供合理的定价建议\n\n🔒 **安全咨询**\n交易安全建议和风险评估\n\n❓ **客服问题**\n解答平台使用相关问题\n\n请告诉我你需要什么帮助！\n','GREETING','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-31 14:18:42','2026-03-31 14:18:42','2026-03-31 14:18:42',1),(34,8,'如何联系卖家？','[当前用户ID: {userId}] \n\n您好！联系卖家有几种方式：\n\n1. **平台内私信**：在商品详情页，通常会有一个私信卖家的按钮，您可以直接发送消息给卖家。\n\n2. **商品留言**：在商品详情页下方，您可以留下留言，卖家看到后会尽快回复您。\n\n3. **电话联系**：如果商品信息中提供了卖家的电话号码，您可以直接拨打电话联系卖家。\n\n为了保障您的交易安全，建议在联系卖家时，尽量通过平台内的沟通工具进行，这样可以更好地保护您的个人信息。同时，请勿随意透露您的银行账号、密码等敏感信息。如果您在联系卖家过程中遇到任何问题，也可以随时联系我们的客服帮助解决。','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-31 14:18:51','2026-03-31 14:18:51','2026-03-31 14:18:51',1),(35,8,'交易安全吗？','[当前用户ID: {userId}] \n\n在回答您的问题之前，我需要了解一些关于您即将进行的交易的具体信息，比如卖家的ID、交易金额、商品类型等。请您提供这些信息，我才能帮您进行交易安全的评估。','SAFETY','TradeSafetyAgent',NULL,'glm-4-flash',0,0,'2026-03-31 14:19:00','2026-03-31 14:19:00','2026-03-31 14:19:00',1),(36,8,'如何发布商品？','[当前用户ID: {userId}] \n\n发布商品在“闲七”校园二手交易平台非常简单，以下是具体的步骤：\n\n1. **注册并登录**：首先，确保您已经注册并登录到平台。\n\n2. **选择商品类别**：进入个人中心后，找到“发布商品”选项，选择您想要发布的商品类别。\n\n3. **填写商品信息**：根据要求填写商品的基本信息，包括商品名称、描述、品牌、型号、新旧程度等。\n\n4. **上传图片**：上传清晰、多角度的商品图片，至少3张，以便买家更好地了解商品。\n\n5. **设置价格和交易方式**：设定商品的价格，并选择交易方式，如面交、快递等。\n\n6. **选择交易地点**：如果选择面交，请选择合适的交易地点。\n\n7. **提交审核**：填写完所有信息并确认无误后，提交商品信息等待平台审核。\n\n8. **审核通过**：审核通过后，您的商品就会出现在平台上，供其他用户浏览和购买。\n\n请注意，发布商品时请确保信息的真实性，避免虚假信息影响交易。另外，为了保障交易安全，建议在平台内完成交易，避免私下交易可能带来的风险。如果您在发布过程中遇到任何问题，可以随时联系我们的客服获取帮助。','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-31 14:19:21','2026-03-31 14:19:21','2026-03-31 14:19:21',1),(37,8,'如何发布商品？','发布商品在“闲七”校园二手交易平台非常简单，以下是具体的步骤：\n\n1. **登录账号**：首先，您需要登录到您的“闲七”账号。\n\n2. **进入发布页面**：登录后，在首页找到“发布商品”的按钮，点击进入。\n\n3. **选择商品类别**：根据您的商品类型，选择合适的分类。\n\n4. **填写商品信息**：\n   - 商品名称：简洁明了地描述您的商品。\n   - 商品描述：详细描述商品的新旧程度、功能、使用情况等。\n   - 商品价格：根据市场行情和商品状况设定合理的价格。\n   - 商品图片：上传至少一张清晰的照片，以便买家更好地了解商品。\n\n5. **设置交易方式**：选择商品交易的方式，如面对面交易或邮寄。\n\n6. **确认信息**：仔细检查您填写的所有信息，确保无误。\n\n7. **提交发布**：确认无误后，点击“发布”按钮，您的商品就会出现在平台上供买家浏览。\n\n发布商品时，请注意以下几点：\n- 确保商品信息的真实性，避免虚假信息。\n- 上传清晰的照片，以便买家更好地了解商品。\n- 根据商品的实际状况定价，避免价格过高或过低。\n\n如果您在发布过程中遇到任何问题，可以随时联系我们的客服团队获取帮助。','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-31 16:52:26','2026-03-31 16:52:26','2026-03-31 16:52:26',1),(38,8,'介绍下你自己','你好！我是闲七的智能助手 🎓\n\n我可以帮助你：\n\n📦 **商品推荐**\n根据你的需求推荐合适的二手商品\n\n✍️ **描述优化**\n帮你写吸引人的商品描述\n\n💰 **定价建议**\n为你的商品提供合理的定价建议\n\n🔒 **安全咨询**\n交易安全建议和风险评估\n\n❓ **客服问题**\n解答平台使用相关问题\n\n请告诉我你需要什么帮助！\n','GREETING','UnknownAgent',NULL,'glm-4-flash',0,0,'2026-03-31 16:54:43','2026-03-31 16:54:43','2026-03-31 16:54:43',1),(39,8,'可以帮我查一下我有什么订单吗','当然可以，为了帮您查询订单信息，请您提供一下您的用户名或者订单号。这样我就能准确地为您查询到相关的订单信息。如果您不确定订单号，提供用户名也可以。','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-31 16:55:00','2026-03-31 16:55:00','2026-03-31 16:55:00',1),(40,8,'如何发布商品？','发布商品在“闲七”校园二手交易平台非常简单，以下是具体的步骤：\n\n1. **登录账号**：首先，请确保您已经登录了您的“闲七”账号。\n\n2. **进入发布页面**：在首页，通常会有一个“发布商品”或者“出售闲置”的按钮，点击进入。\n\n3. **选择商品类别**：根据您的商品类型，选择合适的分类。比如书籍、电子产品、衣物等。\n\n4. **填写商品信息**：\n   - **商品名称**：简洁明了地描述您的商品。\n   - **商品描述**：详细描述商品的新旧程度、功能、使用情况等。\n   - **商品价格**：根据市场行情和商品状况设定合理的价格。\n   - **商品图片**：至少上传一张清晰的照片，如果有多个角度或者商品细节，可以多上传几张。\n\n5. **设置交易方式**：选择是希望面对面交易还是通过平台配送。\n\n6. **填写联系方式**：提供有效的联系方式，如手机号码或微信号，以便买家联系您。\n\n7. **确认信息**：仔细检查您填写的所有信息，确保无误。\n\n8. **提交发布**：确认所有信息无误后，点击“发布”按钮。您的商品就会出现在平台上供买家浏览。\n\n在发布商品时，请注意以下几点：\n- 确保商品信息的真实性和准确性，避免虚假宣传。\n- 上传清晰、无遮挡的图片，以便买家更好地了解商品。\n- 设置合理的价格，避免过高或过低。\n- 保护个人隐私，不要在公开信息中透露敏感联系方式。\n\n如果您在发布商品的过程中遇到任何问题，欢迎随时联系我们的客服团队寻求帮助。','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-31 16:55:26','2026-03-31 16:55:26','2026-03-31 16:55:26',1),(41,8,'我的用户id是8，请你帮我查询一下我的订单信息','很抱歉，目前我无法直接查询您的订单信息，因为我的权限限制了我访问用户订单数据的范围。不过，您可以按照以下步骤自行查询订单信息：\n\n1. **登录平台**：请使用您的用户名和密码登录到“闲七”校园二手交易平台。\n\n2. **进入个人中心**：登录后，在页面的顶部或侧边栏通常会有“个人中心”或“我的订单”这样的选项，点击进入。\n\n3. **查看订单**：在个人中心页面，您应该能看到一个订单列表。这里会显示您的所有订单，包括已完成的、进行中的和已取消的订单。\n\n4. **详细查看**：点击某个订单，可以查看订单的详细信息，如商品详情、交易状态、交易金额等。\n\n如果您在查询订单时遇到任何问题，或者订单信息显示不正确，建议您联系我们的客服团队，他们将能够帮助您解决这些问题。您可以通过平台内的客服联系功能，或者使用平台提供的联系方式进行联系。','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-31 16:55:44','2026-03-31 16:55:44','2026-03-31 16:55:44',1),(42,8,'如何联系卖家？','您好！在“闲七”校园二手交易平台上联系卖家有以下几种方式：\n\n1. **商品详情页联系**：在商品详情页，通常会有卖家的联系方式，如电话、微信等。您可以直接通过这些方式联系卖家。\n\n2. **平台内私信**：如果您在商品详情页没有找到联系方式，可以在商品页面下方找到“联系卖家”的选项，点击后可以通过平台私信功能与卖家沟通。\n\n3. **订单页面联系**：如果您已经下单，可以在订单页面找到卖家的联系方式，通过订单页面提供的联系方式与卖家联系。\n\n在联系卖家时，请注意以下几点：\n- 保护个人隐私，不要随意透露您的敏感信息。\n- 保持礼貌，清晰表达您的需求或疑问。\n- 注意交易安全，建议在平台内完成交易，避免私下交易。\n\n如果您需要更详细的帮助，可以告诉我具体的问题，我会尽力为您解答。','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-31 19:45:57','2026-03-31 19:45:57','2026-03-31 19:45:57',1),(43,8,'如何联系卖家？','很抱歉，目前我无法提供关于如何联系卖家的具体帮助信息。您可以在平台的帮助中心搜索相关内容，或者尝试使用以下关键词：注册认证、商品发布、交易流程、支付收款、安全防骗，这些可能会找到您需要的信息。\n\n如果您还是无法找到答案，建议您联系我们的客服团队，他们会尽快为您提供帮助。您可以通过平台内的客服入口或者联系平台的官方联系方式来获取帮助。感谢您的理解与支持！','CUSTOMER_SERVICE','CustomerServiceAgent',NULL,'glm-4-flash',0,0,'2026-03-31 21:06:16','2026-03-31 21:06:16','2026-03-31 21:06:16',0);
/*!40000 ALTER TABLE `ai_chat_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banner`
--

DROP TABLE IF EXISTS `banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `banner` (
  `banner_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '轮播图ID',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '轮播图标题',
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图片URL',
  `image_thumbnail_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '缩略图URL',
  `link_type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '链接类型：1-无 2-外链 3-商品详情 4-功能页面',
  `link_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '跳转URL（外链时使用）',
  `link_product_id` bigint unsigned DEFAULT NULL COMMENT '关联商品ID（link_type=3时使用）',
  `link_page_path` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '功能页面路径（link_type=4时使用）',
  `sort_order` int unsigned NOT NULL DEFAULT '0' COMMENT '排序，数字越小越靠前',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '状态：0-禁用 1-启用',
  `start_time` datetime DEFAULT NULL COMMENT '开始展示时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束展示时间',
  `click_count` int unsigned NOT NULL DEFAULT '0' COMMENT '点击次数',
  `exposure_count` int unsigned NOT NULL DEFAULT '0' COMMENT '曝光次数',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`banner_id`),
  KEY `idx_status` (`status`),
  KEY `idx_sort_order` (`sort_order`),
  KEY `idx_start_end_time` (`start_time`,`end_time`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='轮播图表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banner`
--

LOCK TABLES `banner` WRITE;
/*!40000 ALTER TABLE `banner` DISABLE KEYS */;
INSERT INTO `banner` VALUES (1,'新用户注册送积分','http://localhost:8080/api/image/565d4a0d-7004-4716-bec7-419894f7c74c.png','http://localhost:8080/api/image/565d4a0d-7004-4716-bec7-419894f7c74c.png',2,'https://www.baidu.com',NULL,NULL,1,1,'2026-03-19 00:00:00','2026-03-27 00:00:00',45,1270,'2025-01-01 08:00:00','2026-03-24 10:07:04',0),(2,'限时秒杀活动','/static/images/banner2.png',NULL,3,NULL,NULL,NULL,2,1,NULL,NULL,89,1500,'2025-01-05 09:00:00','2026-03-04 16:54:33',0),(3,'优质商品推荐','/static/images/banner3.png',NULL,2,NULL,9,NULL,3,1,NULL,NULL,67,980,'2025-01-10 10:00:00','2026-03-04 16:54:33',0);
/*!40000 ALTER TABLE `banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blacklist`
--

DROP TABLE IF EXISTS `blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blacklist` (
  `blacklist_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '黑名单ID',
  `user_id` bigint unsigned NOT NULL COMMENT '用户ID',
  `blocked_user_id` bigint unsigned NOT NULL COMMENT '被拉黑的用户ID',
  `reason` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '拉黑原因',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`blacklist_id`),
  UNIQUE KEY `idx_user_blocked` (`user_id`,`blocked_user_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `fk_blacklist_blocked_user` (`blocked_user_id`),
  CONSTRAINT `fk_blacklist_blocked_user` FOREIGN KEY (`blocked_user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_blacklist_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='黑名单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blacklist`
--

LOCK TABLES `blacklist` WRITE;
/*!40000 ALTER TABLE `blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campus_location`
--

DROP TABLE IF EXISTS `campus_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campus_location` (
  `location_id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä½ç½®ID',
  `name` varchar(50) NOT NULL COMMENT 'ä½ç½®åç§°',
  `code` varchar(50) NOT NULL COMMENT 'ä½ç½®ä»£ç ',
  `description` varchar(200) DEFAULT NULL COMMENT 'ä½ç½®æè¿°',
  `sort_order` int DEFAULT '0' COMMENT 'æŽ’åº',
  `status` tinyint DEFAULT '1' COMMENT 'çŠ¶æ€ï¼š0-ç¦ç”¨ï¼Œ1-å¯ç”¨',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted` tinyint DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤æ ‡è®°ï¼ˆ0=æœªåˆ é™¤ï¼Œ1=å·²åˆ é™¤ï¼‰',
  PRIMARY KEY (`location_id`),
  UNIQUE KEY `uk_code` (`code`),
  KEY `idx_status` (`status`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æ ¡å›­ä½ç½®è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campus_location`
--

LOCK TABLES `campus_location` WRITE;
/*!40000 ALTER TABLE `campus_location` DISABLE KEYS */;
INSERT INTO `campus_location` VALUES (1,'全校','all','全校所有区域',0,1,'2026-03-02 20:57:11','2026-03-02 21:40:47',0),(2,'南区','south','校园南区',1,1,'2026-03-02 20:57:11','2026-03-02 21:40:47',0),(3,'北区','north','校园北区',2,1,'2026-03-02 20:57:11','2026-03-02 21:40:47',0),(4,'东区','east','校园东区',3,1,'2026-03-02 20:57:11','2026-03-02 21:40:47',0),(5,'西区','west','校园西区',4,1,'2026-03-02 20:57:11','2026-03-02 21:40:47',0);
/*!40000 ALTER TABLE `campus_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `category_id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分类名称',
  `code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'åˆ†ç±»ä»£ç ï¼ˆå¦‚ï¼šdigital, booksç­‰ï¼‰',
  `parent_id` int unsigned NOT NULL DEFAULT '0' COMMENT '父分类ID，0表示顶级分类',
  `icon` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分类图标',
  `gradient` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ¸å˜è‰²èƒŒæ™¯CSS',
  `sort_order` int unsigned NOT NULL DEFAULT '0' COMMENT '排序，数字越小越靠前',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '状态：0-禁用 1-启用',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `idx_code` (`code`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'数码电子','other',0,'digital','linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',1,1,'2026-03-02 21:34:32','2026-03-09 14:35:19',0),(2,'书籍教材',NULL,0,'book',NULL,2,1,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(3,'生活用品',NULL,0,'life',NULL,3,1,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(4,'运动装备',NULL,0,'sports',NULL,4,1,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(5,'服饰鞋包',NULL,0,'fashion',NULL,5,1,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(6,'美妆护肤',NULL,0,'beauty',NULL,6,1,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(7,'娱乐影音',NULL,0,'entertainment',NULL,7,1,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(8,'其他',NULL,0,'other',NULL,99,1,'2026-03-02 21:34:32','2026-03-02 21:34:32',0);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation`
--

DROP TABLE IF EXISTS `conversation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversation` (
  `conversation_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '会话ID',
  `conversation_type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '会话类型：1-单聊 2-群聊',
  `user_id_1` bigint unsigned NOT NULL COMMENT '用户1ID（单聊时使用）',
  `user_id_2` bigint unsigned DEFAULT NULL COMMENT '用户2ID（单聊时使用）',
  `related_order_id` bigint unsigned DEFAULT NULL COMMENT '关联订单ID',
  `related_product_id` bigint unsigned DEFAULT NULL,
  `last_message_id` bigint unsigned DEFAULT NULL COMMENT '最后一条消息ID',
  `last_message_content` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_message_type` tinyint unsigned DEFAULT NULL COMMENT 'æœ€åŽä¸€æ¡æ¶ˆæ¯ç±»åž‹ï¼š1-æ–‡æœ¬ï¼Œ2-å›¾ç‰‡ï¼Œ3-å•†å“å¡ç‰‡ï¼Œ4-è®¢å•å¡ç‰‡ï¼Œ5-ç³»ç»Ÿé€šçŸ¥ï¼Œ6-å¼•ç”¨æ¶ˆæ¯',
  `last_message_time` datetime DEFAULT NULL COMMENT '最后消息时间',
  `unread_count_user1` int unsigned NOT NULL DEFAULT '0' COMMENT '用户1的未读消息数',
  `unread_count_user2` int unsigned NOT NULL DEFAULT '0' COMMENT '用户2的未读消息数',
  `is_muted_user1` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '用户1是否免打扰：0-否 1-是',
  `is_muted_user2` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '用户2是否免打扰：0-否 1-是',
  `remark_user1` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户1对会话的备注名',
  `remark_user2` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户2对会话的备注名',
  `is_archived_user1` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '用户1是否归档：0-否 1-是',
  `is_archived_user2` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '用户2是否归档：0-否 1-是',
  `is_pinned_user1` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'ç”¨æˆ·1æ˜¯å¦ç½®é¡¶ï¼š0-å¦ 1-æ˜¯',
  `is_pinned_user2` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'ç”¨æˆ·2æ˜¯å¦ç½®é¡¶ï¼š0-å¦ 1-æ˜¯',
  `pin_order_user1` int unsigned DEFAULT NULL COMMENT 'ç”¨æˆ·1çš„ç½®é¡¶æŽ’åºï¼ˆæ•°å€¼è¶Šå°è¶Šé å‰ï¼‰',
  `pin_order_user2` int unsigned DEFAULT NULL COMMENT 'ç”¨æˆ·2çš„ç½®é¡¶æŽ’åºï¼ˆæ•°å€¼è¶Šå°è¶Šé å‰ï¼‰',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-æ­£å¸¸ï¼Œ1-å·²åˆ é™¤',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`conversation_id`),
  KEY `idx_user_id_1` (`user_id_1`),
  KEY `idx_user_id_2` (`user_id_2`),
  KEY `idx_last_message_time` (`last_message_time`),
  KEY `idx_related_order_id` (`related_order_id`),
  KEY `idx_pinned_user1` (`is_pinned_user1`,`pin_order_user1`),
  KEY `idx_pinned_user2` (`is_pinned_user2`,`pin_order_user2`),
  KEY `idx_related_product_id` (`related_product_id`),
  KEY `idx_last_message_type` (`last_message_type`),
  CONSTRAINT `fk_conversation_order` FOREIGN KEY (`related_order_id`) REFERENCES `order` (`order_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_conversation_user1` FOREIGN KEY (`user_id_1`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_conversation_user2` FOREIGN KEY (`user_id_2`) REFERENCES `user` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=289764955505432336 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会话表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation`
--

LOCK TABLES `conversation` WRITE;
/*!40000 ALTER TABLE `conversation` DISABLE KEYS */;
INSERT INTO `conversation` VALUES (1,1,1,2,1,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2025-01-20 16:00:00',0,2,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2025-01-20 10:00:00','2026-03-06 18:38:17',0),(2,1,1,3,2,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2025-01-19 15:00:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2025-01-19 14:00:00','2026-03-06 18:38:17',0),(3,1,2,4,4,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2025-01-17 12:00:00',1,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2025-01-17 11:00:00','2026-03-06 18:38:17',0),(10,1,1,18,NULL,NULL,109,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-06 09:30:00',0,1,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-05 10:00:00','2026-03-06 18:38:17',0),(11,1,1,19,NULL,NULL,112,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-06 08:15:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-05 11:00:00','2026-03-06 18:38:17',0),(12,1,1,20,NULL,NULL,118,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 20:45:00',2,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 14:00:00','2026-03-06 18:38:17',0),(13,1,1,21,NULL,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 19:20:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 15:00:00','2026-03-06 18:38:17',0),(14,1,1,22,NULL,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-04 16:30:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-03 10:30:00','2026-03-06 18:38:17',0),(15,1,2,23,NULL,NULL,124,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-06 07:50:00',1,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 12:00:00','2026-03-06 18:38:17',0),(16,1,2,24,NULL,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 18:00:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 13:30:00','2026-03-06 18:38:17',0),(17,1,2,25,NULL,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 15:40:00',0,1,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 14:20:00','2026-03-06 18:38:17',0),(18,1,2,26,NULL,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-04 17:10:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-03 16:00:00','2026-03-06 18:38:17',0),(19,1,3,27,NULL,NULL,132,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-06 10:00:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-05 09:00:00','2026-03-06 18:38:17',0),(20,1,3,28,NULL,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 21:30:00',1,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 10:15:00','2026-03-06 18:38:17',0),(21,1,3,29,NULL,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 14:20:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 11:45:00','2026-03-06 18:38:17',0),(22,1,3,30,NULL,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-04 20:50:00',0,1,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-03 15:30:00','2026-03-06 18:38:17',0),(23,1,4,31,NULL,NULL,138,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 22:00:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 12:20:00','2026-03-06 18:38:17',0),(24,1,5,32,NULL,NULL,146,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 19:45:00',0,2,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 13:00:00','2026-03-06 18:38:17',0),(25,1,6,18,NULL,NULL,149,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 16:30:00',1,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 14:15:00','2026-03-06 18:38:17',0),(26,1,7,19,NULL,NULL,152,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 13:20:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 15:40:00','2026-03-06 18:38:17',0),(27,1,8,20,NULL,NULL,155,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-04 18:50:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-03 16:20:00','2026-03-06 18:38:17',0),(28,1,18,21,NULL,NULL,158,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-04 17:30:00',0,1,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-03 17:00:00','2026-03-06 18:38:17',0),(29,1,19,22,NULL,NULL,161,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-04 16:10:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-03 18:30:00','2026-03-06 18:38:17',0),(30,1,20,23,NULL,NULL,166,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-04 15:00:00',1,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-03 19:15:00','2026-03-06 18:38:17',0),(31,1,1,2,NULL,NULL,169,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 12:00:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-02 10:00:00','2026-03-06 18:38:17',0),(32,1,18,19,NULL,NULL,173,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 11:30:00',0,2,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-02 11:00:00','2026-03-06 18:38:36',0),(33,1,20,21,NULL,NULL,177,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 18:00:00',3,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-03 12:00:00','2026-03-06 18:38:36',0),(34,1,22,23,NULL,NULL,179,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-04 14:00:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-02 14:00:00','2026-03-06 18:37:49',0),(35,1,24,25,NULL,NULL,181,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-04 16:00:00',0,1,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-02 16:00:00','2026-03-06 18:38:36',0),(100,1,9,18,NULL,NULL,202,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-06 10:00:00',0,1,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-05 10:00:00','2026-03-06 18:38:36',0),(101,1,9,19,NULL,NULL,204,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-06 09:30:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-05 11:00:00','2026-03-06 18:38:36',0),(102,1,9,20,NULL,NULL,208,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 20:00:00',0,2,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 14:00:00','2026-03-06 18:38:36',0),(103,1,1,9,NULL,NULL,212,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 18:00:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 12:00:00','2026-03-06 18:38:36',0),(104,1,9,21,NULL,NULL,214,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 16:00:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 15:00:00','2026-03-06 18:48:11',0),(105,1,9,22,NULL,NULL,217,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 14:30:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-04 13:00:00','2026-03-06 18:38:36',0),(106,1,2,9,NULL,NULL,220,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-04 17:00:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-03 16:00:00','2026-03-07 15:57:44',0),(107,1,9,23,NULL,NULL,223,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-04 15:30:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-03 14:00:00','2026-03-06 18:38:36',0),(200,1,9,1,NULL,NULL,424,'1\n',1,'2026-03-07 17:17:06',0,14,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-06 11:00:00','2026-03-07 17:23:52',0),(201,1,2,9,51,NULL,289762671828541260,'3',1,'2026-03-10 22:13:24',2,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-06 10:30:00','2026-03-11 13:56:58',0),(202,1,9,3,NULL,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-06 09:00:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-06 09:00:00','2026-03-06 18:38:36',0),(203,1,4,9,50,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 16:00:00',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-05 14:00:00','2026-03-06 18:38:36',0),(204,1,9,5,NULL,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 15:00:00',0,1,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-05 15:00:00','2026-03-06 18:38:36',0),(205,1,6,9,NULL,NULL,NULL,'ddasd1233322222222222ddasd1233322222222222ddasd1233322222222222',NULL,'2026-03-05 14:00:00',1,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-05 14:00:00','2026-03-06 18:38:36',0),(206,1,9,34,NULL,100,417,'http://localhost:8080/api/image/b95ad769-1bde-4dd5-ad15-2b29428660e2.png',NULL,'2026-03-07 16:52:10',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-07 09:43:11','2026-03-11 13:56:56',0),(207,1,9,34,NULL,NULL,404,'hi\n',NULL,'2026-03-07 15:46:00',0,1,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-07 15:45:55','2026-03-07 15:45:55',0),(289757411659620019,1,8,9,NULL,NULL,289764767541891931,'3',1,'2026-03-10 22:21:44',0,0,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-10 21:52:30','2026-03-23 17:39:40',0),(289764955505432335,1,8,9,289750524650199795,NULL,301641100827955832,'hello',1,'2026-04-12 16:54:03',0,5,0,0,NULL,NULL,0,0,0,0,NULL,NULL,0,'2026-03-10 22:22:29','2026-03-23 17:39:37',0);
/*!40000 ALTER TABLE `conversation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation_member`
--

DROP TABLE IF EXISTS `conversation_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversation_member` (
  `member_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '成员ID',
  `conversation_id` bigint unsigned NOT NULL COMMENT '会话ID',
  `user_id` bigint unsigned NOT NULL COMMENT '用户ID',
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '群昵称',
  `unread_count` int unsigned NOT NULL DEFAULT '0' COMMENT '未读消息数',
  `is_muted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否免打扰：0-否 1-是',
  `join_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间',
  `last_read_message_id` bigint unsigned DEFAULT NULL COMMENT '最后阅读的消息ID',
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `idx_conversation_user` (`conversation_id`,`user_id`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `fk_conversation_member_conv` FOREIGN KEY (`conversation_id`) REFERENCES `conversation` (`conversation_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_conversation_member_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会话成员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation_member`
--

LOCK TABLES `conversation_member` WRITE;
/*!40000 ALTER TABLE `conversation_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversation_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon`
--

DROP TABLE IF EXISTS `coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon` (
  `coupon_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¼˜æƒ åˆ¸ID',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ä¼˜æƒ åˆ¸åç§°',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¼˜æƒ åˆ¸æè¿°',
  `type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'ä¼˜æƒ åˆ¸ç±»åž‹ï¼š1-æ»¡å‡åˆ¸ï¼Œ2-æŠ˜æ‰£åˆ¸ï¼Œ3-å…é‚®åˆ¸',
  `min_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'é—¨æ§›é‡‘é¢ï¼ˆæ»¡å¤šå°‘å¯ç”¨ï¼‰',
  `discount_value` decimal(10,2) NOT NULL COMMENT 'ä¼˜æƒ é‡‘é¢/æŠ˜æ‰£å€¼',
  `max_discount` decimal(10,2) DEFAULT NULL COMMENT 'æœ€å¤§ä¼˜æƒ é‡‘é¢ï¼ˆæŠ˜æ‰£åˆ¸ç”¨ï¼‰',
  `total_count` int unsigned NOT NULL DEFAULT '0' COMMENT 'æ€»å‘è¡Œæ•°é‡',
  `received_count` int unsigned NOT NULL DEFAULT '0' COMMENT 'å·²é¢†å–æ•°é‡',
  `used_count` int unsigned NOT NULL DEFAULT '0' COMMENT 'å·²ä½¿ç”¨æ•°é‡',
  `limit_per_user` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'æ¯äººé™é¢†æ•°é‡',
  `scope` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'ä½¿ç”¨èŒƒå›´ï¼š1-å…¨åœºï¼Œ2-æŒ‡å®šåˆ†ç±»ï¼Œ3-æŒ‡å®šå•†å“',
  `category_ids` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é€‚ç”¨åˆ†ç±»IDï¼ˆJSONæ•°ç»„ï¼‰',
  `product_ids` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é€‚ç”¨å•†å“IDï¼ˆJSONæ•°ç»„ï¼‰',
  `valid_from` datetime NOT NULL COMMENT 'æœ‰æ•ˆå¼€å§‹æ—¶é—´',
  `valid_to` datetime NOT NULL COMMENT 'æœ‰æ•ˆç»“æŸæ—¶é—´',
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¼˜æƒ åˆ¸å›¾ç‰‡',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-è‰ç¨¿ï¼Œ1-è¿›è¡Œä¸­ï¼Œ2-å·²ç»“æŸï¼Œ3-å·²ä½œåºŸ',
  `sort_order` int unsigned NOT NULL DEFAULT '0' COMMENT 'æŽ’åº',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ ‡è®°ï¼š0-æ­£å¸¸ 1-å·²åˆ é™¤',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`coupon_id`),
  KEY `idx_status` (`status`),
  KEY `idx_valid_time` (`valid_from`,`valid_to`),
  KEY `idx_sort` (`sort_order` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ä¼˜æƒ åˆ¸è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon`
--

LOCK TABLES `coupon` WRITE;
/*!40000 ALTER TABLE `coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `error_log`
--

DROP TABLE IF EXISTS `error_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `error_log` (
  `id` bigint NOT NULL COMMENT '异常ID',
  `level` varchar(10) NOT NULL COMMENT '异常级别：ERROR/WARN/INFO',
  `message` text NOT NULL COMMENT '异常信息',
  `exception_type` varchar(100) DEFAULT NULL COMMENT '异常类型',
  `stack_trace` text COMMENT '堆栈跟踪',
  `request_url` varchar(500) DEFAULT NULL COMMENT '请求URL',
  `request_method` varchar(10) DEFAULT NULL COMMENT '请求方法',
  `request_params` text COMMENT '请求参数',
  `user_id` bigint DEFAULT NULL COMMENT '操作用户ID',
  `user_type` tinyint DEFAULT NULL COMMENT '用户类型：1-普通用户 2-管理员',
  `ip` varchar(50) DEFAULT NULL COMMENT 'IP地址',
  `occur_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '发生时间',
  PRIMARY KEY (`id`),
  KEY `idx_level` (`level`),
  KEY `idx_occur_time` (`occur_time`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统异常日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `error_log`
--

LOCK TABLES `error_log` WRITE;
/*!40000 ALTER TABLE `error_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `error_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluation`
--

DROP TABLE IF EXISTS `evaluation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evaluation` (
  `eval_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '评价ID',
  `order_id` bigint unsigned NOT NULL COMMENT '订单ID',
  `from_user_id` bigint unsigned NOT NULL COMMENT '评价人ID',
  `to_user_id` bigint unsigned NOT NULL COMMENT '被评价人ID',
  `score` tinyint unsigned NOT NULL COMMENT '评分：1-5星',
  `content` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '评价内容',
  `tags` json DEFAULT NULL COMMENT '标签，JSON数组：如["发货快","描述准确"]',
  `images` json DEFAULT NULL COMMENT 'è¯„ä»·å›¾ç‰‡ï¼ˆJSONæ•°ç»„ï¼‰',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`eval_id`),
  UNIQUE KEY `idx_order_id` (`order_id`),
  KEY `idx_from_user_id` (`from_user_id`),
  KEY `idx_to_user_id` (`to_user_id`),
  KEY `idx_score` (`score`),
  CONSTRAINT `fk_eval_from_user` FOREIGN KEY (`from_user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_eval_order` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eval_to_user` FOREIGN KEY (`to_user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=289770502883514083 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='评价表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluation`
--

LOCK TABLES `evaluation` WRITE;
/*!40000 ALTER TABLE `evaluation` DISABLE KEYS */;
INSERT INTO `evaluation` VALUES (1,3,1,2,5,'商品很好，描述准确，卖家态度也很好！','[\"描述准确\", \"态度好\", \"发货快\"]',NULL,'2025-01-19 11:00:00'),(2,4,2,4,4,'商品质量不错，就是物流慢了一点','[\"质量好\", \"物流稍慢\"]',NULL,'2025-01-18 12:00:00'),(3,2,1,3,5,'非常满意的一次交易，推荐！','[\"满意\", \"推荐\"]',NULL,'2025-01-19 16:00:00'),(4,6,9,1,5,'手机成色很好，和描述一致，卖家回复也很及时，非常满意的一次交易！','[\"成色很好\", \"描述准确\", \"回复及时\", \"包装仔细\"]',NULL,'2025-03-05 16:00:00'),(5,7,9,2,5,'iPad 颜值很高，紫色真的很好看！用于网课和看剧完全够用，卖家还送了保护壳，太贴心了～','[\"颜值高\", \"性价比不错\", \"送配件\", \"推荐\"]',NULL,'2025-03-04 15:00:00'),(6,8,9,3,4,'自行车功能正常，变速灵敏。就是有点旧，卖家提前说过了，总体满意。','[\"功能正常\", \"与描述一致\", \"性价比高\"]',NULL,'2025-03-03 14:00:00'),(7,9,1,9,5,'商品很新，发货很快，test123 同学非常诚信！推荐大家交易。','[\"商品很新\", \"发货迅速\", \"诚信卖家\", \"推荐\"]',NULL,'2025-02-22 14:00:00'),(289770502883514082,289750524650199795,9,8,4,'3123','[\"正品\"]',NULL,'2026-03-10 22:44:31');
/*!40000 ALTER TABLE `evaluation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `export_log`
--

DROP TABLE IF EXISTS `export_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `export_log` (
  `id` bigint NOT NULL COMMENT '导出ID',
  `admin_id` bigint NOT NULL COMMENT '管理员ID',
  `admin_name` varchar(50) NOT NULL COMMENT '管理员用户名',
  `report_type` varchar(50) NOT NULL COMMENT '报表类型: user/order/product',
  `file_name` varchar(255) NOT NULL COMMENT '文件名',
  `file_path` varchar(500) NOT NULL COMMENT '文件路径',
  `row_count` int NOT NULL COMMENT '数据行数',
  `file_size` bigint NOT NULL COMMENT '文件大小(字节)',
  `start_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime NOT NULL COMMENT '结束时间',
  `duration` bigint DEFAULT NULL COMMENT '导出耗时(毫秒)',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_report_type` (`report_type`),
  KEY `idx_create_time` (`create_time`),
  KEY `idx_admin_type_time` (`admin_id`,`report_type`,`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='数据导出记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export_log`
--

LOCK TABLES `export_log` WRITE;
/*!40000 ALTER TABLE `export_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `export_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flash_sale_order_ext`
--

DROP TABLE IF EXISTS `flash_sale_order_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flash_sale_order_ext` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `order_id` bigint unsigned NOT NULL COMMENT 'è®¢å•IDï¼ˆå…³è”orderè¡¨ï¼‰',
  `user_id` bigint unsigned NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆå†—ä½™å­—æ®µï¼Œæ–¹ä¾¿æŸ¥è¯¢ï¼‰',
  `product_id` bigint unsigned NOT NULL COMMENT 'å•†å“IDï¼ˆå†—ä½™å­—æ®µï¼Œæ–¹ä¾¿æŸ¥è¯¢ï¼‰',
  `session_id` bigint unsigned DEFAULT NULL COMMENT 'ç§’æ€åœºæ¬¡ID',
  `flash_price` decimal(10,2) NOT NULL COMMENT 'ç§’æ€æˆäº¤ä»·',
  `discount` decimal(3,1) DEFAULT NULL COMMENT 'æŠ˜æ‰£ï¼ˆå¦‚8.5è¡¨ç¤º8.5æŠ˜ï¼‰',
  `seckill_time` datetime NOT NULL COMMENT 'æŠ¢è´­æ—¶é—´',
  `client_ip` varchar(50) DEFAULT NULL COMMENT 'å®¢æˆ·ç«¯IPï¼ˆé˜²åˆ·å•ï¼‰',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_order_id` (`order_id`) COMMENT 'ä¸€ä¸ªè®¢å•åªèƒ½æœ‰ä¸€æ¡ç§’æ€è®°å½•',
  KEY `idx_user_activity` (`user_id`) COMMENT 'æŸ¥è¯¢ç”¨æˆ·åœ¨æŸæ´»åŠ¨çš„è´­ä¹°è®°å½•',
  KEY `idx_user_session` (`user_id`,`session_id`) COMMENT 'æŸ¥è¯¢ç”¨æˆ·åœ¨åœºæ¬¡çš„è´­ä¹°è®°å½•',
  KEY `idx_activity_time` (`seckill_time`) COMMENT 'æ´»åŠ¨è®¢å•æŒ‰æ—¶é—´æŽ’åº',
  KEY `idx_user_product` (`user_id`,`product_id`) COMMENT 'æŸ¥è¯¢ç”¨æˆ·è´­ä¹°æŸå•†å“è®°å½•',
  KEY `idx_client_ip` (`client_ip`) COMMENT 'é˜²åˆ·å•æŸ¥è¯¢'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='ç§’æ€è®¢å•æ‰©å±•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flash_sale_order_ext`
--

LOCK TABLES `flash_sale_order_ext` WRITE;
/*!40000 ALTER TABLE `flash_sale_order_ext` DISABLE KEYS */;
/*!40000 ALTER TABLE `flash_sale_order_ext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flash_sale_product`
--

DROP TABLE IF EXISTS `flash_sale_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flash_sale_product` (
  `id` bigint unsigned NOT NULL COMMENT '秒杀商品ID',
  `session_id` bigint unsigned DEFAULT NULL COMMENT '场次ID',
  `product_id` bigint unsigned NOT NULL COMMENT 'å•†å“ID',
  `flash_price` decimal(10,2) NOT NULL COMMENT 'ç§’æ€ä»·æ ¼',
  `stock_count` int unsigned NOT NULL DEFAULT '1' COMMENT 'ç§’æ€åº“å­˜æ•°é‡ï¼ˆäºŒæ‰‹å•†å“é€šå¸¸ä¸º1ï¼‰',
  `sold_count` int unsigned NOT NULL DEFAULT '0' COMMENT 'å·²å”®æ•°é‡',
  `limit_per_user` int unsigned DEFAULT '1' COMMENT '每人限购数量',
  `repeat_type` tinyint DEFAULT '1' COMMENT '重复类型：0-不重复（卖完下架），1-每日重复',
  `sale_date` date DEFAULT NULL COMMENT '参与秒杀的日期（NULL表示每日重复，有值表示指定日期）',
  `stock_status` tinyint DEFAULT '0' COMMENT '库存状态：0-在售，1-已售罄，2-手动下架',
  `sort_order` int unsigned NOT NULL DEFAULT '0' COMMENT 'æŽ’åºæƒé‡',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ ‡è®°ï¼š0-æ­£å¸¸ 1-å·²åˆ é™¤',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_product` (`product_id`),
  KEY `idx_sort` (`sort_order` DESC),
  KEY `idx_session_id` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç§’æ€å•†å“è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flash_sale_product`
--

LOCK TABLES `flash_sale_product` WRITE;
/*!40000 ALTER TABLE `flash_sale_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `flash_sale_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flash_sale_session`
--

DROP TABLE IF EXISTS `flash_sale_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flash_sale_session` (
  `session_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'åœºæ¬¡ID',
  `name` varchar(100) DEFAULT NULL COMMENT '场次名称',
  `description` varchar(500) DEFAULT NULL COMMENT '场次描述',
  `session_time` varchar(10) DEFAULT NULL COMMENT '场次时间点（HH:mm格式）',
  `start_time` datetime NOT NULL COMMENT 'å®žé™…å¼€å§‹æ—¶é—´',
  `end_time` datetime NOT NULL COMMENT 'å®žé™…ç»“æŸæ—¶é—´',
  `sort_order` int unsigned NOT NULL DEFAULT '0' COMMENT 'æŽ’åº',
  `session_type` tinyint DEFAULT '1' COMMENT '场次类型：1-默认固定场次，2-特殊临时场次',
  `enabled` tinyint DEFAULT '1' COMMENT '是否启用：0-禁用（暂停/取消），1-启用',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`),
  KEY `idx_status_time` (`start_time`,`end_time`)
) ENGINE=InnoDB AUTO_INCREMENT=289300035559100484 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='ç§’æ€åœºæ¬¡è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flash_sale_session`
--

LOCK TABLES `flash_sale_session` WRITE;
/*!40000 ALTER TABLE `flash_sale_session` DISABLE KEYS */;
INSERT INTO `flash_sale_session` VALUES (1,'早场',NULL,'08:00','2026-04-12 08:00:00','2026-04-12 10:00:00',1,1,1,'2026-03-04 16:58:37'),(2,'午场',NULL,'12:00','2026-04-12 12:00:00','2026-04-12 14:00:00',2,1,1,'2026-03-04 16:58:37'),(3,'晚场',NULL,'18:00','2026-04-12 18:00:00','2026-04-12 20:00:00',3,1,1,'2026-03-04 16:58:37'),(4,'夜场',NULL,'22:00','2026-04-12 22:00:00','2026-04-13 00:00:00',4,1,1,'2026-03-04 16:58:37'),(289300035559100483,'3123','123','01:00','2026-03-06 01:00:00','2026-03-06 18:59:00',99,2,1,'2026-03-09 15:35:03');
/*!40000 ALTER TABLE `flash_sale_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flash_sale_session_template`
--

DROP TABLE IF EXISTS `flash_sale_session_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flash_sale_session_template` (
  `template_id` int NOT NULL AUTO_INCREMENT COMMENT '模板ID',
  `name` varchar(100) NOT NULL COMMENT '场次名称',
  `session_time` varchar(10) NOT NULL COMMENT '时间点 HH:mm',
  `duration_hours` int NOT NULL DEFAULT '2' COMMENT '持续小时数',
  `sort_order` int NOT NULL COMMENT '排序权重',
  `is_enabled` tinyint NOT NULL DEFAULT '1' COMMENT '是否启用：0-禁用，1-启用',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` int NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除，1-已删除',
  PRIMARY KEY (`template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='秒杀场次模板表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flash_sale_session_template`
--

LOCK TABLES `flash_sale_session_template` WRITE;
/*!40000 ALTER TABLE `flash_sale_session_template` DISABLE KEYS */;
INSERT INTO `flash_sale_session_template` VALUES (1,'早场','08:00',3,1,1,'2026-03-04 13:07:26','2026-03-09 13:39:51',0),(2,'午场','12:00',2,2,1,'2026-03-04 13:07:26','2026-03-04 13:07:26',0),(3,'晚场','18:00',2,3,1,'2026-03-04 13:07:26','2026-03-04 13:07:26',0),(4,'夜场','22:00',2,4,1,'2026-03-04 13:07:26','2026-03-04 13:07:26',0);
/*!40000 ALTER TABLE `flash_sale_session_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hot_tag`
--

DROP TABLE IF EXISTS `hot_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hot_tag` (
  `id` bigint NOT NULL COMMENT '标签ID',
  `keyword` varchar(50) NOT NULL COMMENT '搜索关键词',
  `click_count` int DEFAULT '0' COMMENT '点击次数',
  `sort_order` int DEFAULT '0' COMMENT '排序值（越小越靠前）',
  `is_active` tinyint DEFAULT '1' COMMENT '是否启用：0-禁用 1-启用',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '删除标记：0-正常 1-已删除',
  PRIMARY KEY (`id`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='热门搜索标签表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hot_tag`
--

LOCK TABLES `hot_tag` WRITE;
/*!40000 ALTER TABLE `hot_tag` DISABLE KEYS */;
INSERT INTO `hot_tag` VALUES (1,'iPhone',0,1,1,'2026-03-07 22:47:06','2026-03-07 22:47:06',0),(2,'iPad',0,2,1,'2026-03-07 22:47:06','2026-03-07 22:47:06',0),(3,'MacBook',0,3,1,'2026-03-07 22:47:06','2026-03-07 22:47:06',0),(4,'自行车',0,4,1,'2026-03-07 22:47:06','2026-03-07 22:47:06',0),(5,'教材',0,5,1,'2026-03-07 22:47:06','2026-03-07 22:47:06',0);
/*!40000 ALTER TABLE `hot_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_device`
--

DROP TABLE IF EXISTS `login_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_device` (
  `device_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'è®¾å¤‡ID',
  `user_id` bigint unsigned NOT NULL COMMENT 'ç”¨æˆ·ID',
  `device_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¾å¤‡åç§°',
  `device_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¾å¤‡ç±»åž‹ï¼šios/android/web/miniapp',
  `platform` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¹³å°æ ‡è¯†',
  `device_identifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¾å¤‡å”¯ä¸€æ ‡è¯†',
  `last_login_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æœ€åŽç™»å½•IP',
  `last_login_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'æœ€åŽç™»å½•æ—¶é—´',
  `is_current` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'æ˜¯å¦ä¸ºå½“å‰è®¾å¤‡ï¼š0-å¦ 1-æ˜¯',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-æ­£å¸¸ 1-å·²ç§»é™¤',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ ‡è®°ï¼š0-æ­£å¸¸ 1-å·²åˆ é™¤',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`device_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_device_identifier` (`device_identifier`),
  KEY `idx_user_status` (`user_id`,`status`),
  KEY `idx_last_login` (`last_login_time` DESC)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç™»å½•è®¾å¤‡è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_device`
--

LOCK TABLES `login_device` WRITE;
/*!40000 ALTER TABLE `login_device` DISABLE KEYS */;
INSERT INTO `login_device` VALUES (1,9,'iPhone','ios','iOS','17727020869027389549','10.173.241.252','2026-03-11 22:13:22',1,0,0,'2026-03-06 22:24:33','2026-03-09 22:21:49'),(2,34,'iPhone','ios','iOS','17728093603259967076','0:0:0:0:0:0:0:1','2026-03-07 09:16:02',1,0,0,'2026-03-07 09:16:02','2026-03-07 09:16:02'),(3,288626339412582000,'iPhone','ios','iOS','17728093603259967076','0:0:0:0:0:0:0:1','2026-03-07 18:58:35',1,0,0,'2026-03-07 18:58:35','2026-03-07 18:58:35'),(4,9,'iPhone','ios','iOS','1773066083231565995','0:0:0:0:0:0:0:1','2026-03-10 22:22:23',0,0,0,'2026-03-09 22:21:50','2026-03-11 10:55:26'),(5,8,'iPhone','ios','iOS','17731158610626107637','0:0:0:0:0:0:0:1','2026-03-10 12:26:39',0,0,0,'2026-03-10 12:26:39','2026-03-23 17:30:25'),(6,9,'iPhone','ios','iOS','iPhone 12/13 (Pro)','0:0:0:0:0:0:0:1','2026-03-11 10:55:27',0,0,0,'2026-03-11 10:55:27','2026-03-11 22:13:21'),(7,8,'iPhone','ios','iOS','iPhone 12/13 (Pro)','127.0.0.1','2026-04-12 14:49:16',1,0,0,'2026-03-23 17:30:26','2026-03-23 17:30:26');
/*!40000 ALTER TABLE `login_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message` (
  `message_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '消息ID',
  `conversation_id` bigint unsigned NOT NULL COMMENT '会话ID',
  `from_user_id` bigint unsigned NOT NULL COMMENT '发送者ID',
  `to_user_id` bigint unsigned DEFAULT NULL COMMENT '接收者ID（单聊时使用）',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '消息内容',
  `type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '类型：1-文本 2-图片 3-商品卡片 4-订单卡片 5-系统通知 6-引用消息',
  `parent_message_id` bigint unsigned DEFAULT NULL COMMENT '引用的父消息ID',
  `is_read` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否已读：0-未读 1-已读',
  `read_time` datetime DEFAULT NULL COMMENT '阅读时间',
  `send_status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '发送状态：0-发送中 1-成功 2-失败',
  `delivered_time` datetime DEFAULT NULL COMMENT '送达时间',
  `extra_data` json DEFAULT NULL COMMENT '扩展数据，存储卡片详细信息',
  `reply_count` int unsigned NOT NULL DEFAULT '0' COMMENT '被回复次数',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0-正常 1-撤回 2-删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`message_id`),
  KEY `idx_conversation_id` (`conversation_id`),
  KEY `idx_from_user_id` (`from_user_id`),
  KEY `idx_create_time` (`create_time`),
  KEY `idx_parent_message_id` (`parent_message_id`),
  KEY `fk_message_to_user` (`to_user_id`),
  CONSTRAINT `fk_message_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `conversation` (`conversation_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_message_from_user` FOREIGN KEY (`from_user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_message_parent` FOREIGN KEY (`parent_message_id`) REFERENCES `message` (`message_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_message_to_user` FOREIGN KEY (`to_user_id`) REFERENCES `user` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=301641100827955833 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='消息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES (1,1,2,1,'å¥½çš„ï¼Œä¸‹åˆ3ç‚¹åœ¨å—åŒºå®¿èˆæ¥¼ä¸‹è§',1,NULL,1,NULL,1,NULL,NULL,0,0,'2025-01-20 10:30:00','2026-03-06 17:47:46',0),(2,1,1,2,'å¥½çš„ï¼Œ2ç‚¹è§',1,NULL,1,NULL,1,NULL,NULL,0,0,'2025-01-20 12:00:00','2026-03-06 17:47:46',0),(3,1,2,1,'ä½ å¥½ï¼Œçœ‹åˆ°ä½ å‘å¸ƒçš„iPhoneäº†',1,NULL,1,NULL,1,NULL,NULL,0,0,'2025-01-20 14:00:00','2026-03-06 17:47:46',0),(4,1,1,2,'ä½ å¥½ï¼Œè¿™ä¸ªæ‰‹æœºè¿˜åœ¨å—ï¼Ÿ',1,NULL,1,NULL,1,NULL,NULL,0,0,'2025-01-20 16:00:00','2026-03-06 17:47:46',0),(5,2,1,3,'æ²¡é—®é¢˜ï¼Œä¸œè¥¿è¿˜ä¸é”™',1,NULL,1,NULL,1,NULL,NULL,0,0,'2025-01-19 14:30:00','2026-03-06 17:47:46',0),(6,2,3,1,'æ€Žä¹ˆæ ·ï¼Œä¸œè¥¿è¿˜å¥½å—ï¼Ÿ',1,NULL,1,NULL,1,NULL,NULL,0,0,'2025-01-19 15:00:00','2026-03-06 17:47:46',0),(7,3,2,4,'å¥½çš„ï¼Œè°¢è°¢ï¼',1,NULL,0,NULL,1,NULL,NULL,0,0,'2025-01-17 12:00:00','2026-03-06 17:47:46',0),(100,10,1,18,'ä½ å¥½ï¼Œçœ‹åˆ°ä½ å‘å¸ƒçš„iPhoneäº†',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 10:00:00','2026-03-06 17:16:43',0),(101,10,18,1,'ä½ å¥½ï¼Œæ˜¯çš„è¿˜åœ¨',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 10:05:00','2026-03-06 17:16:43',0),(102,10,1,18,'æˆè‰²æ€Žä¹ˆæ ·ï¼Ÿæœ‰é…ä»¶å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 10:10:00','2026-03-06 17:16:43',0),(103,10,18,1,'99æ–°ï¼Œç›’è¯´å…¨ï¼Œæœ‰åŽŸè£…å……ç”µå™¨',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 10:15:00','2026-03-06 17:16:43',0),(104,10,1,18,'ä»·æ ¼å¯ä»¥å•†é‡å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 10:20:00','2026-03-06 17:16:43',0),(105,10,18,1,'å¯ä»¥å°åˆ€ï¼Œæœ€ä½Ž5800',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 10:25:00','2026-03-06 17:16:43',0),(106,10,1,18,'å¥½çš„ï¼Œ5800å¯ä»¥äº†',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 09:00:00','2026-03-06 17:16:43',0),(107,10,18,1,'å¥½çš„ï¼Œä»€ä¹ˆæ—¶å€™æ–¹ä¾¿äº¤æ˜“ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 09:10:00','2026-03-06 17:16:43',0),(108,10,1,18,'ä¸‹åˆ3ç‚¹å¯ä»¥å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 09:20:00','2026-03-06 17:16:43',0),(109,10,18,1,'å¥½çš„ï¼Œä¸‹åˆ3ç‚¹åœ¨å—åŒºå®¿èˆæ¥¼ä¸‹è§',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 09:30:00','2026-03-06 17:16:43',0),(110,11,1,19,'ä½ å¥½ï¼Œè¯·é—®iPadè¿˜åœ¨å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 11:00:00','2026-03-06 17:16:43',0),(111,11,19,1,'åœ¨çš„ï¼Œä½ éœ€è¦å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 11:10:00','2026-03-06 17:16:43',0),(112,11,1,19,'è¯·é—®è¿™ä¸ªè¿˜åœ¨å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 08:15:00','2026-03-06 17:16:43',0),(113,12,1,20,'ä½ å¥½ï¼Œé”®ç›˜å¤šå°‘é’±ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 14:00:00','2026-03-06 17:16:43',0),(114,12,20,1,'299å…ƒ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 14:10:00','2026-03-06 17:16:43',0),(115,12,1,20,'å¯ä»¥ä¾¿å®œç‚¹å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 14:20:00','2026-03-06 17:16:43',0),(116,12,20,1,'æœ€ä½Ž280',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 20:30:00','2026-03-06 17:16:43',0),(117,12,1,20,'å¥½çš„ï¼Œæˆ‘å†çœ‹çœ‹',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 20:40:00','2026-03-06 17:16:43',0),(118,12,20,1,'å¯ä»¥ä¾¿å®œç‚¹å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 20:45:00','2026-03-06 17:16:43',0),(119,15,2,23,'ä½ å¥½ï¼Œä¹¦è¿˜åœ¨å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 12:00:00','2026-03-06 17:16:43',0),(120,15,23,2,'åœ¨çš„',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 12:10:00','2026-03-06 17:16:43',0),(121,15,2,23,'æˆ‘æƒ³è¦äº†ï¼Œæ€Žä¹ˆäº¤æ˜“ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 09:00:00','2026-03-06 17:16:43',0),(122,15,23,2,'æ˜Žå¤©ä¸‹åˆå›¾ä¹¦é¦†è§',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 09:10:00','2026-03-06 17:16:43',0),(123,15,2,23,'å¥½çš„ï¼Œæ”¶åˆ°',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 07:50:00','2026-03-06 17:16:43',0),(124,15,23,2,'æ”¶åˆ°ï¼Œæ²¡é—®é¢˜',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 07:50:00','2026-03-06 17:16:43',0),(125,19,3,27,'ä½ å¥½ï¼Œè‡ªè¡Œè½¦è¿˜åœ¨å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 09:00:00','2026-03-06 17:16:43',0),(126,19,27,3,'åœ¨çš„ï¼Œä½ è¦å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 09:10:00','2026-03-06 17:16:43',0),(127,19,3,27,'æˆ‘æƒ³è¦äº†ï¼Œ350å¯ä»¥å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 09:20:00','2026-03-06 17:16:43',0),(128,19,27,3,'å¯ä»¥ï¼Œä»€ä¹ˆæ—¶å€™çœ‹è½¦ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 09:30:00','2026-03-06 17:16:43',0),(129,19,3,27,'çŽ°åœ¨å¯ä»¥å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 09:40:00','2026-03-06 17:16:43',0),(130,19,27,3,'å¥½çš„ï¼ŒåŒ—åŒºè½¦æ£šè§',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 09:50:00','2026-03-06 17:16:43',0),(131,19,3,27,'è½¦æŒºå¥½çš„ï¼Œæˆ‘ä¹°äº†',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 10:00:00','2026-03-06 17:16:43',0),(132,19,27,3,'å¥½çš„ï¼Œè°¢è°¢æƒ é¡¾',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 10:00:00','2026-03-06 17:16:43',0),(133,23,4,31,'ä½ å¥½',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 12:20:00','2026-03-06 17:16:43',0),(134,23,31,4,'ä½ å¥½ï¼Œè¯·é—®æœ‰ä»€ä¹ˆäº‹ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 12:30:00','2026-03-06 17:16:43',0),(135,23,4,31,'çœ‹åˆ°ä½ çš„æ‰‹çŽ¯äº†ï¼Œè¿˜åœ¨å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 10:00:00','2026-03-06 17:16:43',0),(136,23,31,4,'åœ¨çš„ï¼Œ159å…ƒ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 10:10:00','2026-03-06 17:16:43',0),(137,23,4,31,'å¥½çš„ï¼Œæˆ‘æƒ³è¦äº†',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 21:00:00','2026-03-06 17:16:43',0),(138,23,31,4,'å—¯å—¯ï¼Œå¥½çš„',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 22:00:00','2026-03-06 17:16:43',0),(139,24,5,32,'ä½ å¥½ï¼Œè¯·é—®MacBookè¿˜åœ¨å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 13:00:00','2026-03-06 17:16:43',0),(140,24,32,5,'åœ¨çš„',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 13:10:00','2026-03-06 17:16:43',0),(141,24,5,32,'7500å¯ä»¥å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 19:00:00','2026-03-06 17:16:43',0),(142,24,32,5,'æœ€ä½Ž7300',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 19:30:00','2026-03-06 17:16:43',0),(143,24,5,32,'å¥½çš„ï¼Œ7300å¯ä»¥',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 19:40:00','2026-03-06 17:16:43',0),(144,24,32,5,'å¥½çš„ï¼Œæˆ‘çŸ¥é“äº†',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 19:45:00','2026-03-06 17:16:43',0),(145,24,32,5,'ä»€ä¹ˆæ—¶å€™äº¤æ˜“ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 19:50:00','2026-03-06 17:16:43',0),(146,24,32,5,'å‘¨æœ«å¯ä»¥å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 19:55:00','2026-03-06 17:16:43',0),(147,25,6,18,'ä½ å¥½',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 14:15:00','2026-03-06 17:16:43',0),(148,25,18,6,'ä½ å¥½',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 14:20:00','2026-03-06 17:16:43',0),(149,25,6,18,'å¯ä»¥å‘ä¸€ä¸‹å›¾ç‰‡å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 16:30:00','2026-03-06 17:16:43',0),(150,26,7,19,'ä½ å¥½ï¼Œè€ƒç ”çœŸé¢˜è¿˜åœ¨å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 15:40:00','2026-03-06 17:16:43',0),(151,26,19,7,'åœ¨çš„',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 15:50:00','2026-03-06 17:16:43',0),(152,26,7,19,'å¤šå°‘é’±ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 13:20:00','2026-03-06 17:16:43',0),(153,27,8,20,'ä½ å¥½ï¼Œå…­çº§è¯æ±‡ä¹¦è¿˜åœ¨å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-03 16:20:00','2026-03-06 17:16:43',0),(154,27,20,8,'åœ¨çš„ï¼Œ10å…ƒ',1,NULL,1,'2026-03-10 21:52:53',0,NULL,NULL,0,1,'2026-03-03 16:30:00','2026-03-10 21:52:52',0),(155,27,8,20,'å¥½çš„ï¼Œæˆäº¤ï¼',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 18:50:00','2026-03-06 17:16:43',0),(156,28,18,21,'ä½ å¥½',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-03 17:00:00','2026-03-06 17:16:43',0),(157,28,21,18,'ä½ å¥½',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-03 17:10:00','2026-03-06 17:16:43',0),(158,28,18,21,'è¿™ä¸ªç‰Œå­è¿˜ä¸é”™',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 17:30:00','2026-03-06 17:16:43',0),(159,29,19,22,'ä½ å¥½ï¼Œä»€ä¹ˆæ—¶å€™æ–¹ä¾¿ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-03 18:30:00','2026-03-06 17:16:43',0),(160,29,22,19,'å‘¨æœ«å¯ä»¥',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-03 18:40:00','2026-03-06 17:16:43',0),(161,29,19,22,'å¥½çš„ï¼Œå‘¨æœ«å¯ä»¥å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 16:10:00','2026-03-06 17:16:43',0),(162,30,20,23,'ä½ å¥½',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-03 19:15:00','2026-03-06 17:16:43',0),(163,30,23,20,'ä½ å¥½',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-03 19:20:00','2026-03-06 17:16:43',0),(164,30,20,23,'è¿™ä¸ªä¸œè¥¿æ€Žä¹ˆæ ·ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 14:50:00','2026-03-06 17:16:43',0),(165,30,23,20,'è¿˜ä¸é”™',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 14:55:00','2026-03-06 17:16:43',0),(166,30,20,23,'å—¯å—¯ï¼Œäº†è§£',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 15:00:00','2026-03-06 17:16:43',0),(167,31,1,2,'å¥½ä¹…ä¸è§ï¼Œæœ€è¿‘æ€Žä¹ˆæ ·ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 12:00:00','2026-03-06 17:16:43',0),(168,31,2,1,'æŒºå¥½çš„ï¼Œä½ å‘¢ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 12:10:00','2026-03-06 17:16:43',0),(169,31,1,2,'æˆ‘ä¹Ÿä¸é”™ï¼Œæœ€è¿‘åœ¨å¿™ä»€ä¹ˆï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 12:20:00','2026-03-06 17:16:43',0),(170,32,18,19,'æ˜Žå¤©ä¸€èµ·åŽ»å›¾ä¹¦é¦†å§',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 11:30:00','2026-03-06 17:16:43',0),(171,32,19,18,'å¥½çš„ï¼Œå‡ ç‚¹ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 11:40:00','2026-03-06 17:16:43',0),(172,32,18,19,'ä¸Šåˆ9ç‚¹æ€Žä¹ˆæ ·ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 11:50:00','2026-03-06 17:16:43',0),(173,32,19,18,'å¥½çš„',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 11:55:00','2026-03-06 17:16:43',0),(174,33,20,21,'æ™šä¸Šä¸€èµ·åƒé¥­å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 18:00:00','2026-03-06 17:16:43',0),(175,33,21,20,'å¥½å•Šï¼ŒåŽ»å“ªåƒï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 18:10:00','2026-03-06 17:16:43',0),(176,33,20,21,'å—åŒºé£Ÿå ‚æ€Žä¹ˆæ ·ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 18:15:00','2026-03-06 17:16:43',0),(177,33,21,20,'å¯ä»¥ï¼Œ6ç‚¹è§',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 18:20:00','2026-03-06 17:16:43',0),(178,34,22,23,'æ–‡ä»¶å‘ä½ é‚®ç®±äº†',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 14:00:00','2026-03-06 17:16:43',0),(179,34,23,22,'å¥½çš„ï¼Œæ”¶åˆ°',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 14:00:00','2026-03-06 17:16:43',0),(180,35,24,25,'è°¢è°¢ä½ å¸®æˆ‘',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 16:00:00','2026-03-06 17:16:43',0),(181,35,25,24,'ä¸å®¢æ°”',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 16:00:00','2026-03-06 17:16:43',0),(200,100,9,18,'ä½ å¥½ï¼Œçœ‹åˆ°ä½ çš„å•†å“äº†',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 10:00:00','2026-03-06 17:36:55',0),(201,100,18,9,'ä½ å¥½ï¼Œéœ€è¦ä»€ä¹ˆå—ï¼Ÿ',1,NULL,1,'2026-03-06 18:48:37',0,NULL,NULL,0,1,'2026-03-06 10:05:00','2026-03-06 18:48:37',0),(202,100,9,18,'é‚£ä¸ªiPhoneè¿˜åœ¨å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 10:10:00','2026-03-06 17:36:55',0),(203,101,9,19,'è¯·é—®è¿™ä¸ªè¿˜åœ¨å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 09:30:00','2026-03-06 17:36:55',0),(204,101,19,9,'åœ¨çš„ï¼Œä½ éœ€è¦å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 09:35:00','2026-03-06 17:36:55',0),(205,102,9,20,'å¤šå°‘é’±ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 20:00:00','2026-03-06 17:36:55',0),(206,102,20,9,'299å…ƒ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 20:10:00','2026-03-06 17:36:55',0),(207,102,9,20,'å¯ä»¥ä¾¿å®œç‚¹å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 20:15:00','2026-03-06 17:36:55',0),(208,102,20,9,'æœ€ä½Ž280',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 20:20:00','2026-03-06 17:36:55',0),(209,103,1,9,'ä½ å¥½å•Šï¼Œå¥½ä¹…ä¸è§',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 18:00:00','2026-03-06 17:36:55',0),(210,103,9,1,'æ˜¯å•Šï¼Œæœ€è¿‘æ€Žä¹ˆæ ·ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 18:10:00','2026-03-06 17:36:55',0),(211,103,1,9,'æŒºå¥½çš„ï¼Œåœ¨å¿™ä»€ä¹ˆï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 18:15:00','2026-03-06 17:36:55',0),(212,103,9,1,'åœ¨å‡†å¤‡è€ƒè¯•å‘¢',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 18:20:00','2026-03-06 17:36:55',0),(213,104,9,21,'å¥½çš„ï¼Œæˆ‘çŸ¥é“äº†',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 16:00:00','2026-03-06 17:36:55',0),(214,104,21,9,'å¥½çš„ï¼Œåˆ°æ—¶å€™è§',1,NULL,1,'2026-03-06 18:48:11',0,NULL,NULL,0,1,'2026-03-05 16:10:00','2026-03-06 18:48:11',0),(215,105,9,22,'ä»€ä¹ˆæ—¶å€™æ–¹ä¾¿äº¤æ˜“ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 14:30:00','2026-03-06 17:36:55',0),(216,105,22,9,'ä¸‹åˆ3ç‚¹æ€Žä¹ˆæ ·ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 14:40:00','2026-03-06 17:36:55',0),(217,105,9,22,'å¥½çš„ï¼Œæ²¡é—®é¢˜',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 14:50:00','2026-03-06 17:36:55',0),(218,106,2,9,'æ”¶åˆ°äº†ï¼Œè°¢è°¢ï¼',1,NULL,1,'2026-03-07 15:57:45',0,NULL,NULL,0,1,'2026-03-04 17:00:00','2026-03-07 15:57:44',0),(219,106,9,2,'ä¸å®¢æ°”',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 17:05:00','2026-03-06 17:36:55',0),(220,106,2,9,'ä¸‹æ¬¡åˆä½œ',1,NULL,1,'2026-03-07 15:57:45',0,NULL,NULL,0,1,'2026-03-04 17:10:00','2026-03-07 15:57:44',0),(221,107,9,23,'è¿™ä¸ªå¤šå°‘é’±ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 15:30:00','2026-03-06 17:36:55',0),(222,107,23,9,'150å…ƒ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 15:35:00','2026-03-06 17:36:55',0),(223,107,9,23,'å¥½çš„ï¼Œæˆäº¤',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-04 15:40:00','2026-03-06 17:36:55',0),(300,200,9,1,'ä½ å¥½ï¼Œçœ‹åˆ°ä½ çš„iPhoneäº†ï¼Œè¿˜åœ¨å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 11:00:00','2026-03-06 17:40:10',0),(301,200,1,9,'åœ¨çš„ï¼Œä½ éœ€è¦å—ï¼Ÿ',1,NULL,1,'2026-03-06 17:46:52',0,NULL,NULL,0,1,'2026-03-06 11:05:00','2026-03-06 17:46:51',0),(302,200,9,1,'æˆè‰²æ€Žä¹ˆæ ·ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 11:10:00','2026-03-06 17:40:10',0),(303,200,1,9,'99æ–°ï¼Œç›’è¯´å…¨',1,NULL,1,'2026-03-06 17:46:52',0,NULL,NULL,0,1,'2026-03-06 11:15:00','2026-03-06 17:46:51',0),(304,200,9,1,'ä»·æ ¼å¯ä»¥å•†é‡å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 11:20:00','2026-03-06 17:40:10',0),(305,200,1,9,'æœ€ä½Ž5800',1,NULL,1,'2026-03-06 17:46:52',0,NULL,NULL,0,1,'2026-03-06 11:25:00','2026-03-06 17:46:51',0),(306,200,9,1,'å¥½çš„ï¼Œæˆ‘æƒ³è¦äº†',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 11:30:00','2026-03-06 17:40:10',0),(307,201,2,9,'ä½ å¥½ï¼Œä½ çš„MacBookè¿˜åœ¨å—ï¼Ÿ',1,NULL,1,'2026-03-06 17:55:45',0,NULL,NULL,0,1,'2026-03-06 10:30:00','2026-03-06 17:55:45',0),(308,201,9,2,'åœ¨çš„',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 10:35:00','2026-03-06 17:40:10',0),(309,201,2,9,'å¤šå°‘é’±ï¼Ÿ',1,NULL,1,'2026-03-06 17:55:45',0,NULL,NULL,0,1,'2026-03-06 10:40:00','2026-03-06 17:55:45',0),(310,201,9,2,'4500å…ƒ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 10:45:00','2026-03-06 17:40:10',0),(311,201,2,9,'å¯ä»¥ä¾¿å®œç‚¹å—ï¼Ÿ',1,NULL,1,'2026-03-06 17:55:45',0,NULL,NULL,0,1,'2026-03-06 10:50:00','2026-03-06 17:55:45',0),(312,201,9,2,'æœ€ä½Ž4400',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 10:55:00','2026-03-06 17:40:10',0),(313,201,2,9,'å¥½çš„ï¼Œæˆ‘æƒ³è¦äº†',1,NULL,1,'2026-03-06 17:55:45',0,NULL,NULL,0,1,'2026-03-06 11:00:00','2026-03-06 17:55:45',0),(314,202,9,3,'ä½ å¥½ï¼Œè‡ªè¡Œè½¦è¿˜åœ¨å—ï¼Ÿå¤šå°‘é’±ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 09:00:00','2026-03-06 17:40:10',0),(315,202,3,9,'åœ¨çš„ï¼Œ350å…ƒ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 09:10:00','2026-03-06 17:40:10',0),(316,202,9,3,'åœ¨å“ªé‡Œçœ‹è½¦ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 09:20:00','2026-03-06 17:40:10',0),(317,202,3,9,'åŒ—åŒºè½¦æ£š',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 09:30:00','2026-03-06 17:40:10',0),(318,202,9,3,'å¥½çš„ï¼Œä¸‹åˆåŽ»çœ‹çœ‹',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-06 09:40:00','2026-03-06 17:40:10',0),(319,203,4,9,'ä½ å¥½ï¼Œçœ‹åˆ°ä½ çš„MacBookäº†',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 14:00:00','2026-03-06 17:40:10',0),(320,203,9,4,'ä½ å¥½ï¼Œåœ¨çš„',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 14:10:00','2026-03-06 17:40:10',0),(321,203,4,9,'å¤šå°‘é’±ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 14:20:00','2026-03-06 17:40:10',0),(322,203,9,4,'4500å…ƒ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 14:30:00','2026-03-06 17:40:10',0),(323,203,4,9,'4300å¯ä»¥å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 14:40:00','2026-03-06 17:40:10',0),(324,203,9,4,'å¥½çš„ï¼Œ4300æˆäº¤',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 14:50:00','2026-03-06 17:40:10',0),(325,203,4,9,'å¥½çš„ï¼Œæˆ‘è¦äº†ï¼Œæ€Žä¹ˆäº¤æ˜“ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 16:00:00','2026-03-06 17:40:10',0),(326,203,9,4,'ä»€ä¹ˆæ—¶å€™æ–¹ä¾¿ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 16:10:00','2026-03-06 17:40:10',0),(327,203,4,9,'çŽ°åœ¨å¯ä»¥å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 16:20:00','2026-03-06 17:40:10',0),(328,203,9,4,'å¥½çš„ï¼Œå—åŒºå®¿èˆè§',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 16:30:00','2026-03-06 17:40:10',0),(329,204,9,5,'ä½ å¥½ï¼ŒiPadè¿˜åœ¨å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 15:00:00','2026-03-06 17:40:10',0),(330,204,5,9,'åœ¨çš„',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 15:10:00','2026-03-06 17:40:10',0),(331,205,6,9,'ä½ çš„MacBookå¯ä»¥ä¾¿å®œç‚¹å—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 14:00:00','2026-03-06 17:40:10',0),(332,205,9,6,'æœ€ä½Žå¤šå°‘ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 14:10:00','2026-03-06 17:40:10',0),(333,205,6,9,'4400è¡Œå—ï¼Ÿ',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 14:15:00','2026-03-06 17:40:10',0),(334,205,9,6,'å¯ä»¥',1,NULL,0,NULL,0,NULL,NULL,0,1,'2026-03-05 14:20:00','2026-03-06 17:40:10',0),(335,200,9,1,'{\"id\":100,\"title\":\"äºŒæ‰‹ MacBook Pro 13å¯¸ M1èŠ¯ç‰‡\",\"price\":4500,\"image\":\"/uploads/products/100-macbook-1.jpg\"}',3,NULL,0,NULL,1,NULL,NULL,0,2,'2026-03-06 22:05:33','2026-03-07 17:12:22',0),(336,200,9,1,'http://localhost:8080/api/image/fa665e20-16c3-4c72-a671-e9cc5b077b5c.png',2,NULL,0,NULL,1,NULL,NULL,0,2,'2026-03-06 22:05:39','2026-03-07 17:12:22',0),(337,200,9,1,'http://localhost:8080/api/image/33647b4d-26fc-4c0a-b675-3f6a8620415e.png',2,NULL,0,NULL,1,NULL,NULL,0,2,'2026-03-06 22:06:56','2026-03-07 17:12:22',0),(338,200,9,1,'asd',1,NULL,0,NULL,1,NULL,NULL,0,2,'2026-03-06 22:15:46','2026-03-07 17:12:22',0),(339,200,9,1,'{\"id\":100,\"title\":\"äºŒæ‰‹ MacBook Pro 13å¯¸ M1èŠ¯ç‰‡\",\"price\":4500,\"image\":\"/uploads/products/100-macbook-1.jpg\"}',3,NULL,0,NULL,1,NULL,NULL,0,2,'2026-03-06 22:24:40','2026-03-07 17:12:22',0),(340,200,9,1,'http://localhost:8080/api/image/7e1a3d17-7979-4fd9-9127-e3cd1433036e.png',2,NULL,0,NULL,1,NULL,NULL,0,2,'2026-03-06 22:24:44','2026-03-07 17:12:22',0),(341,206,34,9,'hello',1,NULL,1,'2026-03-07 09:43:28',1,NULL,NULL,0,2,'2026-03-07 09:43:14','2026-03-07 14:36:43',0),(342,206,34,9,'test',1,NULL,1,'2026-03-07 09:43:42',1,NULL,NULL,0,2,'2026-03-07 09:43:35','2026-03-07 14:36:43',0),(343,206,34,9,'你好',1,NULL,1,'2026-03-07 09:43:42',1,NULL,NULL,0,2,'2026-03-07 09:43:39','2026-03-07 14:36:43',0),(344,206,9,34,'{\"id\":100,\"title\":\"äºŒæ‰‹ MacBook Pro 13å¯¸ M1èŠ¯ç‰‡\",\"price\":4500,\"image\":null}',3,NULL,1,'2026-03-07 09:49:06',1,NULL,NULL,0,2,'2026-03-07 09:49:06','2026-03-07 14:36:43',0),(345,206,34,9,'312、',1,NULL,1,'2026-03-07 09:49:19',1,NULL,NULL,0,2,'2026-03-07 09:49:19','2026-03-07 14:36:43',0),(346,206,34,9,'介绍下',1,NULL,1,'2026-03-07 09:49:27',1,NULL,NULL,0,2,'2026-03-07 09:49:27','2026-03-07 14:36:43',0),(347,206,9,34,'3123',1,NULL,1,'2026-03-07 09:49:31',1,NULL,NULL,0,2,'2026-03-07 09:49:31','2026-03-07 14:36:43',0),(348,206,34,9,'3213',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 09:54:26','2026-03-07 14:36:43',0),(349,206,34,9,'asd',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 09:57:14','2026-03-07 14:36:43',0),(350,206,34,9,'ds',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 09:57:18','2026-03-07 14:36:43',0),(351,206,34,9,'dsda',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 09:57:22','2026-03-07 14:36:43',0),(352,206,34,9,'3213\nasd',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:00:22','2026-03-07 14:36:43',0),(353,206,34,9,'hello world\nthis\n',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:00:30','2026-03-07 14:36:43',0),(354,206,34,9,'http://localhost:8080/api/image/e0f924f6-dc42-4352-8f2a-1acfdbe9b6a3.png',2,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:00:42','2026-03-07 14:36:43',0),(355,206,34,9,'32',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:18:52','2026-03-07 14:36:43',0),(356,206,34,9,'http://localhost:8080/api/image/2e05144e-7242-460d-91d9-070e5e8f937b.png',2,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:19:01','2026-03-07 14:36:43',0),(357,206,34,9,'3',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:19:33','2026-03-07 14:36:43',0),(358,206,34,9,'2',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:19:35','2026-03-07 14:36:43',0),(359,206,34,9,'3\n',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:24:41','2026-03-07 14:36:43',0),(360,206,34,9,'3123',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:24:45','2026-03-07 14:36:43',0),(361,206,34,9,'http://localhost:8080/api/image/a6013a5e-002c-4110-a661-13868e096d44.png',2,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:27:35','2026-03-07 14:36:43',0),(362,206,34,9,'http://localhost:8080/api/image/7def2643-d271-4334-8eae-91c33586c0c5.png',2,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:27:43','2026-03-07 14:36:43',0),(363,206,34,9,'2\n',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:30:05','2026-03-07 14:36:43',0),(364,206,34,9,'3',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:30:08','2026-03-07 14:36:43',0),(365,206,34,9,'1',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:30:48','2026-03-07 14:36:43',0),(366,206,34,9,'44',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:31:19','2026-03-07 14:36:43',0),(367,206,34,9,'1\n',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:33:04','2026-03-07 14:36:43',0),(368,206,34,9,'2\n',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:33:07','2026-03-07 14:36:43',0),(369,206,34,9,'33',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:33:10','2026-03-07 14:36:43',0),(370,206,34,9,'123123',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:33:29','2026-03-07 14:36:43',0),(371,206,34,9,'3123123',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:33:34','2026-03-07 14:36:43',0),(372,206,34,9,'312313\n32232\n3223',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:33:41','2026-03-07 14:36:43',0),(373,206,34,9,'http://localhost:8080/api/image/19cf06f7-7599-4276-80ca-81781ad57e9d.png',2,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:33:47','2026-03-07 14:36:43',0),(374,206,34,9,'http://localhost:8080/api/image/87948987-ece2-4e01-80ac-7fd6ebd6ec7a.png',2,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:34:27','2026-03-07 14:36:43',0),(375,206,34,9,'3123\n',1,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:40:20','2026-03-07 14:36:43',0),(376,206,34,9,'http://localhost:8080/api/image/257a0e80-f399-442a-964b-85c3cc09cbc5.png',2,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:40:24','2026-03-07 14:36:43',0),(377,206,34,9,'http://localhost:8080/api/image/e31eddfe-42f0-4de9-b6d7-62a7ac560c09.png',2,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:49:15','2026-03-07 14:36:43',0),(378,206,34,9,'http://localhost:8080/api/image/1d19eaa5-1618-4408-8969-937364f1e0aa.png',2,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:50:03','2026-03-07 14:36:43',0),(379,206,34,9,'http://localhost:8080/api/image/1576d97c-aa70-4028-a061-482f29ab43d4.png',2,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:50:23','2026-03-07 14:36:43',0),(380,206,34,9,'http://localhost:8080/api/image/dbc44e33-247e-490b-84c7-35fd63977fef.png',2,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:55:14','2026-03-07 14:36:43',0),(381,206,34,9,'http://localhost:8080/api/image/630f13e1-c603-480b-9046-b62bad7c7aa0.png',2,NULL,1,'2026-03-07 11:12:08',1,NULL,NULL,0,2,'2026-03-07 10:58:17','2026-03-07 14:36:43',0),(382,206,9,34,'http://localhost:8080/api/image/1aa9dd31-2fc5-4d85-a77a-14376449f858.png',2,NULL,1,'2026-03-07 11:12:27',1,NULL,NULL,0,2,'2026-03-07 11:12:27','2026-03-07 14:36:43',0),(383,206,9,34,'http://localhost:8080/api/image/d92ca346-2321-4f7c-acc1-736d40fac77c.png',2,NULL,1,'2026-03-07 11:23:10',1,NULL,NULL,0,2,'2026-03-07 11:23:10','2026-03-07 14:36:43',0),(384,206,9,34,'http://localhost:8080/api/image/69743f67-ae63-48c8-8cd9-668dc4eba913.png',2,NULL,1,'2026-03-07 11:25:41',1,NULL,NULL,0,2,'2026-03-07 11:25:41','2026-03-07 14:36:43',0),(385,206,9,34,'1\n2\n',1,NULL,1,'2026-03-07 11:32:31',1,NULL,NULL,0,2,'2026-03-07 11:32:31','2026-03-07 14:36:43',0),(386,206,34,9,'2',1,NULL,1,'2026-03-07 11:32:48',1,NULL,NULL,0,2,'2026-03-07 11:32:48','2026-03-07 14:36:43',0),(387,206,9,34,'3',1,NULL,1,'2026-03-07 11:34:13',1,NULL,NULL,0,2,'2026-03-07 11:34:13','2026-03-07 14:36:43',0),(388,206,9,34,'http://localhost:8080/api/image/59721e5d-68b1-4c72-b3d8-c4487b94ffd4.png',2,NULL,1,'2026-03-07 11:34:20',1,NULL,NULL,0,2,'2026-03-07 11:34:20','2026-03-07 14:36:43',0),(389,206,9,34,'123\n',1,NULL,1,'2026-03-07 11:40:30',1,NULL,NULL,0,2,'2026-03-07 11:40:30','2026-03-07 14:36:43',0),(390,206,9,34,'/image/2b66976f-0093-4593-b5f0-16f7cf082959.png',2,NULL,1,'2026-03-07 11:40:36',1,NULL,NULL,0,2,'2026-03-07 11:40:36','2026-03-07 14:36:43',0),(391,206,9,34,'/image/3151815e-98de-4696-9f42-4daac88d8251.png',2,NULL,1,'2026-03-07 11:42:28',1,NULL,NULL,0,2,'2026-03-07 11:42:28','2026-03-07 14:36:43',0),(392,206,9,34,'http://localhost:8080/api/image/c40f8529-4d21-4c12-88eb-8ad6db05b051.png',2,NULL,1,'2026-03-07 11:43:01',1,NULL,NULL,0,2,'2026-03-07 11:43:01','2026-03-07 14:36:43',0),(393,206,9,34,'2',1,NULL,1,'2026-03-07 11:56:19',1,NULL,NULL,0,2,'2026-03-07 11:56:19','2026-03-07 14:36:43',0),(394,206,9,34,'22',1,NULL,1,'2026-03-07 11:56:31',1,NULL,NULL,0,2,'2026-03-07 11:56:31','2026-03-07 14:36:43',0),(395,206,34,9,'3',1,NULL,1,'2026-03-07 11:58:39',1,NULL,NULL,0,2,'2026-03-07 11:58:39','2026-03-07 14:36:43',0),(396,206,34,9,'4',1,NULL,1,'2026-03-07 11:58:55',1,NULL,NULL,0,2,'2026-03-07 11:58:55','2026-03-07 14:36:43',0),(397,206,34,9,'2\n',1,NULL,1,'2026-03-07 13:07:42',1,NULL,NULL,0,2,'2026-03-07 13:07:42','2026-03-07 14:36:43',0),(398,206,9,34,'21',1,NULL,1,'2026-03-07 13:28:03',1,NULL,NULL,0,2,'2026-03-07 13:28:03','2026-03-07 14:36:43',0),(399,206,9,34,'22\n\n',1,NULL,1,'2026-03-07 13:28:16',1,NULL,NULL,0,2,'2026-03-07 13:28:16','2026-03-07 14:36:43',0),(400,206,9,34,'http://localhost:8080/api/image/768193a4-5544-4a7f-9049-32ccbe70bb62.png',2,NULL,1,'2026-03-07 13:28:28',1,NULL,NULL,0,2,'2026-03-07 13:28:27','2026-03-07 14:36:43',0),(401,206,9,34,'33\n',1,NULL,1,'2026-03-07 13:31:58',1,NULL,NULL,0,2,'2026-03-07 13:31:58','2026-03-07 14:36:43',0),(402,206,9,34,'http://localhost:8080/api/image/462b09d4-bd63-4509-ba4b-a53918eef490.png',2,NULL,1,'2026-03-07 13:32:01',1,NULL,NULL,0,2,'2026-03-07 13:32:01','2026-03-07 14:36:43',0),(403,206,9,34,'http://localhost:8080/api/image/e689e30f-0bf3-4212-ac48-702fe41a2f01.png',2,NULL,1,'2026-03-07 13:36:01',1,NULL,NULL,0,2,'2026-03-07 13:36:01','2026-03-07 14:36:43',0),(404,207,9,34,'hi\n',1,NULL,0,NULL,1,NULL,NULL,0,0,'2026-03-07 15:46:00','2026-03-07 15:46:00',0),(405,206,9,34,'{\"id\":100,\"title\":\"äºŒæ‰‹ MacBook Pro 13å¯¸ M1èŠ¯ç‰‡\",\"price\":4500,\"image\":null}',3,NULL,1,'2026-03-07 18:57:00',1,NULL,NULL,0,2,'2026-03-07 16:07:45','2026-03-07 18:56:59',0),(406,206,9,34,'{\"id\":100,\"title\":\"äºŒæ‰‹ MacBook Pro 13å¯¸ M1èŠ¯ç‰‡\",\"price\":4500,\"image\":null}',3,NULL,1,'2026-03-07 18:57:00',1,NULL,NULL,0,2,'2026-03-07 16:07:47','2026-03-07 18:56:59',0),(407,206,9,34,'{\"id\":100,\"title\":\"äºŒæ‰‹ MacBook Pro 13å¯¸ M1èŠ¯ç‰‡\",\"price\":4500,\"image\":null}',3,NULL,1,'2026-03-07 18:57:00',1,NULL,NULL,0,2,'2026-03-07 16:14:58','2026-03-07 18:56:59',0),(408,206,9,34,'http://localhost:8080/api/image/ac91dc4c-09b9-48bc-89b5-871deaa7d9e3.png',2,NULL,1,'2026-03-07 18:57:00',1,NULL,NULL,0,2,'2026-03-07 16:15:01','2026-03-07 18:56:59',0),(409,206,9,34,'http://localhost:8080/api/image/2de7fa6b-882e-498a-a44a-21ffa703d8ec.png',2,NULL,1,'2026-03-07 18:57:00',1,NULL,NULL,0,2,'2026-03-07 16:22:46','2026-03-07 18:56:59',0),(410,206,9,34,'http://localhost:8080/api/image/c6e5a8e1-7cd2-42ec-b70e-1bc496fc63ad.png',2,NULL,1,'2026-03-07 18:57:00',1,NULL,NULL,0,2,'2026-03-07 16:22:56','2026-03-07 18:56:59',0),(411,206,9,34,'http://localhost:8080/api/image/70d47a00-0cb2-4bd2-8db3-a9ed39923ade.png',2,NULL,1,'2026-03-07 18:57:00',1,NULL,NULL,0,2,'2026-03-07 16:23:04','2026-03-07 18:56:59',0),(412,206,9,34,'http://localhost:8080/api/image/6acd87fa-9ea3-4d13-a154-3991d28c16fb.png',2,NULL,1,'2026-03-07 18:57:00',1,NULL,NULL,0,2,'2026-03-07 16:23:13','2026-03-07 18:56:59',0),(413,206,9,34,'213\n',1,NULL,1,'2026-03-07 18:57:00',1,NULL,NULL,0,0,'2026-03-07 16:24:21','2026-03-07 18:56:59',0),(414,206,9,34,'http://localhost:8080/api/image/4a6fc113-10e1-4300-a76b-999ecc340b6c.png',2,NULL,1,'2026-03-07 18:57:00',1,NULL,NULL,0,0,'2026-03-07 16:24:25','2026-03-07 18:56:59',0),(415,206,9,34,'31\n',1,NULL,1,'2026-03-07 18:57:00',1,NULL,NULL,0,0,'2026-03-07 16:51:57','2026-03-07 18:56:59',0),(416,206,9,34,'http://localhost:8080/api/image/1d96c3c8-6980-44ec-ad95-2d6a5baacd94.png',2,NULL,1,'2026-03-07 18:57:00',1,NULL,NULL,0,0,'2026-03-07 16:51:59','2026-03-07 18:56:59',0),(417,206,9,34,'http://localhost:8080/api/image/b95ad769-1bde-4dd5-ad15-2b29428660e2.png',2,NULL,1,'2026-03-07 18:57:00',1,NULL,NULL,0,0,'2026-03-07 16:52:10','2026-03-07 18:56:59',0),(418,200,9,1,'test\n',1,NULL,0,NULL,1,NULL,NULL,0,2,'2026-03-07 16:52:25','2026-03-07 17:12:22',0),(419,200,9,1,'http://localhost:8080/api/image/c6bd5d84-c4e2-4d83-8abc-c87176860438.png',2,NULL,0,NULL,1,NULL,NULL,0,2,'2026-03-07 16:52:30','2026-03-07 17:12:22',0),(420,200,9,1,'123\n',1,NULL,0,NULL,1,NULL,NULL,0,2,'2026-03-07 16:57:47','2026-03-07 17:12:22',0),(421,200,9,1,'http://localhost:8080/api/image/5bcf99da-1016-44f2-82a6-9b085cb078df.png',2,NULL,0,NULL,1,NULL,NULL,0,2,'2026-03-07 16:57:49','2026-03-07 17:12:22',0),(422,200,9,1,'http://localhost:8080/api/image/95cd2a5c-b15c-4822-bfad-72aef8f2848c.png',2,NULL,0,NULL,1,NULL,NULL,0,2,'2026-03-07 17:09:35','2026-03-07 17:12:22',0),(423,200,9,1,'3123\n',1,NULL,0,NULL,1,NULL,NULL,0,0,'2026-03-07 17:12:28','2026-03-07 17:12:28',0),(424,200,9,1,'1\n',1,NULL,0,NULL,1,NULL,NULL,0,0,'2026-03-07 17:17:06','2026-03-07 17:17:06',0),(289761432776613165,289757411659620019,9,8,'2',1,NULL,1,'2026-03-23 17:39:41',1,NULL,NULL,0,0,'2026-03-10 22:08:29','2026-03-23 17:39:40',0),(289761471058026422,289757411659620019,9,8,'3',1,NULL,1,'2026-03-23 17:39:41',1,NULL,NULL,0,0,'2026-03-10 22:08:38','2026-03-23 17:39:40',0),(289762671828541260,201,9,2,'3',1,NULL,0,NULL,1,NULL,NULL,0,0,'2026-03-10 22:13:24','2026-03-10 22:13:24',0),(289762705512994284,289757411659620019,9,8,'\n1',1,NULL,1,'2026-03-23 17:39:41',1,NULL,NULL,0,0,'2026-03-10 22:13:33','2026-03-23 17:39:40',0),(289764767541891931,289757411659620019,9,8,'3',1,NULL,1,'2026-03-23 17:39:41',1,NULL,NULL,0,0,'2026-03-10 22:21:44','2026-03-23 17:39:40',0),(289764966112825831,289764955505432335,9,8,'1',1,NULL,1,'2026-03-10 22:40:48',1,NULL,NULL,0,0,'2026-03-10 22:22:31','2026-03-10 22:40:48',0),(289764971515091448,289764955505432335,9,8,'2',1,NULL,1,'2026-03-10 22:40:48',1,NULL,NULL,0,0,'2026-03-10 22:22:33','2026-03-10 22:40:48',0),(289768768773691707,289764955505432335,9,8,'123\n',1,NULL,1,'2026-03-10 22:40:48',1,NULL,NULL,0,0,'2026-03-10 22:37:38','2026-03-10 22:40:48',0),(289955152557905256,289764955505432335,9,8,'hello',1,NULL,1,'2026-03-23 17:39:38',1,NULL,NULL,0,0,'2026-03-11 10:58:15','2026-03-23 17:39:37',0),(289955209793377747,289764955505432335,9,8,'http://localhost:8080/api/image/25e17ec7-c166-4a52-b9ab-76451fafcc06.png',2,NULL,1,'2026-03-23 17:39:38',1,NULL,NULL,0,0,'2026-03-11 10:58:29','2026-03-23 17:39:37',0),(289984165649192322,289764955505432335,9,8,'1',1,NULL,1,'2026-03-23 17:39:38',1,NULL,NULL,0,0,'2026-03-11 12:53:33','2026-03-23 17:39:37',0),(289984170229373858,289764955505432335,9,8,'2',1,NULL,1,'2026-03-23 17:39:38',1,NULL,NULL,0,0,'2026-03-11 12:53:34','2026-03-23 17:39:37',0),(289999912630882989,289764955505432335,9,8,'http://localhost:8080/api/image/5314f117-9acb-4a87-a5ef-60709e006a9f.png',2,NULL,1,'2026-03-23 17:39:38',1,NULL,NULL,0,0,'2026-03-11 13:56:07','2026-03-23 17:39:37',0),(297251860560092977,289764955505432335,8,9,'111',1,NULL,0,NULL,1,NULL,NULL,0,0,'2026-03-31 14:12:46','2026-03-31 14:12:46',0),(297251874543899035,289764955505432335,8,9,'222',1,NULL,0,NULL,1,NULL,NULL,0,0,'2026-03-31 14:12:50','2026-03-31 14:12:50',0),(297251891480501036,289764955505432335,8,9,'http://localhost:8080/api/image/34d57dc1-bd19-42ee-9a3f-66ccfb5ae4f4.png',2,NULL,0,NULL,1,NULL,NULL,0,0,'2026-03-31 14:12:54','2026-03-31 14:12:54',0),(300274467505050097,289764955505432335,8,9,'123\n\n',1,NULL,0,NULL,1,NULL,NULL,0,0,'2026-04-08 22:23:32','2026-04-08 22:23:32',0),(301641100827955832,289764955505432335,8,9,'hello',1,NULL,0,NULL,1,NULL,NULL,0,0,'2026-04-12 16:54:03','2026-04-12 16:54:03',0);
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_read_records`
--

DROP TABLE IF EXISTS `notification_read_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_read_records` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'è®°å½•ID',
  `notification_id` bigint NOT NULL COMMENT 'é€šçŸ¥ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `read_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'é˜…è¯»æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_notification_user` (`notification_id`,`user_id`),
  KEY `idx_notification` (`notification_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_read_time` (`read_time`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é€šçŸ¥é˜…è¯»è®°å½•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_read_records`
--

LOCK TABLES `notification_read_records` WRITE;
/*!40000 ALTER TABLE `notification_read_records` DISABLE KEYS */;
INSERT INTO `notification_read_records` VALUES (1,3,9,'2026-03-05 01:00:32'),(2,1,9,'2026-03-05 01:00:42'),(3,2,9,'2026-03-05 01:00:42'),(5,3,34,'2026-03-07 09:16:09'),(6,1,34,'2026-03-07 09:26:17'),(7,2,34,'2026-03-07 09:26:17'),(9,1,8,'2026-03-10 20:52:32'),(10,2,8,'2026-03-10 20:52:32'),(11,3,8,'2026-03-10 20:52:32');
/*!40000 ALTER TABLE `notification_read_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation_log`
--

DROP TABLE IF EXISTS `operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation_log` (
  `log_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'æ—¥å¿—ID',
  `user_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ“ä½œç”¨æˆ·IDï¼Œ0è¡¨ç¤ºç³»ç»Ÿæ“ä½œ',
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç”¨æˆ·åï¼ˆå†—ä½™å­—æ®µï¼‰',
  `biz_id` bigint unsigned DEFAULT NULL COMMENT 'ä¸šåŠ¡å¯¹è±¡IDï¼ˆå¦‚è®¢å•IDã€å•†å“IDç­‰ï¼‰',
  `biz_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¸šåŠ¡å¯¹è±¡ç±»åž‹ï¼ˆå¦‚orderã€productç­‰ï¼‰',
  `module` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œæ¨¡å—ï¼šuser/product/order/share_item/systemç­‰',
  `action` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹ï¼šlogin/create/update/delete/query/exportç­‰',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ“ä½œæè¿°',
  `request_method` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è¯·æ±‚æ–¹æ³•ï¼šGET/POST/PUT/DELETE',
  `request_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è¯·æ±‚URL',
  `request_params` json DEFAULT NULL COMMENT 'è¯·æ±‚å‚æ•°ï¼ŒJSONæ ¼å¼',
  `response_result` json DEFAULT NULL COMMENT 'å“åº”ç»“æžœï¼ŒJSONæ ¼å¼',
  `ip_address` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'IPåœ°å€',
  `user_agent` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç”¨æˆ·ä»£ç†',
  `execute_time` bigint unsigned DEFAULT NULL COMMENT 'æ‰§è¡Œæ—¶é•¿ï¼ˆæ¯«ç§’ï¼‰',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'æ‰§è¡ŒçŠ¶æ€ï¼š1-æˆåŠŸ 0-å¤±è´¥',
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'é”™è¯¯ä¿¡æ¯ï¼ˆå¤±è´¥æ—¶è®°å½•ï¼‰',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'æ“ä½œæ—¶é—´',
  PRIMARY KEY (`log_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_module` (`module`),
  KEY `idx_action` (`action`),
  KEY `idx_create_time` (`create_time`),
  KEY `idx_ip_address` (`ip_address`),
  KEY `idx_biz_id` (`biz_id`),
  KEY `idx_biz_type` (`biz_type`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ“ä½œæ—¥å¿—è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation_log`
--

LOCK TABLES `operation_log` WRITE;
/*!40000 ALTER TABLE `operation_log` DISABLE KEYS */;
INSERT INTO `operation_log` VALUES (1,1,'zhangsan',NULL,NULL,'user','update_status','更新用户状态（封禁/解封）','PUT','/api/admin/user/status','{\"param0\": {\"reason\": \"313\", \"status\": 1, \"userId\": 288626339412582000}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',6,1,NULL,'2026-03-09 01:09:16'),(2,1,'zhangsan',NULL,NULL,'user','update_status','更新用户状态（封禁/解封）','PUT','/api/admin/user/status','{\"param0\": {\"reason\": \"\", \"status\": 0, \"userId\": 288626339412582000}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',9,1,NULL,'2026-03-09 01:09:28'),(3,1,'zhangsan',NULL,NULL,'share_item','update_status','更新共享物品状态','PUT','/api/admin/share-item/status','{\"param0\": {\"status\": 0, \"shareId\": 13}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',17,1,NULL,'2026-03-09 01:26:33'),(4,1,'zhangsan',NULL,NULL,'share_item','update_status','更新共享物品状态','PUT','/api/admin/share-item/status','{\"param0\": {\"status\": 1, \"shareId\": 13}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',9,1,NULL,'2026-03-09 01:26:35'),(5,0,'系统',NULL,NULL,'admin','login','管理员登录','POST','/api/admin/auth/login','{\"param0\": {\"password\": \"123456\", \"username\": \"admin\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',131,1,NULL,'2026-03-09 12:01:00'),(6,1,'zhangsan',NULL,NULL,'product_audit','audit','审核商品（通过/拒绝）','POST','/api/admin/product-audit/audit','{\"param0\": {\"productId\": 100, \"auditRemark\": \"\", \"auditStatus\": 1}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',34,1,NULL,'2026-03-09 12:18:47'),(7,1,'zhangsan',NULL,NULL,'share_item','update_status','更新共享物品状态','PUT','/api/admin/share-item/status','{\"param0\": {\"status\": 0, \"shareId\": 13}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',14,1,NULL,'2026-03-09 13:36:42'),(8,1,'zhangsan',NULL,NULL,'share_item','update_status','更新共享物品状态','PUT','/api/admin/share-item/status','{\"param0\": {\"status\": 1, \"shareId\": 13}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',11,1,NULL,'2026-03-09 13:36:44'),(9,1,'zhangsan',NULL,NULL,'auth','audit_student','审核学号认证','PUT','/api/admin/auth/student/audit','{\"param0\": {\"action\": \"approve\", \"authId\": 1}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',28,1,NULL,'2026-03-09 13:36:50'),(10,1,'zhangsan',NULL,NULL,'flash_sale','toggle_template','启用/禁用模板','PUT','/api/admin/flash-sale/template/1/toggle','{\"param0\": 1}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',12,1,NULL,'2026-03-09 13:39:43'),(11,1,'zhangsan',NULL,NULL,'flash_sale','toggle_template','启用/禁用模板','PUT','/api/admin/flash-sale/template/1/toggle','{\"param0\": 1}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',10,1,NULL,'2026-03-09 13:39:45'),(12,1,'zhangsan',NULL,NULL,'flash_sale','toggle_template','启用/禁用模板','PUT','/api/admin/flash-sale/template/2/toggle','{\"param0\": 2}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',9,1,NULL,'2026-03-09 13:39:46'),(13,1,'zhangsan',NULL,NULL,'flash_sale','toggle_template','启用/禁用模板','PUT','/api/admin/flash-sale/template/2/toggle','{\"param0\": 2}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',8,1,NULL,'2026-03-09 13:39:48'),(14,1,'zhangsan',NULL,NULL,'flash_sale','save_template','保存场次模板','POST','/api/admin/flash-sale/template','{\"param0\": {\"name\": \"早场\", \"isEnabled\": 1, \"sortOrder\": 1, \"templateId\": 1, \"updateTime\": \"2026-03-09T13:39:51.385413\", \"sessionTime\": \"08:00\", \"durationHours\": 3}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',8,1,NULL,'2026-03-09 13:39:51'),(15,1,'zhangsan',NULL,NULL,'feedback','handle','处理用户反馈','PUT','/api/admin/feedback/handle','{\"param0\": 2, \"param1\": \"asd test\"}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',21,1,NULL,'2026-03-09 13:49:16'),(16,1,'zhangsan',NULL,NULL,'report','handle','处理举报','PUT','/api/admin/report/1/handle','{\"param0\": 1, \"param1\": \"4\"}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',11,1,NULL,'2026-03-09 13:51:38'),(17,1,'zhangsan',NULL,NULL,'blacklist','delete','删除黑名单记录','DELETE','/api/admin/blacklist/1','{\"param0\": 1}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',28,1,NULL,'2026-03-09 13:51:53'),(18,1,'zhangsan',NULL,NULL,'blacklist','delete','删除黑名单记录','DELETE','/api/admin/blacklist/2','{\"param0\": 2}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',7,1,NULL,'2026-03-09 13:52:01'),(19,1,'zhangsan',NULL,NULL,'upload','upload','上传图片','POST','/api/admin/upload/image','{\"param0\": \"org.springframework.web.multipart.support.StandardMultipartHttpServletRequest$StandardMultipartFile@3e23fd5d\"}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',15,1,NULL,'2026-03-09 14:16:21'),(20,1,'zhangsan',NULL,NULL,'banner','update','更新轮播图','PUT','/api/admin/banner','{\"param0\": {\"title\": \"新用户注册送积分\", \"status\": 1, \"endTime\": \"2026-03-27T00:00:00\", \"linkUrl\": \"https://www.baidu.com\", \"bannerId\": 1, \"imageUrl\": \"http://localhost:8080/api/image/565d4a0d-7004-4716-bec7-419894f7c74c.png\", \"linkType\": 2, \"sortOrder\": 1, \"startTime\": \"2026-03-19T00:00:00\", \"imageThumbnailUrl\": \"http://localhost:8080/api/image/565d4a0d-7004-4716-bec7-419894f7c74c.png\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',23,1,NULL,'2026-03-09 14:19:57'),(21,1,'zhangsan',NULL,NULL,'category','update','更新分类','PUT','/api/admin/category','{\"param0\": {\"code\": \"other\", \"icon\": \"digital\", \"name\": \"数码电子\", \"status\": 1, \"gradient\": \"linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)\", \"parentId\": 2, \"sortOrder\": 1, \"categoryId\": 1, \"updateTime\": \"2026-03-09T14:23:53.611341\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',12,1,NULL,'2026-03-09 14:23:54'),(22,1,'zhangsan',NULL,NULL,'category','update','更新分类','PUT','/api/admin/category','{\"param0\": {\"code\": \"other\", \"icon\": \"digital\", \"name\": \"数码电子\", \"status\": 1, \"gradient\": \"linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)\", \"sortOrder\": 1, \"categoryId\": 1, \"updateTime\": \"2026-03-09T14:24:05.375784\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',7,1,NULL,'2026-03-09 14:24:05'),(23,1,'zhangsan',NULL,NULL,'category','update','更新分类','PUT','/api/admin/category','{\"param0\": {\"code\": \"other\", \"icon\": \"digital\", \"name\": \"数码电子\", \"status\": 1, \"gradient\": \"linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)\", \"sortOrder\": 1, \"categoryId\": 1, \"updateTime\": \"2026-03-09T14:26:04.953992\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',15,1,NULL,'2026-03-09 14:26:05'),(24,1,'zhangsan',NULL,NULL,'category','update','更新分类','PUT','/api/admin/category','{\"param0\": {\"code\": \"other\", \"icon\": \"digital\", \"name\": \"数码电子\", \"status\": 1, \"gradient\": \"linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)\", \"sortOrder\": 1, \"categoryId\": 1, \"updateTime\": \"2026-03-09T14:26:12.146248\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',12,1,NULL,'2026-03-09 14:26:12'),(25,1,'zhangsan',NULL,NULL,'category','update','更新分类','PUT','/api/admin/category','{\"param0\": {\"code\": \"other\", \"icon\": \"digital\", \"name\": \"数码电子\", \"status\": 1, \"gradient\": \"linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)\", \"sortOrder\": 1, \"categoryId\": 1, \"updateTime\": \"2026-03-09T14:27:29.168465\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',11,1,NULL,'2026-03-09 14:27:29'),(26,1,'zhangsan',NULL,NULL,'category','update','更新分类','PUT','/api/admin/category','{\"param0\": {\"code\": \"other\", \"icon\": \"digital\", \"name\": \"数码电子\", \"status\": 1, \"gradient\": \"linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)\", \"sortOrder\": 1, \"categoryId\": 1, \"updateTime\": \"2026-03-09T14:32:26.605483\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',22,1,NULL,'2026-03-09 14:32:27'),(27,1,'zhangsan',NULL,NULL,'category','update','更新分类','PUT','/api/admin/category','{\"param0\": {\"code\": \"other\", \"icon\": \"digital\", \"name\": \"数码电子\", \"status\": 1, \"gradient\": \"linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)\", \"parentId\": 0, \"sortOrder\": 1, \"categoryId\": 1, \"updateTime\": \"2026-03-09T14:35:19.482027\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',18,1,NULL,'2026-03-09 14:35:19'),(28,1,'zhangsan',NULL,NULL,'sensitive_word','update','更新敏感词','PUT','/api/admin/sensitive-word','{\"param0\": {\"type\": 2, \"word\": \"欺诈\", \"level\": 2, \"status\": 1, \"wordId\": 1, \"updateTime\": \"2026-03-09T14:37:08.726172\", \"replaceWord\": \"\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',12,1,NULL,'2026-03-09 14:37:09'),(29,1,'zhangsan',NULL,NULL,'sensitive_word','update','更新敏感词','PUT','/api/admin/sensitive-word','{\"param0\": {\"type\": 1, \"word\": \"欺诈\", \"level\": 2, \"status\": 1, \"wordId\": 1, \"updateTime\": \"2026-03-09T14:37:13.601948\", \"replaceWord\": \"\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',5,1,NULL,'2026-03-09 14:37:14'),(30,1,'zhangsan',NULL,NULL,'sensitive_word','create','创建敏感词','POST','/api/admin/sensitive-word','{\"param0\": {\"type\": 1, \"word\": \"231\", \"level\": 1, \"status\": 1, \"wordId\": 14, \"deleted\": 0, \"createTime\": \"2026-03-09T15:01:42.855992\", \"updateTime\": \"2026-03-09T15:01:42.856021\", \"replaceWord\": \"\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',23,1,NULL,'2026-03-09 15:01:43'),(31,1,'zhangsan',NULL,NULL,'sensitive_word','delete','删除敏感词','DELETE','/api/admin/sensitive-word/14','{\"param0\": 14}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',28,1,NULL,'2026-03-09 15:01:48'),(32,1,'zhangsan',NULL,NULL,'sensitive_word','import','批量导入敏感词','POST','/api/admin/sensitive-word/import','{\"param0\": {\"type\": 1, \"level\": 1, \"words\": [\"3123\", \"tesss\", \"asd\"]}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',26,1,NULL,'2026-03-09 15:10:52'),(33,1,'zhangsan',NULL,NULL,'sensitive_word','delete','删除敏感词','DELETE','/api/admin/sensitive-word/15','{\"param0\": 15}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',17,1,NULL,'2026-03-09 15:11:00'),(34,1,'zhangsan',NULL,NULL,'sensitive_word','delete','删除敏感词','DELETE','/api/admin/sensitive-word/16','{\"param0\": 16}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',12,1,NULL,'2026-03-09 15:11:01'),(35,1,'zhangsan',NULL,NULL,'sensitive_word','delete','删除敏感词','DELETE','/api/admin/sensitive-word/17','{\"param0\": 17}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',13,1,NULL,'2026-03-09 15:11:03'),(36,1,'zhangsan',NULL,NULL,'notification','update','更新系统通知','PUT','/api/admin/system-notification/1','{\"param0\": 1, \"param1\": {\"type\": 1, \"title\": \"欢迎使用闲七校园交易平台231\", \"content\": \"感谢您注册闲七，新用户注册送10积分！赶快发布你的第一个商品吧。\", \"updateTime\": \"2026-03-09T15:11:56.971871\", \"targetUsers\": \"all\", \"notificationId\": 1}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',70,0,'\n### Error updating database.  Cause: com.mysql.cj.jdbc.exceptions.MysqlDataTruncation: Data truncation: Invalid JSON text: \"Invalid value.\" at position 0 in value for column \'system_notification.target_users\'.\n### The error may exist in com/xx/xianqijava/mapper/SystemNotificationMapper.java (best guess)\n### The error may involve com.xx.xianqijava.mapper.SystemNotificationMapper.updateById-Inline\n### The error occurred while setting parameters\n### SQL: UPDATE system_notification  SET title=?, content=?, type=?,  target_users=?,            update_time=?  WHERE notification_id=? AND deleted=0\n### Cause: com.mysql.cj.jdbc.exceptions.MysqlDataTruncation: Data truncation: Invalid JSON text: \"Invalid value.\" at position 0 in value for column \'system_notification.target_users\'.\n; Data truncation: Invalid JSON text: \"Invalid value.\" at position 0 in value for column \'system_notification.target_users\'.','2026-03-09 15:11:57'),(37,1,'zhangsan',NULL,NULL,'notification','update','更新系统通知','PUT','/api/admin/system-notification/1','{\"param0\": 1, \"param1\": {\"type\": 1, \"title\": \"欢迎使用闲七校园交易平台\", \"content\": \"感谢您注册闲七，新用户注册送10积分！赶快发布你的第一个商品吧。3123\", \"updateTime\": \"2026-03-09T15:16:43.689233\", \"notificationId\": 1}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',17,1,NULL,'2026-03-09 15:16:44'),(38,1,'zhangsan',NULL,NULL,'flash_sale','create_temp_session','创建临时场次','POST','/api/admin/flash-sale/sessions/temporary','{\"param0\": {\"name\": \"3123\", \"endTime\": \"2026-03-25 00:00:00\", \"sessionId\": 289300035559100483, \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionTime\": \"15:34\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',16,1,NULL,'2026-03-09 15:35:03'),(39,1,'zhangsan',NULL,NULL,'flash_sale','batch_toggle_sessions','批量启用/禁用场次','PUT','/api/admin/flash-sale/sessions/batch-toggle','{\"param0\": {\"enabled\": 1}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',10,1,NULL,'2026-03-09 15:35:13'),(40,1,'zhangsan',NULL,NULL,'flash_sale','batch_toggle_sessions','批量启用/禁用场次','PUT','/api/admin/flash-sale/sessions/batch-toggle','{\"param0\": {\"enabled\": 0}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',11,1,NULL,'2026-03-09 15:35:14'),(41,1,'zhangsan',NULL,NULL,'flash_sale','batch_toggle_sessions','批量启用/禁用场次','PUT','/api/admin/flash-sale/sessions/batch-toggle','{\"param0\": {\"enabled\": 1}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',7,1,NULL,'2026-03-09 15:35:16'),(42,1,'zhangsan',NULL,NULL,'flash_sale','generate_sessions','生成今日场次','POST','/api/admin/flash-sale/sessions/generate','{}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',23,1,NULL,'2026-03-09 15:35:16'),(43,1,'zhangsan',NULL,NULL,'flash_sale','batch_toggle_sessions','批量启用/禁用场次','PUT','/api/admin/flash-sale/sessions/batch-toggle','{\"param0\": {\"enabled\": 1}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',7,1,NULL,'2026-03-09 15:35:18'),(44,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100500','{\"param0\": 289300035559100500, \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 10:00:00\", \"sessionId\": 289300035559100500, \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',4,1,NULL,'2026-03-09 15:53:54'),(45,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100500','{\"param0\": 289300035559100500, \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 01:00:00\", \"sessionId\": 289300035559100500, \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',21,1,NULL,'2026-03-09 15:54:26'),(46,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100500','{\"param0\": 289300035559100500, \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 15:00:00\", \"sessionId\": 289300035559100500, \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',3,1,NULL,'2026-03-09 16:08:02'),(47,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100500','{\"param0\": 289300035559100500, \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 15:00:00\", \"sessionId\": 289300035559100500, \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',3,1,NULL,'2026-03-09 16:13:06'),(48,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100500','{\"param0\": 289300035559100500, \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 15:00:00\", \"sessionId\": 289300035559100500, \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',6,1,NULL,'2026-03-09 16:13:20'),(49,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100500','{\"param0\": 289300035559100500, \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 15:00:00\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',10,1,NULL,'2026-03-09 16:16:17'),(50,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100500','{\"param0\": 289300035559100500, \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 15:00:00\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',7,1,NULL,'2026-03-09 16:20:33'),(51,1,'zhangsan',NULL,NULL,'flash_sale','delete_temp_session','删除临时场次','DELETE','/api/admin/flash-sale/sessions/temporary/289300035559100500','{\"param0\": 289300035559100500}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',4,1,NULL,'2026-03-09 16:20:38'),(52,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100500','{\"param0\": \"289300035559100500\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 15:00:00\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',3,1,NULL,'2026-03-09 16:27:27'),(53,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100500','{\"param0\": \"289300035559100500\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 15:00:00\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',8,1,NULL,'2026-03-09 16:27:52'),(54,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100500','{\"param0\": \"289300035559100500\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 15:00:00\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\"}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',7,1,NULL,'2026-03-09 16:30:55'),(55,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 15:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',16,1,NULL,'2026-03-09 16:34:12'),(56,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 09:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',15,1,NULL,'2026-03-09 16:34:16'),(57,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 04:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',12,1,NULL,'2026-03-09 16:34:41'),(58,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 04:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',8,1,NULL,'2026-03-09 16:36:01'),(59,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 04:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',7,1,NULL,'2026-03-09 16:36:17'),(60,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 04:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',7,1,NULL,'2026-03-09 16:36:33'),(61,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 15:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionTime\": \"00:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',18,1,NULL,'2026-03-09 16:43:52'),(62,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 15:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionTime\": \"00:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',8,1,NULL,'2026-03-09 16:43:56'),(63,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 16:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionTime\": \"00:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',10,1,NULL,'2026-03-09 16:45:25'),(64,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 16:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionTime\": \"00:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',8,1,NULL,'2026-03-09 16:45:31'),(65,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 16:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionTime\": \"00:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',7,1,NULL,'2026-03-09 16:49:38'),(66,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 16:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionTime\": \"00:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',6,1,NULL,'2026-03-09 16:56:03'),(67,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 16:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 00:00:00\", \"description\": \"123\", \"sessionTime\": \"00:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',20,1,NULL,'2026-03-09 16:56:07'),(68,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 15:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 01:00:00\", \"description\": \"123\", \"sessionTime\": \"01:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',17,1,NULL,'2026-03-09 17:00:27'),(69,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 11:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 01:00:00\", \"description\": \"123\", \"sessionTime\": \"01:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',12,1,NULL,'2026-03-09 17:00:32'),(70,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 06:00:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 01:00:00\", \"description\": \"123\", \"sessionTime\": \"01:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',10,1,NULL,'2026-03-09 17:15:43'),(71,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 15:59:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 01:00:00\", \"description\": \"123\", \"sessionTime\": \"01:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',14,1,NULL,'2026-03-09 17:15:57'),(72,1,'zhangsan',NULL,NULL,'feedback','handle','处理用户反馈','PUT','/api/admin/feedback/handle','{\"param0\": \"2\", \"param1\": \"123\"}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',72,1,NULL,'2026-03-09 17:34:02'),(73,1,'zhangsan',NULL,NULL,'feedback','handle','处理用户反馈','PUT','/api/admin/feedback/handle','{\"param0\": \"2\", \"param1\": \"12\"}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',11,1,NULL,'2026-03-09 17:34:05'),(74,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 10:59:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 01:00:00\", \"description\": \"123\", \"sessionTime\": \"01:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',30,1,NULL,'2026-03-09 17:35:21'),(75,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 10:59:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 01:00:00\", \"description\": \"123\", \"sessionTime\": \"01:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',11,1,NULL,'2026-03-09 17:43:41'),(76,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 04:59:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 01:00:00\", \"description\": \"123\", \"sessionTime\": \"01:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',9,1,NULL,'2026-03-09 17:43:50'),(77,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 14:59:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 01:00:00\", \"description\": \"123\", \"sessionTime\": \"01:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',13,1,NULL,'2026-03-09 17:46:00'),(78,1,'zhangsan',NULL,NULL,'flash_sale','update_temp_session','更新临时场次','PUT','/api/admin/flash-sale/sessions/temporary/289300035559100483','{\"param0\": \"289300035559100483\", \"param1\": {\"name\": \"3123\", \"endTime\": \"2026-03-06 18:59:00\", \"sessionId\": \"289300035559100483\", \"sortOrder\": 99, \"startTime\": \"2026-03-06 01:00:00\", \"description\": \"123\", \"sessionTime\": \"01:00\", \"sessionType\": 2}}',NULL,'0:0:0:0:0:0:0:1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',7,1,NULL,'2026-03-09 17:46:06'),(79,8,'测试用户',289664611152699290,'order','订单','创建订单','创建订单 202603101543450001','POST','/order',NULL,NULL,NULL,NULL,NULL,1,NULL,'2026-03-10 15:43:45'),(80,8,'测试用户',289750524650199795,'order','订单','创建订单','创建订单 202603102125080001','POST','/order',NULL,NULL,NULL,NULL,NULL,1,NULL,'2026-03-10 21:25:08'),(81,9,'test123',289750524650199795,'order','订单','确认订单','确认订单 202603102125080001','PUT','/order/289750524650199795/confirm',NULL,NULL,NULL,NULL,NULL,1,NULL,'2026-03-10 21:52:16'),(82,8,'测试用户',289750524650199795,'order','订单','完成订单','完成订单 202603102125080001','PUT','/order/289750524650199795/complete',NULL,NULL,NULL,NULL,NULL,1,NULL,'2026-03-10 22:41:00');
/*!40000 ALTER TABLE `operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation_log_backup`
--

DROP TABLE IF EXISTS `operation_log_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation_log_backup` (
  `id` bigint NOT NULL COMMENT '日志ID',
  `admin_id` bigint NOT NULL COMMENT '管理员ID',
  `admin_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '管理员用户名',
  `module` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '操作模块',
  `operation` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '操作类型',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '操作描述',
  `method` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '执行方法',
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '请求参数',
  `ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'IP地址',
  `location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'IP归属地',
  `browser` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '浏览器',
  `os` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '操作系统',
  `status` tinyint DEFAULT '1' COMMENT '状态 0-失败 1-成功',
  `error_msg` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '错误信息',
  `duration` bigint DEFAULT NULL COMMENT '执行耗时(毫秒)',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation_log_backup`
--

LOCK TABLES `operation_log_backup` WRITE;
/*!40000 ALTER TABLE `operation_log_backup` DISABLE KEYS */;
/*!40000 ALTER TABLE `operation_log_backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order` (
  `order_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '订单号',
  `buyer_id` bigint unsigned NOT NULL COMMENT '买家ID',
  `seller_id` bigint unsigned NOT NULL COMMENT '卖家ID',
  `product_id` bigint unsigned DEFAULT NULL COMMENT '商品ID',
  `share_id` bigint unsigned DEFAULT NULL COMMENT '共享物品ID',
  `type` tinyint unsigned NOT NULL COMMENT '类型：1-购买 2-共享',
  `order_type` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'è®¢å•ç±»åž‹ï¼š0-æ™®é€šè®¢å• 1-ç§’æ€è®¢å• 2-å…±äº«è®¢å• 3-æ‹å–è®¢å•',
  `amount` decimal(10,2) unsigned NOT NULL COMMENT '交易金额（元）',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0-待确认 1-进行中 2-已完成 3-已取消 4-退款中',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `ship_time` datetime DEFAULT NULL COMMENT '发货时间',
  `deliver_time` datetime DEFAULT NULL COMMENT '送达时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `finish_time` datetime DEFAULT NULL COMMENT '完成时间',
  `confirm_time` datetime DEFAULT NULL COMMENT 'ç¡®è®¤æ”¶è´§æ—¶é—´',
  `cancel_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '取消原因',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `idx_order_no` (`order_no`),
  KEY `idx_buyer_id` (`buyer_id`),
  KEY `idx_seller_id` (`seller_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_share_id` (`share_id`),
  KEY `idx_status` (`status`),
  KEY `idx_create_time` (`create_time`),
  KEY `idx_order_type` (`order_type`) COMMENT 'æŒ‰è®¢å•ç±»åž‹æŸ¥è¯¢',
  KEY `idx_order_pay_time` (`pay_time`),
  KEY `idx_order_ship_time` (`ship_time`),
  KEY `idx_order_deliver_time` (`deliver_time`),
  CONSTRAINT `fk_order_buyer` FOREIGN KEY (`buyer_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_order_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_order_seller` FOREIGN KEY (`seller_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_order_share` FOREIGN KEY (`share_id`) REFERENCES `share_item` (`share_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=289750524650199796 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,'ORD20250120001',2,1,NULL,NULL,1,0,5999.00,3,'下午3点后可以交易',NULL,NULL,NULL,'2025-01-20 10:00:00','2026-03-09 22:42:26',NULL,NULL,'超时未支付自动关闭',0),(2,'ORD20250119001',1,3,NULL,NULL,1,0,350.00,2,'周末面交',NULL,NULL,NULL,'2025-01-19 14:00:00','2026-03-10 00:53:12','2026-03-10 00:53:12',NULL,NULL,0),(3,'ORD20250118001',1,2,NULL,NULL,1,0,3200.00,2,NULL,NULL,NULL,NULL,'2025-01-18 10:00:00','2026-03-04 16:54:33','2025-01-19 10:00:00',NULL,NULL,0),(4,'ORD20250117001',2,4,NULL,NULL,1,0,299.00,3,NULL,NULL,NULL,NULL,'2025-01-17 11:00:00','2026-03-04 16:54:33','2025-01-18 11:00:00',NULL,NULL,0),(5,'ORD20250116001',3,1,NULL,NULL,1,0,899.00,3,'可以测试吗？',NULL,NULL,NULL,'2025-01-16 09:00:00','2026-03-09 22:42:26',NULL,NULL,'超时未支付自动关闭',0),(6,'ORD20250306001',9,1,NULL,NULL,1,0,5999.00,2,NULL,NULL,NULL,NULL,'2026-03-05 01:57:00','2026-03-06 13:42:24','2025-03-05 16:00:00',NULL,NULL,0),(7,'ORD20250306002',9,2,NULL,NULL,1,0,3200.00,2,NULL,NULL,NULL,NULL,'2026-03-04 01:57:00','2026-03-06 13:42:24','2025-03-04 15:00:00',NULL,NULL,0),(8,'ORD20250306003',9,3,NULL,NULL,1,0,350.00,2,NULL,NULL,NULL,NULL,'2026-03-03 01:57:00','2026-03-06 13:42:24','2025-03-03 14:00:00',NULL,NULL,0),(9,'ORD20250306007',1,9,NULL,NULL,1,0,350.00,2,NULL,NULL,NULL,NULL,'2025-02-20 10:00:00','2026-03-06 13:42:35','2025-02-22 14:00:00',NULL,NULL,0),(50,'ORD20260305001',4,9,NULL,NULL,1,0,4300.00,2,'å—åŒºå®¿èˆäº¤æ˜“',NULL,NULL,NULL,'2026-03-05 17:00:00','2026-03-13 22:08:24','2026-03-13 22:08:25',NULL,NULL,0),(51,'ORD20260306001',2,9,NULL,NULL,1,0,4400.00,3,'éœ€è¦å‘ç¥¨',NULL,NULL,NULL,'2026-03-06 11:30:00','2026-03-09 22:42:26',NULL,NULL,'超时未支付自动关闭',0),(100,'ORD20260309001',9,1,NULL,NULL,1,0,4500.00,3,'è¯·é—®å•†å“è¿˜åœ¨å—ï¼Ÿæƒ³è¦è¯¦ç»†äº†è§£ä¸€ä¸‹',NULL,NULL,NULL,'2026-03-09 10:00:00','2026-03-09 22:42:26',NULL,NULL,'超时未支付自动关闭',0),(101,'ORD20260309002',18,9,14,NULL,1,0,50.00,3,'æ–¹ä¾¿å¯„å¿«é€’å—ï¼Ÿ',NULL,NULL,NULL,'2026-03-09 11:30:00','2026-03-09 22:42:26',NULL,NULL,'超时未支付自动关闭',0),(102,'ORD20260308001',9,1,NULL,NULL,1,0,4500.00,2,'ä¸‹åˆ3ç‚¹åŽå¯ä»¥äº¤æ˜“','2026-03-08 14:00:00',NULL,NULL,'2026-03-08 13:50:00','2026-03-23 16:50:56','2026-03-23 16:50:56',NULL,NULL,0),(103,'ORD20260307001',18,9,14,NULL,1,0,50.00,2,'å‘¨æœ«é¢äº¤','2026-03-07 10:00:00','2026-03-07 16:00:00',NULL,'2026-03-07 09:55:00','2026-03-23 16:50:56','2026-03-23 16:50:56',NULL,NULL,0),(200,'ORD20260310001',9,1,NULL,NULL,1,0,4500.00,3,'è¯·é—®å•†å“è¿˜åœ¨å—ï¼Ÿ',NULL,NULL,NULL,'2026-03-09 21:08:34','2026-03-09 22:42:26',NULL,NULL,'超时未支付自动关闭',0),(201,'ORD20260310002',18,9,14,NULL,1,0,50.00,3,'æ–¹ä¾¿é¢äº¤å—ï¼Ÿ',NULL,NULL,NULL,'2026-03-09 21:08:42','2026-03-09 22:42:26',NULL,NULL,'超时未支付自动关闭',0),(202,'ORD20260310003',9,18,NULL,NULL,1,1,4200.00,3,'ç§’æ€å•†å“ï¼Œæƒ³è¦',NULL,NULL,NULL,'2026-03-09 21:08:42','2026-03-09 22:42:26',NULL,NULL,'超时未支付自动关闭',0),(203,'ORD20260310004',9,1,NULL,NULL,1,0,4500.00,2,'ä¸‹åˆ3ç‚¹åŽå¯ä»¥äº¤æ˜“','2026-03-09 19:08:42',NULL,NULL,'2026-03-09 18:08:42','2026-03-23 16:50:56','2026-03-23 16:50:56',NULL,NULL,0),(204,'ORD20260310005',18,9,14,NULL,1,0,50.00,2,'å‘¨æœ«é¢äº¤','2026-03-08 21:08:42',NULL,NULL,'2026-03-08 21:08:42','2026-03-23 16:50:56','2026-03-23 16:50:56',NULL,NULL,0),(205,'ORD20260310006',9,1,NULL,NULL,1,0,4500.00,2,'å•†å“è´¨é‡å¾ˆå¥½','2026-03-07 21:08:42',NULL,NULL,'2026-03-06 21:08:42','2026-03-07 21:08:42',NULL,NULL,NULL,0),(206,'ORD20260310007',18,9,14,NULL,1,0,50.00,3,'é¢äº¤å®Œæˆ','2026-03-06 21:08:42',NULL,NULL,'2026-03-05 21:08:42','2026-03-09 22:42:26',NULL,NULL,'超时未确认自动关闭',0),(207,'ORD20260310008',9,1,NULL,NULL,1,0,4500.00,3,'ä¸æƒ³ä¹°äº†',NULL,NULL,NULL,'2026-03-05 21:08:42','2026-03-05 21:08:42',NULL,NULL,NULL,0),(208,'ORD20260310009',9,1,NULL,NULL,1,0,4500.00,4,'å•†å“ä¸Žæè¿°ä¸ç¬¦','2026-03-04 21:08:42',NULL,NULL,'2026-03-04 21:08:42','2026-03-04 21:08:42',NULL,NULL,NULL,0),(289664611152699290,'202603101543450001',8,9,14,NULL,1,0,100.00,3,NULL,NULL,NULL,NULL,'2026-03-10 15:43:45','2026-03-10 16:14:35',NULL,NULL,'超时未确认自动关闭',0),(289750524650199795,'202603102125080001',8,9,14,NULL,1,0,100.00,2,NULL,NULL,NULL,NULL,'2026-03-10 21:25:08','2026-03-10 21:25:08','2026-03-10 22:41:00',NULL,NULL,0);
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `product_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '商品ID',
  `seller_id` bigint unsigned NOT NULL COMMENT '卖家ID',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“æ ‡é¢˜ï¼ˆè‰ç¨¿æ—¶å¯ç©ºï¼‰',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '商品描述',
  `category_id` int unsigned DEFAULT NULL COMMENT 'åˆ†ç±»IDï¼ˆè‰ç¨¿æ—¶å¯ä¸ºç©ºï¼‰',
  `price` decimal(10,2) unsigned DEFAULT NULL COMMENT 'ä»·æ ¼ï¼ˆå…ƒï¼‰',
  `original_price` decimal(10,2) unsigned DEFAULT NULL COMMENT '原价（元）',
  `condition_level` tinyint unsigned NOT NULL DEFAULT '9' COMMENT '成色：1-10，10为全新',
  `cover_image_id` bigint unsigned DEFAULT NULL COMMENT '封面图片ID',
  `image_count` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '图片数量',
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '交易地点',
  `latitude` decimal(10,7) DEFAULT NULL COMMENT '纬度',
  `longitude` decimal(10,7) DEFAULT NULL COMMENT '经度',
  `can_delivery` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'æ˜¯å¦æ”¯æŒé‚®å¯„ï¼š0-ä»…è‡ªæï¼Œ1-æ”¯æŒé‚®å¯„',
  `delivery_fee` decimal(10,2) unsigned DEFAULT NULL COMMENT 'é…é€è´¹ï¼ˆå…ƒï¼‰ï¼ŒNULLæˆ–0è¡¨ç¤ºåŒ…é‚®ï¼Œ>0è¡¨ç¤ºå…·ä½“è¿è´¹',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '状态：0-下架 1-在售 2-已售 3-预订',
  `view_count` int unsigned NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  `audit_status` tinyint unsigned DEFAULT '0' COMMENT '审核状态：0-待审核，1-审核通过，2-审核拒绝',
  `audit_remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核意见',
  `audit_time` datetime DEFAULT NULL COMMENT '审核时间',
  `auditor_id` bigint unsigned DEFAULT NULL COMMENT '审核人ID',
  PRIMARY KEY (`product_id`),
  KEY `idx_seller_id` (`seller_id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_status` (`status`),
  KEY `idx_price` (`price`),
  KEY `idx_create_time` (`create_time`),
  KEY `idx_location` (`location`(50)),
  FULLTEXT KEY `idx_title_desc` (`title`,`description`),
  CONSTRAINT `fk_product_seller` FOREIGN KEY (`seller_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=301717194650294589 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (12,9,'','',NULL,100.00,NULL,10,NULL,0,'第一食堂',0.0000000,0.0000000,0,NULL,2,0,'2026-03-04 17:52:17','2026-03-10 16:41:56',1,0,NULL,NULL,NULL),(13,9,'','',NULL,100.00,NULL,10,NULL,0,'第一食堂',NULL,NULL,0,NULL,1,0,'2026-03-04 22:35:29','2026-03-09 19:59:17',1,1,'','2026-03-09 01:04:38',1),(14,9,'asd\n','31399',2,100.00,NULL,10,NULL,0,'',0.0000000,0.0000000,1,NULL,0,183,'2026-03-04 22:36:00','2026-04-07 11:47:17',0,1,'','2026-03-09 01:04:02',1),(289957090963888537,9,'','',NULL,NULL,NULL,10,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-03-11 11:05:58','2026-03-11 11:05:58',0,0,NULL,NULL,NULL),(297253056062562090,8,'','',NULL,NULL,NULL,10,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-03-31 14:17:31','2026-04-12 15:30:03',1,0,NULL,NULL,NULL),(298882466805062182,8,'','',NULL,NULL,NULL,10,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-04-05 02:12:13','2026-04-12 15:30:03',1,0,NULL,NULL,NULL),(298882480147142501,8,'','',NULL,NULL,NULL,10,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-04-05 02:12:16','2026-04-12 15:30:03',1,0,NULL,NULL,NULL),(299054080557456463,8,'','',NULL,NULL,NULL,10,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-04-05 13:34:09','2026-04-12 15:30:03',1,0,NULL,NULL,NULL),(299143332070822249,8,'','',NULL,NULL,NULL,10,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-04-05 19:28:48','2026-04-12 15:30:03',1,0,NULL,NULL,NULL),(299181130207334993,8,'','',NULL,NULL,NULL,10,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-04-05 21:59:00','2026-04-12 15:30:03',1,0,NULL,NULL,NULL),(299379672674868109,8,'','',NULL,NULL,NULL,8,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-04-06 11:07:56','2026-04-12 15:30:03',1,0,NULL,NULL,NULL),(299382633975124032,8,'','',NULL,NULL,NULL,10,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-04-06 11:19:42','2026-04-12 15:30:03',1,0,NULL,NULL,NULL),(299382669584765663,8,'','',NULL,NULL,NULL,10,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-04-06 11:19:51','2026-04-12 15:30:03',1,0,NULL,NULL,NULL),(299382946186530850,8,'','',NULL,NULL,NULL,10,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-04-06 11:20:57','2026-04-12 15:30:03',1,0,NULL,NULL,NULL),(301693114198922866,8,'test','这是一个测试商品',1,50.00,222.00,10,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-04-12 20:20:44','2026-04-12 20:20:44',0,0,NULL,NULL,NULL),(301705222642866587,8,'test','test',2,500.00,3333.00,10,NULL,0,'',NULL,NULL,0,NULL,0,0,'2026-04-12 21:08:50','2026-04-12 21:08:51',0,0,NULL,NULL,NULL),(301705995997025844,8,'test','test',2,500.00,3333.00,10,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-04-12 21:11:55','2026-04-12 21:11:55',0,0,NULL,NULL,NULL),(301706034462989419,8,'','',NULL,NULL,NULL,10,NULL,0,'',NULL,NULL,0,NULL,4,0,'2026-04-12 21:12:04','2026-04-12 21:12:04',0,0,NULL,NULL,NULL),(301717099682862822,8,'test','123',1,100.00,NULL,10,NULL,0,'教学楼A栋',0.0000000,0.0000000,0,NULL,0,0,'2026-04-12 21:56:02','2026-04-12 21:56:02',0,0,NULL,NULL,NULL),(301717194650294588,8,'test','123',1,100.00,NULL,10,NULL,0,'教学楼A栋',0.0000000,0.0000000,0,NULL,4,0,'2026-04-12 21:56:25','2026-04-12 21:56:25',0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_favorite`
--

DROP TABLE IF EXISTS `product_favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_favorite` (
  `favorite_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '收藏ID',
  `user_id` bigint unsigned NOT NULL COMMENT '用户ID',
  `product_id` bigint unsigned NOT NULL COMMENT '商品ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '收藏时间',
  PRIMARY KEY (`favorite_id`),
  UNIQUE KEY `idx_user_product` (`user_id`,`product_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `fk_favorite_product` (`product_id`),
  CONSTRAINT `fk_favorite_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_favorite_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品收藏表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_favorite`
--

LOCK TABLES `product_favorite` WRITE;
/*!40000 ALTER TABLE `product_favorite` DISABLE KEYS */;
INSERT INTO `product_favorite` VALUES (55,8,14,'2026-03-10 13:19:39');
/*!40000 ALTER TABLE `product_favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_image`
--

DROP TABLE IF EXISTS `product_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_image` (
  `image_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '图片ID',
  `product_id` bigint unsigned NOT NULL COMMENT '商品ID',
  `image_uuid` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å›¾ç‰‡UUIDï¼ˆç”¨äºŽç”Ÿæˆè®¿é—®URLï¼‰',
  `file_extension` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ–‡ä»¶æ‰©å±•åï¼ˆå¦‚: jpg, pngï¼‰',
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图片URL',
  `image_thumbnail_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '缩略图URL',
  `image_medium_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '中等尺寸图片URL',
  `sort_order` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '排序顺序，数字越小越靠前',
  `file_size` int unsigned DEFAULT NULL COMMENT '文件大小（字节）',
  `width` smallint unsigned DEFAULT NULL COMMENT '图片宽度',
  `height` smallint unsigned DEFAULT NULL COMMENT '图片高度',
  `is_cover` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否为封面：0-否 1-是',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0-正常 1-已删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`image_id`),
  UNIQUE KEY `idx_image_uuid` (`image_uuid`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_is_cover` (`is_cover`),
  KEY `idx_sort_order` (`sort_order`),
  CONSTRAINT `fk_product_image_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=301717194713208210 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品图片表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_image`
--

LOCK TABLES `product_image` WRITE;
/*!40000 ALTER TABLE `product_image` DISABLE KEYS */;
INSERT INTO `product_image` VALUES (290028048819036043,14,NULL,NULL,'http://localhost:8080/api/image/7e5125c4-6ae4-499b-8a91-55ecdbc178d5.png',NULL,NULL,0,NULL,NULL,NULL,1,0,'2026-03-11 15:47:55'),(301693200182154837,301693114198922866,NULL,NULL,'http://localhost:8080/api/image/c81d8558-5b6c-49d5-83be-9e8b73b29af8.png',NULL,NULL,0,NULL,NULL,NULL,1,0,'2026-04-12 20:21:04'),(301705970244000760,301705222642866587,NULL,NULL,'http://localhost:8080/api/image/12c87db3-7969-4e26-8b6d-840484f22ecb.png',NULL,NULL,0,NULL,NULL,NULL,1,0,'2026-04-12 21:11:48'),(301706001751611328,301705995997025844,NULL,NULL,'http://localhost:8080/api/image/12c87db3-7969-4e26-8b6d-840484f22ecb.png',NULL,NULL,0,NULL,NULL,NULL,1,0,'2026-04-12 21:11:56'),(301717186211355958,301717099682862822,NULL,NULL,'http://localhost:8080/api/image/83895e6c-4132-4c29-9dff-132c44b47338.png',NULL,NULL,0,NULL,NULL,NULL,1,0,'2026-04-12 21:56:22'),(301717194713208209,301717194650294588,NULL,NULL,'http://localhost:8080/api/image/83895e6c-4132-4c29-9dff-132c44b47338.png',NULL,NULL,0,NULL,NULL,NULL,1,0,'2026-04-12 21:56:24');
/*!40000 ALTER TABLE `product_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_statistics`
--

DROP TABLE IF EXISTS `product_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_statistics` (
  `product_id` bigint NOT NULL COMMENT 'å•†å“ID',
  `view_count` int DEFAULT '0' COMMENT 'æµè§ˆæ¬¡æ•°',
  `favorite_count` int DEFAULT '0' COMMENT 'æ”¶è—æ¬¡æ•°',
  `image_count` int DEFAULT '0' COMMENT 'å›¾ç‰‡æ•°é‡',
  `cover_image_id` bigint DEFAULT NULL COMMENT 'å°é¢å›¾ç‰‡ID',
  `cover_image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å°é¢å›¾ç‰‡URL',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`product_id`),
  KEY `idx_view_count` (`view_count`),
  KEY `idx_favorite_count` (`favorite_count`),
  KEY `idx_update_time` (`update_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å•†å“ç»Ÿè®¡è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_statistics`
--

LOCK TABLES `product_statistics` WRITE;
/*!40000 ALTER TABLE `product_statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_view_history`
--

DROP TABLE IF EXISTS `product_view_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_view_history` (
  `history_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '历史ID',
  `user_id` bigint unsigned NOT NULL COMMENT '用户ID',
  `product_id` bigint unsigned NOT NULL COMMENT '商品ID',
  `view_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '浏览时间',
  `view_duration` int unsigned DEFAULT NULL COMMENT '浏览时长（秒）',
  PRIMARY KEY (`history_id`),
  KEY `idx_user_product_view` (`user_id`,`product_id`),
  KEY `idx_view_time` (`view_time`),
  KEY `fk_view_history_product` (`product_id`),
  CONSTRAINT `fk_view_history_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_view_history_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='浏览历史表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_view_history`
--

LOCK TABLES `product_view_history` WRITE;
/*!40000 ALTER TABLE `product_view_history` DISABLE KEYS */;
INSERT INTO `product_view_history` VALUES (104,9,14,'2026-03-11 17:09:12',0),(105,8,14,'2026-04-07 11:47:17',0);
/*!40000 ALTER TABLE `product_view_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quick_reply`
--

DROP TABLE IF EXISTS `quick_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quick_reply` (
  `reply_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '回复ID',
  `user_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '用户ID，0表示系统预设',
  `content` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '回复内容',
  `category` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分类：交易-询问/交易-确认/其他',
  `sort_order` int unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `is_system` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否系统预设：0-否 1-是',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`reply_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='快捷回复模板表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quick_reply`
--

LOCK TABLES `quick_reply` WRITE;
/*!40000 ALTER TABLE `quick_reply` DISABLE KEYS */;
INSERT INTO `quick_reply` VALUES (1,1,'不好意思，我已经找到合适的了','其他',1,0,'2026-03-04 16:54:33'),(2,1,'请问可以便宜一些吗？','交易-询问',2,0,'2026-03-04 16:54:33'),(4,9,'test\n','custom',0,0,'2026-03-05 21:52:12');
/*!40000 ALTER TABLE `quick_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refund_record`
--

DROP TABLE IF EXISTS `refund_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refund_record` (
  `refund_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'é€€æ¬¾è®°å½•ID',
  `refund_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'é€€æ¬¾å•å·',
  `order_id` bigint unsigned NOT NULL COMMENT 'è®¢å•ID',
  `refund_amount` decimal(10,2) unsigned NOT NULL COMMENT 'é€€æ¬¾é‡‘é¢',
  `refund_reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'é€€æ¬¾åŽŸå› ',
  `refund_type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'é€€æ¬¾ç±»åž‹ï¼š1-ä»…é€€æ¬¾ 2-é€€è´§é€€æ¬¾',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å®¡æ ¸ 1-å·²åŒæ„ 2-å·²æ‹’ç» 3-é€€è´§ä¸­ 4-å·²å®Œæˆ 5-å·²å–æ¶ˆ',
  `reject_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‹’ç»åŽŸå› ',
  `logistics_company` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç‰©æµå…¬å¸',
  `logistics_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç‰©æµå•å·',
  `logistics_time` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `evidence_images` json DEFAULT NULL COMMENT 'é€€æ¬¾å‡­è¯å›¾ç‰‡ï¼ŒJSONæ•°ç»„',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤‡æ³¨',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `finish_time` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤ï¼š0-æœªåˆ é™¤ 1-å·²åˆ é™¤',
  PRIMARY KEY (`refund_id`),
  UNIQUE KEY `idx_refund_no` (`refund_no`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_status` (`status`),
  KEY `idx_create_time` (`create_time`),
  CONSTRAINT `fk_refund_order` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é€€æ¬¾è®°å½•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refund_record`
--

LOCK TABLES `refund_record` WRITE;
/*!40000 ALTER TABLE `refund_record` DISABLE KEYS */;
INSERT INTO `refund_record` VALUES (1,'RF20250120001',2,350.00,'å•†å“ä¸Žæè¿°ä¸ç¬¦',1,0,NULL,NULL,NULL,NULL,'[\"https://example.com/evidence1.jpg\"]','å¸Œæœ›å°½å¿«å¤„ç†','2026-03-06 01:54:10','2026-03-06 01:54:10',NULL,0),(2,'RF20250119001',3,3200.00,'ä¸æƒ³è¦äº†',1,1,NULL,NULL,NULL,NULL,NULL,'ä¹°å®¶ç”³è¯·å–æ¶ˆ','2026-03-05 01:54:10','2026-03-06 01:54:10',NULL,0),(3,'RF20250118001',4,299.00,'å•†å“è´¨é‡é—®é¢˜',2,3,NULL,'é¡ºä¸°é€Ÿè¿','SF1234567890','2026-03-05 01:54:10','[\"https://example.com/evidence2.jpg\", \"https://example.com/evidence3.jpg\"]','å·²é€€è´§','2026-03-04 01:54:10','2026-03-06 01:54:10',NULL,0),(4,'RF20250117001',5,899.00,'å•†å“æœ‰ç‘•ç–µ',2,4,NULL,NULL,NULL,NULL,NULL,'å·²å®Œæˆé€€æ¬¾','2026-03-03 01:54:10','2026-03-06 01:54:10','2026-03-04 01:54:10',0),(5,'RF20250116001',1,5999.00,'å‘è´§å¤ªæ…¢',1,2,NULL,NULL,NULL,NULL,NULL,'ä¸åŒæ„é€€æ¬¾','2026-03-02 01:54:10','2026-03-06 01:54:10',NULL,0),(6,'RF20250306001',6,5999.00,'å•†å“ä¸Žæè¿°ä¸ç¬¦',2,5,NULL,NULL,NULL,NULL,'[\"https://example.com/evidence1.jpg\"]','å¸Œæœ›å°½å¿«å¤„ç†','2026-03-06 01:57:00','2026-03-06 01:57:00',NULL,0),(7,'RF20250306002',7,3200.00,'å•†å“è´¨é‡é—®é¢˜',2,3,NULL,'é¡ºä¸°é€Ÿè¿','SF9876543210','2026-03-05 01:57:00','[\"https://example.com/evidence2.jpg\"]','å·²é€€è´§ç‰©æµ','2026-03-05 01:57:00','2026-03-06 01:57:00',NULL,0),(8,'RF20250306003',8,350.00,'ä¸æƒ³è¦äº†',1,4,NULL,NULL,NULL,NULL,NULL,'å·²å®Œæˆé€€æ¬¾','2026-03-04 01:57:00','2026-03-06 01:57:00','2026-03-05 01:57:00',0);
/*!40000 ALTER TABLE `refund_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report` (
  `report_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '举报ID',
  `reporter_id` bigint unsigned NOT NULL COMMENT '举报人ID',
  `reported_user_id` bigint unsigned NOT NULL COMMENT '被举报人ID',
  `conversation_id` bigint unsigned DEFAULT NULL COMMENT '会话ID',
  `message_id` bigint unsigned DEFAULT NULL COMMENT '消息ID',
  `reason` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '举报原因：欺诈/骚扰/虚假信息/其他',
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '描述',
  `evidence_images` json DEFAULT NULL COMMENT '证据图片，JSON数组',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '处理状态：0-待处理 1-已处理 2-已驳回',
  `admin_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '管理员备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `handle_time` datetime DEFAULT NULL COMMENT '处理时间',
  PRIMARY KEY (`report_id`),
  KEY `idx_reporter_id` (`reporter_id`),
  KEY `idx_reported_user_id` (`reported_user_id`),
  KEY `idx_status` (`status`),
  KEY `fk_report_conversation` (`conversation_id`),
  KEY `fk_report_message` (`message_id`),
  CONSTRAINT `fk_report_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `conversation` (`conversation_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_report_message` FOREIGN KEY (`message_id`) REFERENCES `message` (`message_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_report_reported_user` FOREIGN KEY (`reported_user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_report_reporter` FOREIGN KEY (`reporter_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='举报记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
INSERT INTO `report` VALUES (1,9,1,NULL,NULL,'4','asd',NULL,1,'4','2026-03-04 20:46:01','2026-03-09 13:51:38');
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensitive_word`
--

DROP TABLE IF EXISTS `sensitive_word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensitive_word` (
  `word_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '敏感词ID',
  `word` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '敏感词',
  `type` tinyint unsigned NOT NULL COMMENT '类型：1-禁止词 2-敏感词 3-替换词',
  `replace_word` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '替换词（type=3时使用）',
  `level` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '等级：1-一般 2-严重（严重等级直接拦截）',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '状态：0-禁用 1-启用',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`word_id`),
  UNIQUE KEY `idx_word` (`word`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='敏感词表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensitive_word`
--

LOCK TABLES `sensitive_word` WRITE;
/*!40000 ALTER TABLE `sensitive_word` DISABLE KEYS */;
INSERT INTO `sensitive_word` VALUES (1,'欺诈',1,'',2,1,'2026-02-18 13:08:33','2026-03-09 14:37:14',0),(2,'诈骗',1,NULL,2,1,'2026-02-18 13:08:33','2026-02-18 13:08:33',0),(3,'刷单',1,NULL,2,1,'2026-02-18 13:08:33','2026-02-18 13:08:33',0),(4,'洗钱',1,NULL,2,1,'2026-02-18 13:08:33','2026-02-18 13:08:33',0),(5,'假货',2,NULL,1,1,'2026-02-18 13:08:33','2026-02-18 13:08:33',0),(6,'骗子',2,NULL,1,1,'2026-02-18 13:08:33','2026-02-18 13:08:33',0),(7,'高仿',2,NULL,1,1,'2026-02-18 13:08:33','2026-02-18 13:08:33',0),(8,'二手东',2,NULL,1,1,'2026-02-18 13:08:33','2026-02-18 13:08:33',0),(9,'破解',2,NULL,1,1,'2026-02-18 13:08:33','2026-02-18 13:08:33',0),(10,'盗版',2,NULL,1,1,'2026-02-18 13:08:33','2026-02-18 13:08:33',0),(11,'微信',3,'wx',1,1,'2026-02-18 13:08:33','2026-02-18 13:08:33',0),(12,'QQ',3,'QQ',1,1,'2026-02-18 13:08:33','2026-02-18 13:08:33',0),(13,'支付宝',3,'支付宝',1,1,'2026-02-18 13:08:33','2026-02-18 13:08:33',0),(14,'231',1,'',1,1,'2026-03-09 15:01:43','2026-03-09 15:01:47',1),(15,'3123',1,NULL,1,1,'2026-03-09 15:10:52','2026-03-09 15:10:59',1),(16,'tesss',1,NULL,1,1,'2026-03-09 15:10:52','2026-03-09 15:11:01',1),(17,'asd',1,NULL,1,1,'2026-03-09 15:10:52','2026-03-09 15:11:02',1);
/*!40000 ALTER TABLE `sensitive_word` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `share_item`
--

DROP TABLE IF EXISTS `share_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `share_item` (
  `share_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '共享物品ID',
  `owner_id` bigint unsigned NOT NULL COMMENT '所有者ID',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `category_id` int unsigned DEFAULT NULL,
  `deposit` decimal(10,2) unsigned DEFAULT '0.00',
  `daily_rent` decimal(10,2) unsigned DEFAULT '0.00',
  `cover_image_id` bigint unsigned DEFAULT NULL COMMENT '封面图片ID',
  `image_count` tinyint unsigned DEFAULT '0',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '状态：0-下架 1-可借用 2-借用中',
  `available_times` json DEFAULT NULL COMMENT '可借用时间段，JSON格式',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`share_id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_share_item_owner` FOREIGN KEY (`owner_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=299556372855528597 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='共享物品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `share_item`
--

LOCK TABLES `share_item` WRITE;
/*!40000 ALTER TABLE `share_item` DISABLE KEYS */;
INSERT INTO `share_item` VALUES (1,1,'小米充电宝 20000mAh 快充版','20000mAh大容量，支持快充，9成新，充满电可给iPhone充电4-5次。适合外出旅游、上课应急使用。',11,50.00,5.00,101,1,1,NULL,'2026-03-01 10:00:00','2026-03-06 14:43:44',0),(2,2,'索尼蓝牙耳机 WH-1000XM4','降噪神器，音质出色，9成新，无划痕。适合图书馆自习、宿舍休息时使用。',11,200.00,15.00,102,1,1,NULL,'2026-03-01 11:00:00','2026-03-06 14:43:44',0),(3,3,'富士拍立得 mini11','可爱拍立得相机，功能完好，送两盒相纸。适合毕业季、聚会拍照留念。',11,150.00,20.00,103,1,1,NULL,'2026-03-01 12:00:00','2026-03-06 14:43:44',0),(4,1,'自行车雨衣套装','骑行雨衣+防水鞋套，全新未使用。适合下雨天骑行使用。',11,30.00,3.00,104,1,1,NULL,'2026-03-01 13:00:00','2026-03-06 14:43:44',0),(5,4,'露营帐篷双人款','户外露营帐篷，防雨防晒，适合2-3人使用。周末露营、野外活动必备。',11,100.00,25.00,105,1,1,NULL,'2026-03-01 14:00:00','2026-03-06 14:43:44',0),(6,5,'Switch游戏机日版','Nintendo Switch OLED版，附带《塞尔达传说》等3款游戏。适合周末娱乐。',11,300.00,30.00,106,1,2,NULL,'2026-03-01 15:00:00','2026-03-06 14:43:44',0),(7,6,'专业相机佳能EOS R50','微单相机套机，含15-45mm镜头，适合摄影爱好者、毕业季拍照。',11,500.00,50.00,107,1,1,NULL,'2026-03-01 16:00:00','2026-03-06 14:43:44',0),(8,7,'网球拍Wilson Pro','专业网球拍，手感好，适合网球课、业余训练使用。',11,80.00,10.00,108,1,0,NULL,'2026-03-01 17:00:00','2026-03-06 14:43:44',0),(9,9,'iPad Pro 11寸2022款','iPad Pro用于网课、画画、看视频，配件齐全，包含Apple Pencil。',11,300.00,30.00,109,1,2,NULL,'2026-03-06 10:00:00','2026-03-06 14:43:44',0),(10,9,'蓝牙音箱JBL Flip6','便携式蓝牙音箱，音质好，续航强，适合聚会、户外使用。',11,50.00,8.00,110,1,1,NULL,'2026-03-06 11:00:00','2026-03-06 14:43:44',0),(11,9,'折叠桌椅套装','户外露营桌椅，轻便易折叠，适合野餐、露营。',11,40.00,5.00,111,1,0,NULL,'2026-03-06 12:00:00','2026-03-06 14:43:44',0),(12,9,'无人机大疆Mini 3 Pro','航拍无人机，4K高清摄像，适合摄影、旅行留念。',11,500.00,50.00,112,1,2,NULL,'2026-03-06 13:00:00','2026-03-06 14:43:44',0),(13,9,'天文望远镜星特朗80EQ','入门级天文望远镜，适合观星、天文爱好者。',11,200.00,20.00,113,1,1,NULL,'2026-03-06 14:00:00','2026-03-06 14:43:44',0),(298882451273552095,8,'','',NULL,0.00,0.00,NULL,0,4,'{\"rentalDays\": \"\", \"rentalType\": \"days\", \"deliveryFee\": \"\", \"mailingType\": \"\", \"rentalHours\": \"\", \"deliveryMethod\": \"pickup\"}','2026-04-05 02:12:09','2026-04-05 02:12:09',0),(298882490989417072,8,'','',NULL,0.00,0.00,NULL,0,4,'{\"rentalDays\": \"\", \"rentalType\": \"days\", \"deliveryFee\": \"\", \"mailingType\": \"\", \"rentalHours\": \"\", \"deliveryMethod\": \"pickup\"}','2026-04-05 02:12:19','2026-04-05 02:12:19',0),(299382654497854921,8,'','',NULL,0.00,0.00,NULL,0,4,'{\"rentalDays\": \"\", \"rentalType\": \"days\", \"deliveryFee\": \"\", \"mailingType\": \"\", \"rentalHours\": \"\", \"deliveryMethod\": \"pickup\"}','2026-04-06 11:19:47','2026-04-06 11:19:47',0),(299382924501981194,8,'','',NULL,0.00,0.00,NULL,0,4,'{\"rentalDays\": \"\", \"rentalType\": \"days\", \"deliveryFee\": \"\", \"mailingType\": \"\", \"rentalHours\": \"\", \"deliveryMethod\": \"pickup\"}','2026-04-06 11:20:51','2026-04-06 11:20:51',0),(299385937526395493,8,'','',NULL,0.00,0.00,NULL,0,4,'{\"rentalDays\": \"\", \"rentalType\": \"days\", \"deliveryFee\": \"\", \"mailingType\": \"\", \"rentalHours\": \"\", \"deliveryMethod\": \"pickup\"}','2026-04-06 11:32:50','2026-04-06 11:32:50',0),(299423326743436160,8,'','',NULL,0.00,0.00,NULL,0,4,'{\"rentalDays\": \"\", \"rentalType\": \"days\", \"deliveryFee\": \"\", \"mailingType\": \"\", \"rentalHours\": \"\", \"deliveryMethod\": \"pickup\"}','2026-04-06 14:01:24','2026-04-06 14:01:24',0),(299437869406230670,8,'','',NULL,0.00,0.00,NULL,0,4,'{\"rentalDays\": \"\", \"rentalType\": \"days\", \"deliveryFee\": \"\", \"mailingType\": \"\", \"rentalHours\": \"\", \"deliveryMethod\": \"pickup\"}','2026-04-06 14:59:11','2026-04-06 14:59:11',0),(299543410413542897,8,'','',NULL,0.00,0.00,NULL,0,4,'{\"rentalDays\": \"\", \"rentalType\": \"days\", \"deliveryFee\": \"\", \"mailingType\": \"\", \"rentalHours\": \"\", \"deliveryMethod\": \"pickup\"}','2026-04-06 21:58:34','2026-04-06 21:58:34',0),(299554239368269828,8,'','',NULL,0.00,0.00,NULL,0,4,'{\"rentalDays\": \"\", \"rentalType\": \"days\", \"deliveryFee\": \"\", \"mailingType\": \"\", \"rentalHours\": \"\", \"deliveryMethod\": \"pickup\"}','2026-04-06 22:41:36','2026-04-06 22:41:36',0),(299556372855528596,8,'','',NULL,0.00,0.00,NULL,0,4,'{\"rentalDays\": \"\", \"rentalType\": \"days\", \"deliveryFee\": \"\", \"mailingType\": \"\", \"rentalHours\": \"\", \"deliveryMethod\": \"pickup\"}','2026-04-06 22:50:05','2026-04-06 22:50:05',0);
/*!40000 ALTER TABLE `share_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `share_item_booking`
--

DROP TABLE IF EXISTS `share_item_booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `share_item_booking` (
  `booking_id` bigint NOT NULL AUTO_INCREMENT COMMENT 'é¢„çº¦ID',
  `share_id` bigint NOT NULL COMMENT 'å…±äº«ç‰©å“ID',
  `owner_id` bigint NOT NULL COMMENT 'ç‰©å“æ‰€æœ‰è€…ID',
  `borrower_id` bigint NOT NULL COMMENT 'å€Ÿç”¨è€…ID',
  `start_date` date NOT NULL COMMENT 'é¢„çº¦å€Ÿç”¨å¼€å§‹æ—¥æœŸ',
  `end_date` date NOT NULL COMMENT 'é¢„çº¦å€Ÿç”¨ç»“æŸæ—¥æœŸ',
  `days` int NOT NULL COMMENT 'å€Ÿç”¨å¤©æ•°',
  `total_rent` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'æ€»ç§Ÿé‡‘ï¼ˆæ—¥ç§Ÿé‡‘Ã—å¤©æ•°ï¼‰',
  `deposit` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'æŠ¼é‡‘',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'æ€»é‡‘é¢ï¼ˆç§Ÿé‡‘+æŠ¼é‡‘ï¼‰',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT 'å€Ÿç”¨è¯´æ˜Ž/å¤‡æ³¨',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'é¢„çº¦çŠ¶æ€ï¼š0-å¾…å®¡æ‰¹ï¼Œ1-å·²æ‰¹å‡†ï¼Œ2-å·²æ‹’ç»ï¼Œ3-å·²å–æ¶ˆï¼Œ4-å€Ÿç”¨ä¸­ï¼Œ5-å·²å®Œæˆ',
  `start_time` datetime DEFAULT NULL COMMENT 'å¼€å§‹æ—¶é—´',
  `approve_time` datetime DEFAULT NULL COMMENT 'å®¡æ‰¹æ—¶é—´',
  `approve_remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å®¡æ‰¹å¤‡æ³¨',
  `return_time` datetime DEFAULT NULL COMMENT 'å®žé™…å½’è¿˜æ—¶é—´',
  `return_remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å½’è¿˜å¤‡æ³¨',
  `deposit_paid_time` datetime DEFAULT NULL COMMENT 'æŠ¼é‡‘æ”¯ä»˜æ—¶é—´',
  `deposit_returned` tinyint NOT NULL DEFAULT '0' COMMENT 'æ˜¯å¦å·²å½’è¿˜æŠ¼é‡‘ï¼š0-æœªé€€è¿˜ï¼Œ1-å·²é€€è¿˜',
  `deposit_return_time` datetime DEFAULT NULL COMMENT 'æŠ¼é‡‘é€€è¿˜æ—¶é—´',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤æ ‡è®°ï¼ˆ0=æœªåˆ é™¤ï¼Œ1=å·²åˆ é™¤ï¼‰',
  PRIMARY KEY (`booking_id`),
  KEY `idx_share_id` (`share_id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_borrower_id` (`borrower_id`),
  KEY `idx_status` (`status`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å…±äº«ç‰©å“é¢„çº¦å€Ÿç”¨è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `share_item_booking`
--

LOCK TABLES `share_item_booking` WRITE;
/*!40000 ALTER TABLE `share_item_booking` DISABLE KEYS */;
INSERT INTO `share_item_booking` VALUES (1,1,1,2,'2026-03-10','2026-03-12',2,0.00,50.00,60.00,'周末外出旅游需要，可以吗？',0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-06 10:00:00','2026-03-06 10:00:00',0),(2,1,1,3,'2026-03-08','2026-03-09',1,0.00,50.00,55.00,'明天应急用一下',1,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-05 14:00:00','2026-03-05 14:00:00',0),(3,2,2,2,'2026-03-05','2026-03-07',2,0.00,200.00,230.00,'图书馆自习使用',2,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-04 09:00:00','2026-03-04 09:00:00',0),(4,3,3,4,'2026-03-06','2026-03-08',2,0.00,150.00,190.00,'毕业季拍照',2,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-05 16:00:00','2026-03-05 16:00:00',0),(5,4,1,5,'2026-03-01','2026-03-02',1,0.00,30.00,33.00,'下雨天骑行',4,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-02-28 11:00:00','2026-02-28 11:00:00',0),(6,5,4,6,'2026-03-15','2026-03-17',2,0.00,100.00,150.00,'周末去露营',0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-06 09:30:00','2026-03-06 09:30:00',0),(7,6,5,7,'2026-03-04','2026-03-06',2,0.00,300.00,360.00,'周末和朋友一起玩',2,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-03 15:00:00','2026-03-03 15:00:00',0),(8,7,6,8,'2026-03-20','2026-03-22',2,0.00,500.00,600.00,'拍毕业照',0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-06 08:00:00','2026-03-06 08:00:00',0),(9,8,7,2,'2026-03-03','2026-03-04',1,0.00,80.00,90.00,'网球课使用',5,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-02 10:00:00','2026-03-02 10:00:00',0),(10,1,1,3,'2026-03-02','2026-03-03',1,0.00,50.00,55.00,'临时借用',3,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-01 12:00:00','2026-03-01 12:00:00',0),(11,1,1,9,'2026-03-15','2026-03-17',2,0.00,50.00,60.00,'周末去音乐节需要',0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-06 15:00:00','2026-03-06 15:00:00',0),(12,2,2,9,'2026-03-06','2026-03-08',2,0.00,200.00,230.00,'图书馆期末复习用',2,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-05 10:00:00','2026-03-05 10:00:00',0),(13,3,3,9,'2026-03-02','2026-03-03',1,0.00,150.00,170.00,'生日派对拍照',4,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-01 12:00:00','2026-03-01 12:00:00',0),(14,5,4,9,'2026-03-20','2026-03-22',2,0.00,100.00,150.00,'计划去露营',0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-06 16:00:00','2026-03-06 16:00:00',0),(15,7,6,9,'2026-03-10','2026-03-11',1,0.00,500.00,550.00,'想拍校园风景',1,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-04 09:00:00','2026-03-04 09:00:00',0),(16,9,9,1,'2026-03-12','2026-03-14',2,0.00,300.00,360.00,'需要写论文做笔记',1,NULL,'2026-03-06 14:55:32',NULL,NULL,NULL,NULL,0,NULL,'2026-03-06 14:00:00','2026-03-06 14:00:00',0),(17,10,9,2,'2026-03-05','2026-03-07',2,0.00,50.00,66.00,'宿舍聚会使用',2,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-04 11:00:00','2026-03-04 11:00:00',0),(18,12,9,3,'2026-03-03','2026-03-04',1,0.00,500.00,550.00,'拍校园风景',3,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-02 10:00:00','2026-03-02 10:00:00',0),(19,13,9,4,'2026-03-06','2026-03-08',2,0.00,200.00,240.00,'天文课作业',2,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-03-05 15:00:00','2026-03-05 15:00:00',0),(20,9,9,5,'2026-03-01','2026-03-02',1,0.00,300.00,330.00,'临时需要',5,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-02-28 16:00:00','2026-02-28 16:00:00',0);
/*!40000 ALTER TABLE `share_item_booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `share_item_image`
--

DROP TABLE IF EXISTS `share_item_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `share_item_image` (
  `image_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '图片ID',
  `share_id` bigint unsigned NOT NULL COMMENT '共享物品ID',
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图片URL',
  `image_thumbnail_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '缩略图URL',
  `image_medium_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '中等尺寸图片URL',
  `sort_order` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '排序顺序',
  `file_size` int unsigned DEFAULT NULL COMMENT '文件大小（字节）',
  `width` smallint unsigned DEFAULT NULL COMMENT '图片宽度',
  `height` smallint unsigned DEFAULT NULL COMMENT '图片高度',
  `is_cover` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否为封面：0-否 1-是',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0-正常 1-已删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`image_id`),
  KEY `idx_share_id` (`share_id`),
  KEY `idx_is_cover` (`is_cover`),
  KEY `idx_sort_order` (`sort_order`),
  CONSTRAINT `fk_share_item_image_share` FOREIGN KEY (`share_id`) REFERENCES `share_item` (`share_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='共享物品图片表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `share_item_image`
--

LOCK TABLES `share_item_image` WRITE;
/*!40000 ALTER TABLE `share_item_image` DISABLE KEYS */;
INSERT INTO `share_item_image` VALUES (101,1,'/uploads/share/1-powerbank.jpg','/uploads/share/1-powerbank-thumb.jpg','/uploads/share/1-powerbank-medium.jpg',0,NULL,NULL,NULL,1,0,'2026-03-06 14:43:44'),(102,2,'/uploads/share/2-headphone.jpg','/uploads/share/2-headphone-thumb.jpg','/uploads/share/2-headphone-medium.jpg',0,NULL,NULL,NULL,1,0,'2026-03-06 14:43:44'),(103,3,'/uploads/share/3-camera.jpg','/uploads/share/3-camera-thumb.jpg','/uploads/share/3-camera-medium.jpg',0,NULL,NULL,NULL,1,0,'2026-03-06 14:43:44'),(104,4,'/uploads/share/4-raincoat.jpg','/uploads/share/4-raincoat-thumb.jpg','/uploads/share/4-raincoat-medium.jpg',0,NULL,NULL,NULL,1,0,'2026-03-06 14:43:44'),(105,5,'/uploads/share/5-tent.jpg','/uploads/share/5-tent-thumb.jpg','/uploads/share/5-tent-medium.jpg',0,NULL,NULL,NULL,1,0,'2026-03-06 14:43:44'),(106,6,'/uploads/share/6-switch.jpg','/uploads/share/6-switch-thumb.jpg','/uploads/share/6-switch-medium.jpg',0,NULL,NULL,NULL,1,0,'2026-03-06 14:43:44'),(107,7,'/uploads/share/7-dslr.jpg','/uploads/share/7-dslr-thumb.jpg','/uploads/share/7-dslr-medium.jpg',0,NULL,NULL,NULL,1,0,'2026-03-06 14:43:44'),(108,8,'/uploads/share/8-tennis.jpg','/uploads/share/8-tennis-thumb.jpg','/uploads/share/8-tennis-medium.jpg',0,NULL,NULL,NULL,1,0,'2026-03-06 14:43:44'),(109,9,'/uploads/share/9-ipad.jpg','/uploads/share/9-ipad-thumb.jpg','/uploads/share/9-ipad-medium.jpg',0,NULL,NULL,NULL,1,0,'2026-03-06 14:43:44'),(110,10,'/uploads/share/10-speaker.jpg','/uploads/share/10-speaker-thumb.jpg','/uploads/share/10-speaker-medium.jpg',0,NULL,NULL,NULL,1,0,'2026-03-06 14:43:44'),(111,11,'/uploads/share/11-table.jpg','/uploads/share/11-table-thumb.jpg','/uploads/share/11-table-medium.jpg',0,NULL,NULL,NULL,1,0,'2026-03-06 14:43:44'),(112,12,'/uploads/share/12-drone.jpg','/uploads/share/12-drone-thumb.jpg','/uploads/share/12-drone-medium.jpg',0,NULL,NULL,NULL,1,0,'2026-03-06 14:43:44'),(113,13,'/uploads/share/13-telescope.jpg','/uploads/share/13-telescope-thumb.jpg','/uploads/share/13-telescope-medium.jpg',0,NULL,NULL,NULL,1,0,'2026-03-06 14:43:44');
/*!40000 ALTER TABLE `share_item_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statistics_cache`
--

DROP TABLE IF EXISTS `statistics_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `statistics_cache` (
  `id` bigint NOT NULL COMMENT '缓存ID',
  `cache_key` varchar(100) NOT NULL COMMENT '缓存键',
  `cache_data` json NOT NULL COMMENT '缓存数据',
  `expire_time` datetime NOT NULL COMMENT '过期时间',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cache_key` (`cache_key`),
  KEY `idx_expire_time` (`expire_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='数据统计缓存表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statistics_cache`
--

LOCK TABLES `statistics_cache` WRITE;
/*!40000 ALTER TABLE `statistics_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `statistics_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_config`
--

DROP TABLE IF EXISTS `system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_config` (
  `config_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `config_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置键（唯一）',
  `config_value` text COLLATE utf8mb4_unicode_ci COMMENT '配置值',
  `config_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'string' COMMENT '配置类型：string/number/boolean/json',
  `value_options` json DEFAULT NULL COMMENT '可选值列表，JSON格式',
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '配置说明',
  `group_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分组名称：basic/upload/payment/email/sms等',
  `is_public` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否公开：0-否 1-是（公开的配置前端可访问）',
  `is_system` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否系统配置：0-否 1-是（系统配置不可删除）',
  `sort_order` int unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`config_id`),
  UNIQUE KEY `idx_config_key` (`config_key`),
  KEY `idx_group_name` (`group_name`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_config`
--

LOCK TABLES `system_config` WRITE;
/*!40000 ALTER TABLE `system_config` DISABLE KEYS */;
INSERT INTO `system_config` VALUES (1,'app_name','校园易购','string',NULL,'应用名称','basic',1,1,1,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(2,'app_version','1.0.0','string',NULL,'应用版本号','basic',1,1,2,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(3,'icp_license','粤ICP备xxxxxxxx号','string',NULL,'ICP备案号','basic',1,1,3,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(4,'copyright','© 2026 校园易购','string',NULL,'版权信息','basic',1,1,4,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(5,'upload_max_size','5242880','number',NULL,'最大上传文件大小(5MB)','upload',1,0,1,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(6,'upload_max_count','9','number',NULL,'单次最多上传数量','upload',1,0,2,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(7,'upload_allowed_types','jpg,jpeg,png,webp','string',NULL,'允许的文件类型','upload',1,0,3,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(8,'password_min_length','6','number',NULL,'密码最小长度','security',1,1,1,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(9,'password_max_length','20','number',NULL,'密码最大长度','security',1,1,2,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(10,'token_expire_time','604800','number',NULL,'Token过期时间(秒,7天)','security',1,1,3,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(11,'max_login_attempts','5','number',NULL,'最大登录尝试次数','security',1,1,4,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(12,'login_lock_time','1800','number',NULL,'登录锁定时长(秒,30分钟)','security',1,1,5,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(13,'product_max_images','9','number',NULL,'商品最大图片数','business',1,0,1,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(14,'product_title_max_length','50','number',NULL,'商品标题最大长度','business',1,0,2,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(15,'product_desc_max_length','2000','number',NULL,'商品描述最大长度','business',1,0,3,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(16,'order_auto_close_time','1800','number',NULL,'订单自动关闭时间(秒,30分钟)','business',1,0,4,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(17,'order_auto_finish_time','604800','number',NULL,'订单自动完成时间(秒,7天)','business',1,0,5,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(18,'credit_score_initial','100','number',NULL,'初始信用分数','business',1,0,6,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(19,'sensitive_word_enabled','true','boolean',NULL,'是否启用敏感词过滤','content',1,0,1,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(20,'sensitive_word_replace','***','string',NULL,'敏感词替换字符','content',1,0,2,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(21,'product_audit_required','false','boolean',NULL,'商品是否需要审核后发布','content',1,0,3,'2026-03-02 21:34:32','2026-03-02 21:34:32',0),(22,'appName','æ ¡å›­äºŒæ‰‹äº¤æ˜“å¹³å°','string',NULL,'åº”ç”¨åç§°','basic',1,1,1,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(23,'appVersion','1.0.0','string',NULL,'åº”ç”¨ç‰ˆæœ¬å·','basic',1,1,2,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(24,'icp','äº¬ICPå¤‡XXXXXXXXå·','string',NULL,'ICPå¤‡æ¡ˆå·','basic',1,1,3,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(25,'companyName','æ ¡å›­äºŒæ‰‹äº¤æ˜“å¹³å°','string',NULL,'å…¬å¸åç§°','basic',1,1,4,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(26,'contactEmail','admin@xianqi.com','string',NULL,'è”ç³»é‚®ç®±','basic',1,1,5,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(27,'contactPhone','400-000-0000','string',NULL,'è”ç³»ç”µè¯','basic',1,1,6,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(28,'maxUploadSize','5','number',NULL,'æœ€å¤§æ–‡ä»¶å¤§å°ï¼ˆMBï¼‰','upload',1,1,1,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(29,'allowedTypes','jpg,png,gif,webp','string',NULL,'å…è®¸çš„æ–‡ä»¶ç±»åž‹ï¼ˆå›¾ç‰‡ï¼‰','upload',1,1,2,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(30,'maxFileCount','9','number',NULL,'å•æ¬¡æœ€å¤§ä¸Šä¼ æ–‡ä»¶æ•°','upload',1,1,3,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(31,'avatarMaxSize','2','number',NULL,'å¤´åƒæœ€å¤§å¤§å°ï¼ˆMBï¼‰','upload',1,1,4,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(32,'documentMaxSize','10','number',NULL,'æ–‡æ¡£æœ€å¤§å¤§å°ï¼ˆMBï¼‰','upload',1,1,5,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(33,'alipayEnabled','false','boolean',NULL,'æ˜¯å¦å¯ç”¨æ”¯ä»˜å®æ”¯ä»˜','payment',0,1,1,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(34,'alipayAppId','','string',NULL,'æ”¯ä»˜å®åº”ç”¨ID','payment',0,1,2,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(35,'wechatPayEnabled','false','boolean',NULL,'æ˜¯å¦å¯ç”¨å¾®ä¿¡æ”¯ä»˜','payment',0,1,3,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(36,'wechatPayAppId','','string',NULL,'å¾®ä¿¡æ”¯ä»˜åº”ç”¨ID','payment',0,1,4,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(37,'paymentTimeout','30','number',NULL,'æ”¯ä»˜è¶…æ—¶æ—¶é—´ï¼ˆåˆ†é’Ÿï¼‰','payment',0,1,5,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(38,'emailEnabled','false','boolean',NULL,'æ˜¯å¦å¯ç”¨é‚®ä»¶æœåŠ¡','email',0,1,1,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(39,'emailHost','smtp.qq.com','string',NULL,'SMTPæœåŠ¡å™¨åœ°å€','email',0,1,2,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(40,'emailPort','587','number',NULL,'SMTPç«¯å£','email',0,1,3,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(41,'emailUsername','','string',NULL,'å‘ä»¶äººé‚®ç®±','email',0,1,4,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(42,'emailPassword','','string',NULL,'é‚®ç®±å¯†ç æˆ–æŽˆæƒç ','email',0,1,5,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(43,'emailFromName','æ ¡å›­äºŒæ‰‹äº¤æ˜“å¹³å°','string',NULL,'å‘ä»¶äººåç§°','email',0,1,6,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(44,'smsEnabled','false','boolean',NULL,'æ˜¯å¦å¯ç”¨çŸ­ä¿¡æœåŠ¡','sms',0,1,1,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(45,'smsProvider','aliyun','string',NULL,'çŸ­ä¿¡æœåŠ¡å•†ï¼ˆaliyun/tencentï¼‰','sms',0,1,2,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(46,'smsAccessKeyId','','string',NULL,'çŸ­ä¿¡æœåŠ¡AccessKey ID','sms',0,1,3,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(47,'smsAccessKeySecret','','string',NULL,'çŸ­ä¿¡æœåŠ¡AccessKey Secret','sms',0,1,4,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(48,'smsSignName','æ ¡å›­äºŒæ‰‹äº¤æ˜“å¹³å°','string',NULL,'çŸ­ä¿¡ç­¾å','sms',0,1,5,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(49,'smsTemplateCode','SMS_XXXXXXXX','string',NULL,'çŸ­ä¿¡æ¨¡æ¿ä»£ç ','sms',0,1,6,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(50,'passwordMinLength','6','number',NULL,'å¯†ç æœ€å°é•¿åº¦','security',0,1,1,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(51,'passwordMaxLength','20','number',NULL,'å¯†ç æœ€å¤§é•¿åº¦','security',0,1,2,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(52,'tokenExpiration','24','number',NULL,'Tokenè¿‡æœŸæ—¶é—´ï¼ˆå°æ—¶ï¼‰','security',0,1,3,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(53,'refreshTokenExpiration','168','number',NULL,'åˆ·æ–°Tokenè¿‡æœŸæ—¶é—´ï¼ˆå°æ—¶ï¼‰','security',0,1,4,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(54,'maxLoginAttempts','5','number',NULL,'æœ€å¤§ç™»å½•å°è¯•æ¬¡æ•°','security',0,1,5,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(55,'loginLockTime','30','number',NULL,'ç™»å½•é”å®šæ—¶é—´ï¼ˆåˆ†é’Ÿï¼‰','security',0,1,6,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(56,'productMaxImages','9','number',NULL,'å•†å“æœ€å¤§å›¾ç‰‡æ•°','business',1,1,1,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(57,'orderTimeout','30','number',NULL,'è®¢å•è¶…æ—¶æ—¶é—´ï¼ˆåˆ†é’Ÿï¼‰','business',0,1,2,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(58,'shareMaxDays','30','number',NULL,'å…±äº«ç‰©å“æœ€å¤§å€Ÿç”¨å¤©æ•°','business',0,1,3,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(59,'autoConfirmDays','7','number',NULL,'è‡ªåŠ¨ç¡®è®¤æ”¶è´§å¤©æ•°','business',0,1,4,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(60,'commentTimeout','7','number',NULL,'è¯„ä»·è¶…æ—¶æ—¶é—´ï¼ˆå¤©ï¼‰','business',0,1,5,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(61,'refundDays','7','number',NULL,'é€€æ¬¾ç”³è¯·æœŸé™ï¼ˆå¤©ï¼‰','business',0,1,6,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(62,'contentAuditEnabled','false','boolean',NULL,'æ˜¯å¦å¯ç”¨å†…å®¹å®¡æ ¸','content',0,1,1,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(63,'sensitiveWordFilterEnabled','true','boolean',NULL,'æ˜¯å¦å¯ç”¨æ•æ„Ÿè¯è¿‡æ»¤','content',0,1,2,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(64,'imageAuditEnabled','false','boolean',NULL,'æ˜¯å¦å¯ç”¨å›¾ç‰‡å®¡æ ¸','content',0,1,3,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(65,'autoAuditProduct','true','boolean',NULL,'æ˜¯å¦è‡ªåŠ¨å®¡æ ¸å•†å“','content',0,1,4,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(66,'autoAuditComment','true','boolean',NULL,'æ˜¯å¦è‡ªåŠ¨å®¡æ ¸è¯„è®º','content',0,1,5,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(67,'siteClosed','false','boolean',NULL,'ç«™ç‚¹æ˜¯å¦å…³é—­','other',1,1,1,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(68,'closeReason','ç³»ç»Ÿç»´æŠ¤ä¸­ï¼Œè¯·ç¨åŽè®¿é—®','string',NULL,'ç«™ç‚¹å…³é—­åŽŸå› ','other',1,1,2,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(69,'registerEnabled','true','boolean',NULL,'æ˜¯å¦å…è®¸æ³¨å†Œ','other',1,1,3,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(70,'realNameAuthRequired','true','boolean',NULL,'æ˜¯å¦éœ€è¦å®žåè®¤è¯','other',1,1,4,'2026-03-09 11:00:29','2026-03-09 11:00:29',0),(71,'studentIdAuthRequired','true','boolean',NULL,'æ˜¯å¦éœ€è¦å­¦å·è®¤è¯','other',1,1,5,'2026-03-09 11:00:29','2026-03-09 11:00:29',0);
/*!40000 ALTER TABLE `system_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_notification`
--

DROP TABLE IF EXISTS `system_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_notification` (
  `notification_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '通知ID',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '通知标题',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '通知内容，支持富文本',
  `type` tinyint unsigned NOT NULL COMMENT '通知类型：1-系统公告 2-活动通知 3-账户提醒 4-交易提醒',
  `target_type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '目标类型：1-全部用户 2-指定用户 3-指定等级',
  `target_users` json DEFAULT NULL COMMENT '指定用户ID列表，JSON数组',
  `target_level` int unsigned DEFAULT NULL COMMENT '目标用户等级',
  `is_read` json DEFAULT NULL COMMENT '已读用户ID列表，JSON数组',
  `link_type` tinyint unsigned DEFAULT NULL COMMENT '跳转链接类型：1-无 2-网页 3-商品详情 4-订单详情',
  `link_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '跳转URL',
  `link_product_id` bigint unsigned DEFAULT NULL COMMENT '关联商品ID',
  `link_order_id` bigint unsigned DEFAULT NULL COMMENT '关联订单ID',
  `publish_time` datetime DEFAULT NULL COMMENT '发布时间',
  `end_time` datetime DEFAULT NULL COMMENT 'ç»“æŸå±•ç¤ºæ—¶é—´ï¼ˆå¯é€‰ï¼‰',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0-草稿 1-已发布 2-已撤回',
  `priority` tinyint unsigned NOT NULL DEFAULT '2' COMMENT '优先级：1-低 2-中 3-高',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`notification_id`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  KEY `idx_publish_time` (`publish_time`),
  KEY `idx_priority` (`priority`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统通知表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_notification`
--

LOCK TABLES `system_notification` WRITE;
/*!40000 ALTER TABLE `system_notification` DISABLE KEYS */;
INSERT INTO `system_notification` VALUES (1,'欢迎使用闲七校园交易平台','感谢您注册闲七，新用户注册送10积分！赶快发布你的第一个商品吧。3123',1,1,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8]',1,NULL,NULL,NULL,'2025-01-01 09:00:00',NULL,1,2,'2025-01-01 08:00:00','2026-03-09 15:16:44',0),(2,'周末特惠秒杀活动','限时秒杀火热进行中！精选好物低至8折，手慢无！',2,1,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8]',1,NULL,NULL,NULL,'2025-01-10 10:00:00',NULL,1,2,'2025-01-10 09:00:00','2026-03-04 16:54:33',0),(3,'账户安全提醒','为了保障您的账户安全，请定期修改密码。如发现异常登录，请及时联系客服。',3,1,NULL,NULL,'[2, 3, 4, 5, 6, 7, 8]',1,NULL,NULL,NULL,'2025-01-15 11:00:00',NULL,1,3,'2025-01-15 10:00:00','2026-03-04 16:54:33',0);
/*!40000 ALTER TABLE `system_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_notification_backup`
--

DROP TABLE IF EXISTS `system_notification_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_notification_backup` (
  `notification_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '通知ID',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '通知标题',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '通知内容，支持富文本',
  `type` tinyint unsigned NOT NULL COMMENT '通知类型：1-系统公告 2-活动通知 3-账户提醒 4-交易提醒',
  `target_type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '目标类型：1-全部用户 2-指定用户 3-指定等级',
  `target_users` json DEFAULT NULL COMMENT '指定用户ID列表，JSON数组',
  `target_level` int unsigned DEFAULT NULL COMMENT '目标用户等级',
  `is_read` json DEFAULT NULL COMMENT '已读用户ID列表，JSON数组',
  `link_type` tinyint unsigned DEFAULT NULL COMMENT '跳转链接类型：1-无 2-网页 3-商品详情 4-订单详情',
  `link_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '跳转URL',
  `link_product_id` bigint unsigned DEFAULT NULL COMMENT '关联商品ID',
  `link_order_id` bigint unsigned DEFAULT NULL COMMENT '关联订单ID',
  `publish_time` datetime DEFAULT NULL COMMENT '发布时间',
  `end_time` datetime DEFAULT NULL COMMENT 'ç»“æŸå±•ç¤ºæ—¶é—´ï¼ˆå¯é€‰ï¼‰',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0-草稿 1-已发布 2-已撤回',
  `priority` tinyint unsigned NOT NULL DEFAULT '2' COMMENT '优先级：1-低 2-中 3-高',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`notification_id`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  KEY `idx_publish_time` (`publish_time`),
  KEY `idx_priority` (`priority`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统通知表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_notification_backup`
--

LOCK TABLES `system_notification_backup` WRITE;
/*!40000 ALTER TABLE `system_notification_backup` DISABLE KEYS */;
INSERT INTO `system_notification_backup` VALUES (10,'æ¬¢è¿Žä½¿ç”¨é—²ä¸ƒæ ¡å›­äº¤æ˜“å¹³å°','æ„Ÿè°¢æ‚¨æ³¨å†Œé—²ä¸ƒï¼Œæ–°ç”¨æˆ·æ³¨å†Œé€10ç§¯åˆ†ï¼èµ¶å¿«å‘å¸ƒä½ çš„ç¬¬ä¸€ä¸ªå•†å“å§ã€‚',1,1,NULL,NULL,'[10, 11, 12, 13, 14, 15, 16, 17]',1,NULL,NULL,NULL,'2025-01-01 09:00:00',NULL,1,2,'2025-01-01 08:00:00','2026-02-24 11:36:13',0),(11,'é¦–æ¬¡äº¤æ˜“å…æ‰‹ç»­è´¹æ´»åŠ¨','å³æ—¥èµ·è‡³æœ¬æœˆåº•ï¼Œé¦–æ¬¡äº¤æ˜“å¯å…é™¤æ‰‹ç»­è´¹ï¼Œå¿«æ¥å‘å¸ƒå•†å“å§ï¼',2,1,NULL,NULL,'[10, 11, 12, 13, 14, 15, 16, 17]',1,NULL,NULL,NULL,'2025-01-10 10:00:00',NULL,1,2,'2025-01-10 09:00:00','2026-02-24 11:36:13',0),(12,'è´¦æˆ·å®‰å…¨æé†’','ä¸ºäº†ä¿éšœæ‚¨çš„è´¦æˆ·å®‰å…¨ï¼Œè¯·å®šæœŸä¿®æ”¹å¯†ç ã€‚å¦‚å‘çŽ°å¼‚å¸¸ç™»å½•ï¼Œè¯·åŠæ—¶è”ç³»å®¢æœã€‚',3,1,NULL,NULL,'[11, 12, 13, 14, 15, 16, 17]',1,NULL,NULL,NULL,'2025-01-15 11:00:00',NULL,1,3,'2025-01-15 10:00:00','2026-02-24 11:36:13',0);
/*!40000 ALTER TABLE `system_notification_backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transfer_record`
--

DROP TABLE IF EXISTS `transfer_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transfer_record` (
  `transfer_id` bigint NOT NULL AUTO_INCREMENT COMMENT 'è½¬èµ è®°å½•ID',
  `share_id` bigint NOT NULL COMMENT 'å…±äº«ç‰©å“ID',
  `from_user_id` bigint NOT NULL COMMENT 'è½¬å‡ºäººID',
  `to_user_id` bigint NOT NULL COMMENT 'æŽ¥æ”¶äººID',
  `transfer_note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è½¬èµ è¯´æ˜Ž',
  `accept_status` tinyint NOT NULL DEFAULT '0' COMMENT 'æŽ¥æ”¶äººç¡®è®¤çŠ¶æ€ï¼š0-å¾…ç¡®è®¤ï¼Œ1-å·²æŽ¥å—ï¼Œ2-å·²æ‹’ç»',
  `confirm_time` datetime DEFAULT NULL COMMENT 'ç¡®è®¤æ—¶é—´',
  `reject_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‹’ç»åŽŸå› ',
  `complete_time` datetime DEFAULT NULL COMMENT 'è½¬èµ å®Œæˆæ—¶é—´',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ ‡è®°ï¼š0-æœªåˆ é™¤ï¼Œ1-å·²åˆ é™¤',
  PRIMARY KEY (`transfer_id`),
  KEY `idx_share_id` (`share_id`),
  KEY `idx_from_user_id` (`from_user_id`),
  KEY `idx_to_user_id` (`to_user_id`),
  KEY `idx_accept_status` (`accept_status`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è½¬èµ è®°å½•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transfer_record`
--

LOCK TABLES `transfer_record` WRITE;
/*!40000 ALTER TABLE `transfer_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `transfer_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码（加密）',
  `pay_password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¯ä»˜å¯†ç ï¼ˆåŠ å¯†ï¼‰',
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `avatar` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '头像URL',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `student_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '学号',
  `real_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '真实姓名',
  `college` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '学院',
  `major` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '专业',
  `credit_score` int unsigned DEFAULT '100' COMMENT '信用分数',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0-正常 1-封禁',
  `is_verified` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否实名认证：0-否 1-是',
  `phone_search_enabled` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'å…è®¸æ‰‹æœºå·æœç´¢ï¼š0-å¦ 1-æ˜¯',
  `location_enabled` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'æ˜¾ç¤ºä½ç½®ä¿¡æ¯ï¼š0-å¦ 1-æ˜¯',
  `wechat_openid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '微信OpenID',
  `wechat_unionid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '微信UnionID',
  `qq_openid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'QQ OpenID',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `idx_username` (`username`),
  KEY `idx_phone` (`phone`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_credit_score` (`credit_score`),
  KEY `idx_pay_password` (`pay_password`(50)),
  KEY `idx_wechat_openid` (`wechat_openid`),
  KEY `idx_wechat_unionid` (`wechat_unionid`),
  KEY `idx_qq_openid` (`qq_openid`)
) ENGINE=InnoDB AUTO_INCREMENT=288626339412582001 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·è¡¨ï¼ˆåŒ…å«è´¦å·å®‰å…¨è®¾ç½®ï¼‰';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'zhangsan','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'张同学','/static/images/user.png','13800138001','2021001','张三','计算机学院','计算机科学与技术',95,0,0,1,1,NULL,NULL,NULL,NULL,'2025-01-01 10:00:00','2026-03-11 13:55:21',0),(2,'lisi','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'李同学','/static/images/user.png','13800138002','2021002','李四','软件学院','软件工程',88,0,0,1,1,NULL,NULL,NULL,NULL,'2025-01-02 11:00:00','2026-03-11 13:55:21',0),(3,'wangwu','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'王同学','/static/images/user.png','13800138003','2021003','王五','信息学院','信息安全',92,0,0,1,1,NULL,NULL,NULL,NULL,'2025-01-03 12:00:00','2026-03-11 13:55:21',0),(4,'zhaoliu','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'赵同学','/static/images/user.png','13800138004','2021004','赵六','经济学院','金融学',85,0,0,1,1,NULL,NULL,NULL,NULL,'2025-01-04 13:00:00','2026-03-11 13:55:21',0),(5,'sunqi','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'孙同学','/static/images/user.png','13800138005','2021005','孙七','文学院','汉语言文学',90,0,0,1,1,NULL,NULL,NULL,NULL,'2025-01-05 14:00:00','2026-03-11 13:55:21',0),(6,'zhouba','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'周同学','/static/images/user.png','13800138006','2021006','周八','理学院','数学与应用数学',87,0,0,1,1,NULL,NULL,NULL,NULL,'2025-01-06 15:00:00','2026-03-11 13:55:21',0),(7,'wujiu','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'吴同学','/static/images/user.png','13800138007','2021007','吴九','艺术学院','视觉传达设计',93,0,0,1,1,NULL,NULL,NULL,NULL,'2025-01-07 16:00:00','2026-03-11 13:55:21',0),(8,'test','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'测试用户','http://localhost:8080/api/image/c38ea6bd-55e4-47c8-9337-44fe7b270639.png','13800138000','2020000','测试用户','测试学院','测试专业',100,0,0,1,1,NULL,NULL,NULL,NULL,'2025-01-10 09:00:00','2026-03-11 13:55:21',0),(9,'test123','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'test123','http://localhost:8080/api/image/444bfd26-c81b-425f-833c-13df5b271bb2.png','13822223333','',NULL,'312',NULL,100,0,0,1,1,NULL,NULL,NULL,NULL,'2026-03-04 17:48:19','2026-03-11 13:55:21',0),(18,'xiaoming','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°æ˜ŽåŒå­¦','/static/images/user.png','13900001001','2021018','å°æ˜Ž','è®¡ç®—æœºå­¦é™¢','äººå·¥æ™ºèƒ½',96,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-15 09:00:00','2026-03-10 12:26:26',0),(19,'xiaohong','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°çº¢åŒå­¦','/static/images/user.png','13900001002','2021019','å°çº¢','è½¯ä»¶å­¦é™¢','è½¯ä»¶å·¥ç¨‹',94,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-16 10:00:00','2026-03-10 12:26:26',0),(20,'xiaogang','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°åˆšåŒå­¦','/static/images/user.png','13900001003','2021020','å°åˆš','ä¿¡æ¯å­¦é™¢','ç½‘ç»œå®‰å…¨',91,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-17 11:00:00','2026-03-10 12:26:26',0),(21,'xiaoli','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°ä¸½åŒå­¦','/static/images/user.png','13900001004','2021021','å°ä¸½','ç»æµŽå­¦é™¢','å›½é™…è´¸æ˜“',89,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-18 12:00:00','2026-03-10 12:26:26',0),(22,'xiaowei','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°ä¼ŸåŒå­¦','/static/images/user.png','13900001005','2021022','å°ä¼Ÿ','ç®¡ç†å­¦é™¢','å·¥å•†ç®¡ç†',93,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-19 13:00:00','2026-03-10 12:26:26',0),(23,'xiaojun','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°å†›åŒå­¦','/static/images/user.png','13900001006','2021023','å°å†›','æœºæ¢°å­¦é™¢','æœºæ¢°å·¥ç¨‹',88,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-20 14:00:00','2026-03-10 12:26:26',0),(24,'xiaoya','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°é›…åŒå­¦','/static/images/user.png','13900001007','2021024','å°é›…','æ–‡å­¦é™¢','æ–°é—»ä¼ æ’­',95,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-21 15:00:00','2026-03-10 12:26:26',0),(25,'xiaochen','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°é™ˆåŒå­¦','/static/images/user.png','13900001008','2021025','å°é™ˆ','æ³•å­¦é™¢','æ³•å­¦',90,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-22 16:00:00','2026-03-10 12:26:26',0),(26,'xiaolin','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°æž—åŒå­¦','/static/images/user.png','13900001009','2021026','å°æž—','å¤–å›½è¯­å­¦é™¢','è‹±è¯­',92,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-23 17:00:00','2026-03-10 12:26:26',0),(27,'xiaofang','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°èŠ³åŒå­¦','/static/images/user.png','13900001010','2021027','å°èŠ³','è‰ºæœ¯å­¦é™¢','çŽ¯å¢ƒè®¾è®¡',87,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-24 18:00:00','2026-03-10 12:26:26',0),(28,'xiaohua','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°èŠ±åŒå­¦','/static/images/user.png','13900001011','2021028','å°èŠ±','å»ºç­‘å­¦é™¢','å»ºç­‘å­¦',94,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-25 19:00:00','2026-03-10 12:26:26',0),(29,'xiaoqiang','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°å¼ºåŒå­¦','/static/images/user.png','13900001012','2021029','å°å¼º','åœŸæœ¨å­¦é™¢','åœŸæœ¨å·¥ç¨‹',86,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-26 20:00:00','2026-03-10 12:26:26',0),(30,'xiaomei','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°ç¾ŽåŒå­¦','/static/images/user.png','13900001013','2021030','å°ç¾Ž','åŒ–å­¦å­¦é™¢','åº”ç”¨åŒ–å­¦',91,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-27 21:00:00','2026-03-10 12:26:26',0),(31,'xiaoguang','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°å…‰åŒå­¦','/static/images/user.png','13900001014','2021031','å°å…‰','ç‰©ç†å­¦é™¢','ç‰©ç†å­¦',89,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-28 22:00:00','2026-03-10 12:26:26',0),(32,'xiaofei','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'å°é£žåŒå­¦','/static/images/user.png','13900001015','2021032','å°é£ž','æ•°å­¦å­¦é™¢','ç»Ÿè®¡å­¦',93,0,0,1,1,NULL,NULL,NULL,NULL,'2026-01-29 23:00:00','2026-03-10 12:26:26',0),(33,'313','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'313',NULL,'13123312332','',NULL,NULL,NULL,100,0,0,1,1,NULL,NULL,NULL,NULL,'2026-03-06 23:03:12','2026-03-10 12:26:26',0),(34,'asd','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'asd',NULL,'13822993399',NULL,NULL,NULL,NULL,100,0,0,1,1,NULL,NULL,NULL,NULL,'2026-03-06 23:04:33','2026-03-10 12:26:26',0),(288626339412582000,'7711','$2a$10$5JrdG.yrZY4xY6P10aSjl.8S8Dn.DAI6FaH/APRfBz5ecNgDcwyqm',NULL,'7711',NULL,'17777111177',NULL,NULL,NULL,NULL,100,0,0,1,1,NULL,NULL,NULL,NULL,'2026-03-07 18:58:02','2026-03-10 12:26:26',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_address`
--

DROP TABLE IF EXISTS `user_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_address` (
  `address_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'åœ°å€ID',
  `user_id` bigint unsigned NOT NULL COMMENT 'ç”¨æˆ·ID',
  `contact_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è”ç³»äººå§“å',
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è”ç³»ç”µè¯',
  `province` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çœä»½',
  `city` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'åŸŽå¸‚',
  `district` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'åŒº/åŽ¿',
  `detail_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è¯¦ç»†åœ°å€',
  `postal_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é‚®æ”¿ç¼–ç ',
  `tag` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ ‡ç­¾ï¼šå®¶/å…¬å¸/å­¦æ ¡',
  `is_default` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'æ˜¯å¦é»˜è®¤åœ°å€ï¼š0-å¦ 1-æ˜¯',
  `longitude` decimal(10,7) DEFAULT NULL COMMENT 'ç»åº¦',
  `latitude` decimal(10,7) DEFAULT NULL COMMENT 'çº¬åº¦',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-æ­£å¸¸ 1-å·²åˆ é™¤',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ ‡è®°ï¼š0-æ­£å¸¸ 1-å·²åˆ é™¤',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`address_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_user_default` (`user_id`,`is_default`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·åœ°å€è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_address`
--

LOCK TABLES `user_address` WRITE;
/*!40000 ALTER TABLE `user_address` DISABLE KEYS */;
INSERT INTO `user_address` VALUES (1,9,'1231','13822223333','广东省','深圳市','南山区','3123123',NULL,'公司',0,NULL,NULL,0,0,'2026-03-05 16:11:43','2026-03-05 16:11:43'),(2,9,'31','13832223333','广东省','深圳市','南山区','13123',NULL,'',0,NULL,NULL,0,0,'2026-03-05 16:37:26','2026-03-05 16:37:26'),(3,9,'123','13922232322','广东省','深圳市','南山区','23',NULL,'',0,NULL,NULL,0,0,'2026-03-05 16:41:57','2026-03-05 16:41:57'),(4,8,'asd','13822223333','广东省','深圳市','南山区','asd',NULL,'家',0,NULL,NULL,0,0,'2026-03-10 15:25:38','2026-03-10 15:42:51'),(5,8,'323','13922223333','广东省','深圳市','罗湖区','asd',NULL,NULL,1,NULL,NULL,0,0,'2026-03-10 15:42:47','2026-03-10 15:42:47');
/*!40000 ALTER TABLE `user_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_backup_20260302`
--

DROP TABLE IF EXISTS `user_backup_20260302`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_backup_20260302` (
  `user_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码（加密）',
  `pay_password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¯ä»˜å¯†ç ï¼ˆåŠ å¯†ï¼‰',
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `avatar` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '头像URL',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `student_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '学号',
  `real_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '真实姓名',
  `college` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '学院',
  `major` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '专业',
  `credit_score` int unsigned DEFAULT '100' COMMENT '信用分数',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0-正常 1-封禁',
  `is_verified` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否实名认证：0-否 1-是',
  `phone_search_enabled` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'å…è®¸æ‰‹æœºå·æœç´¢ï¼š0-å¦ 1-æ˜¯',
  `location_enabled` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'æ˜¾ç¤ºä½ç½®ä¿¡æ¯ï¼š0-å¦ 1-æ˜¯',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `idx_username` (`username`),
  KEY `idx_phone` (`phone`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_credit_score` (`credit_score`),
  KEY `idx_pay_password` (`pay_password`(50))
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·è¡¨ï¼ˆåŒ…å«è´¦å·å®‰å…¨è®¾ç½®ï¼‰';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_backup_20260302`
--

LOCK TABLES `user_backup_20260302` WRITE;
/*!40000 ALTER TABLE `user_backup_20260302` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_backup_20260302` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_coupon`
--

DROP TABLE IF EXISTS `user_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_coupon` (
  `user_coupon_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ç”¨æˆ·ä¼˜æƒ åˆ¸ID',
  `user_id` bigint unsigned NOT NULL COMMENT 'ç”¨æˆ·ID',
  `coupon_id` bigint unsigned NOT NULL COMMENT 'ä¼˜æƒ åˆ¸ID',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'ä¼˜æƒ åˆ¸çŠ¶æ€ï¼š1-æœªä½¿ç”¨ï¼Œ2-å·²ä½¿ç”¨ï¼Œ3-å·²è¿‡æœŸ',
  `used_time` datetime DEFAULT NULL COMMENT 'ä½¿ç”¨æ—¶é—´',
  `order_id` bigint unsigned DEFAULT NULL COMMENT 'å…³è”è®¢å•ID',
  `expire_time` datetime NOT NULL COMMENT 'è¿‡æœŸæ—¶é—´',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ ‡è®°ï¼š0-æ­£å¸¸ 1-å·²åˆ é™¤',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`user_coupon_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_coupon_id` (`coupon_id`),
  KEY `idx_status` (`status`),
  KEY `idx_expire_time` (`expire_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·ä¼˜æƒ åˆ¸è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_coupon`
--

LOCK TABLES `user_coupon` WRITE;
/*!40000 ALTER TABLE `user_coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_credit_ext`
--

DROP TABLE IF EXISTS `user_credit_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_credit_ext` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint unsigned NOT NULL COMMENT 'ç”¨æˆ·ID',
  `credit_level` varchar(20) DEFAULT 'normal' COMMENT 'ä¿¡ç”¨ç­‰çº§ï¼šexcellentä¼˜ç§€/goodè‰¯å¥½/normalä¸€èˆ¬/poorè¾ƒå·®',
  `last_active_time` timestamp NULL DEFAULT NULL COMMENT 'æœ€åŽæ´»è·ƒæ—¶é—´',
  `last_credit_decay_time` timestamp NULL DEFAULT NULL COMMENT 'ä¸Šæ¬¡ä¿¡ç”¨åˆ†è¡°å‡æ—¶é—´',
  `total_positive_evaluations` int DEFAULT '0' COMMENT 'å¥½è¯„æ€»æ•°',
  `total_neutral_evaluations` int DEFAULT '0' COMMENT 'ä¸­è¯„æ€»æ•°',
  `total_negative_evaluations` int DEFAULT '0' COMMENT 'å·®è¯„æ€»æ•°',
  `zhima_credit_score` int DEFAULT NULL COMMENT 'èŠéº»ä¿¡ç”¨åˆ†',
  `zhima_auth_time` timestamp NULL DEFAULT NULL COMMENT 'èŠéº»ä¿¡ç”¨æŽˆæƒæ—¶é—´',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_id` (`user_id`),
  KEY `idx_last_active_time` (`last_active_time`),
  KEY `idx_credit_level` (`credit_level`),
  CONSTRAINT `user_credit_ext_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='ç”¨æˆ·ä¿¡ç”¨åˆ†æ‰©å±•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_credit_ext`
--

LOCK TABLES `user_credit_ext` WRITE;
/*!40000 ALTER TABLE `user_credit_ext` DISABLE KEYS */;
INSERT INTO `user_credit_ext` VALUES (1,1,'excellent','2026-03-04 08:54:33',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(2,2,'good','2026-03-04 08:54:33',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(3,3,'excellent','2026-03-04 08:54:33',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(4,4,'good','2026-03-04 08:54:33',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(5,5,'excellent','2026-03-04 08:54:33',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(6,6,'good','2026-03-04 08:54:33',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(7,7,'excellent','2026-03-04 08:54:33',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(8,8,'excellent','2026-03-04 08:54:33',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(9,9,'excellent','2026-03-04 09:48:19',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(10,18,'excellent','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(11,19,'excellent','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(12,20,'excellent','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(13,21,'good','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(14,22,'excellent','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(15,23,'good','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(16,24,'excellent','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(17,25,'excellent','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(18,26,'excellent','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(19,27,'good','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(20,28,'excellent','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(21,29,'good','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(22,30,'excellent','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(23,31,'good','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(24,32,'excellent','2026-03-06 09:11:53',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(25,33,'excellent','2026-03-06 15:03:12',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(26,34,'excellent','2026-03-06 15:04:33',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57'),(27,288626339412582000,'excellent','2026-03-07 10:58:02',NULL,0,0,0,NULL,NULL,'2026-03-07 14:27:57','2026-03-07 14:27:57');
/*!40000 ALTER TABLE `user_credit_ext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_feedback`
--

DROP TABLE IF EXISTS `user_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_feedback` (
  `feedback_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '反馈ID',
  `user_id` bigint unsigned DEFAULT NULL COMMENT '用户ID（可为空，匿名反馈）',
  `contact` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系方式（手机/邮箱）',
  `type` tinyint unsigned NOT NULL COMMENT '反馈类型：1-功能建议 2-Bug反馈 3-投诉 4-其他',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '反馈内容',
  `images` json DEFAULT NULL COMMENT '图片列表，JSON数组',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '处理状态：0-待处理 1-处理中 2-已处理 3-已驳回',
  `handler_id` bigint unsigned DEFAULT NULL COMMENT '处理人ID（管理员）',
  `handle_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '处理备注',
  `handle_time` datetime DEFAULT NULL COMMENT '处理时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`feedback_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_feedback_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户反馈表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_feedback`
--

LOCK TABLES `user_feedback` WRITE;
/*!40000 ALTER TABLE `user_feedback` DISABLE KEYS */;
INSERT INTO `user_feedback` VALUES (1,9,'123@qq.com',2,'2313','23123','[\"http://localhost:8080/api/image/285e9790-2d3a-4674-8af4-c02482507975.png\"]',0,NULL,NULL,NULL,'2026-03-05 22:38:26','2026-03-05 22:38:26',0),(2,9,'13923223322',2,'1231','23123','[\"http://localhost:8080/api/image/9754aa6f-0255-4a93-833a-3fd7addabaa2.png\"]',2,NULL,'12','2026-03-09 17:34:05','2026-03-06 13:27:37','2026-03-06 13:27:37',0);
/*!40000 ALTER TABLE `user_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_follow`
--

DROP TABLE IF EXISTS `user_follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_follow` (
  `follow_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'å…³æ³¨ID',
  `follower_id` bigint unsigned NOT NULL COMMENT 'å…³æ³¨è€…IDï¼ˆä¸»åŠ¨å…³æ³¨çš„äººï¼‰',
  `following_id` bigint unsigned NOT NULL COMMENT 'è¢«å…³æ³¨è€…IDï¼ˆè¢«å…³æ³¨çš„äººï¼‰',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'å…³æ³¨æ—¶é—´',
  PRIMARY KEY (`follow_id`),
  UNIQUE KEY `idx_follower_following` (`follower_id`,`following_id`),
  KEY `idx_follower_id` (`follower_id`),
  KEY `idx_following_id` (`following_id`),
  CONSTRAINT `fk_follow_follower` FOREIGN KEY (`follower_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_follow_following` FOREIGN KEY (`following_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·å…³æ³¨è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_follow`
--

LOCK TABLES `user_follow` WRITE;
/*!40000 ALTER TABLE `user_follow` DISABLE KEYS */;
INSERT INTO `user_follow` VALUES (6,9,8,'2026-03-12 09:57:50');
/*!40000 ALTER TABLE `user_follow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_preference`
--

DROP TABLE IF EXISTS `user_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_preference` (
  `preference_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'åå¥½ID',
  `user_id` bigint unsigned NOT NULL COMMENT 'ç”¨æˆ·ID',
  `device_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'unknown' COMMENT 'è®¾å¤‡ç±»åž‹ï¼šios/android/web/miniprogram',
  `language` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'zh-CN' COMMENT 'è¯­è¨€',
  `notification_enabled` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'é€šçŸ¥æ€»å¼€å…³',
  `trade_notification_enabled` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'äº¤æ˜“é€šçŸ¥',
  `promo_notification_enabled` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'ä¿ƒé”€é€šçŸ¥',
  `system_notification_enabled` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'ç³»ç»Ÿé€šçŸ¥',
  `quiet_hours_start` time DEFAULT NULL COMMENT 'å…æ‰“æ‰°å¼€å§‹',
  `quiet_hours_end` time DEFAULT NULL COMMENT 'å…æ‰“æ‰°ç»“æŸ',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`preference_id`),
  UNIQUE KEY `idx_user_device` (`user_id`,`device_type`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·åå¥½è®¾ç½®è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_preference`
--

LOCK TABLES `user_preference` WRITE;
/*!40000 ALTER TABLE `user_preference` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_preference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_privacy`
--

DROP TABLE IF EXISTS `user_privacy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_privacy` (
  `privacy_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'éšç§ID',
  `user_id` bigint unsigned NOT NULL COMMENT 'ç”¨æˆ·ID',
  `phone_search_enabled` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'æ‰‹æœºå·æœç´¢ï¼š0-å¦ 1-æ˜¯',
  `student_id_search_enabled` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'å­¦å·æœç´¢ï¼š0-å¦ 1-æ˜¯',
  `show_real_name` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'çœŸå®žå§“åï¼š0-å¦ 1-æ˜¯',
  `show_student_id` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'å­¦å·ï¼š0-å¦ 1-æ˜¯',
  `show_college_major` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'å­¦é™¢ä¸“ä¸šï¼š0-å¦ 1-æ˜¯',
  `show_enrollment_year` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'å…¥å­¦å¹´ä»½ï¼š0-å¦ 1-æ˜¯',
  `show_product_location` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'å•†å“ä½ç½®ï¼š0-å¦ 1-æ˜¯',
  `show_trading_history` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'äº¤æ˜“åŽ†å²ï¼š0-å¦ 1-æ˜¯',
  `allow_stranger_message` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'é™Œç”Ÿäººç§ä¿¡ï¼š0-å¦ 1-æ˜¯',
  `online_status_visible` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'åœ¨çº¿çŠ¶æ€ï¼š0-å¦ 1-æ˜¯',
  `friend_list_visible` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'å¥½å‹åˆ—è¡¨ï¼š0-å¦ 1-æ˜¯',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`privacy_id`),
  UNIQUE KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·éšç§è®¾ç½®è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_privacy`
--

LOCK TABLES `user_privacy` WRITE;
/*!40000 ALTER TABLE `user_privacy` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_privacy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profile`
--

DROP TABLE IF EXISTS `user_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_profile` (
  `profile_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'èµ„æ–™ID',
  `user_id` bigint unsigned NOT NULL COMMENT 'ç”¨æˆ·ID',
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ˜µç§°',
  `avatar` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤´åƒURL',
  `gender` tinyint unsigned DEFAULT '0' COMMENT 'æ€§åˆ«ï¼š0-æœªçŸ¥ 1-ç”· 2-å¥³',
  `birthday` date DEFAULT NULL COMMENT 'ç”Ÿæ—¥',
  `bio` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¸ªäººç®€ä»‹',
  `real_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'çœŸå®žå§“å',
  `id_card` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'èº«ä»½è¯å·ï¼ˆåŠ å¯†ï¼‰',
  `id_card_verified` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'å®žåè®¤è¯ï¼š0-æœªè®¤è¯ 1-å·²è®¤è¯',
  `verified_at` datetime DEFAULT NULL COMMENT 'è®¤è¯æ—¶é—´',
  `student_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å­¦å·',
  `college` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å­¦é™¢',
  `major` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¸“ä¸š',
  `enrollment_year` year DEFAULT NULL COMMENT 'å…¥å­¦å¹´ä»½',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰‹æœºå·',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é‚®ç®±',
  `qq` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'QQå·',
  `wechat` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¾®ä¿¡å·',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`profile_id`),
  UNIQUE KEY `idx_user_id` (`user_id`),
  KEY `idx_phone` (`phone`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·èµ„æ–™è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profile`
--

LOCK TABLES `user_profile` WRITE;
/*!40000 ALTER TABLE `user_profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_real_name_auth`
--

DROP TABLE IF EXISTS `user_real_name_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_real_name_auth` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint unsigned NOT NULL COMMENT 'ç”¨æˆ·ID',
  `real_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çœŸå®žå§“å',
  `id_card` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'èº«ä»½è¯å·ï¼ˆåŠ å¯†ï¼‰',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'è®¤è¯çŠ¶æ€ï¼š0-æœªè®¤è¯ 1-å®¡æ ¸ä¸­ 2-å·²è®¤è¯ 3-è®¤è¯å¤±è´¥',
  `reject_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¤è¯å¤±è´¥åŽŸå› ',
  `audited_by` bigint unsigned DEFAULT NULL COMMENT 'å®¡æ ¸äººID',
  `audited_at` datetime DEFAULT NULL COMMENT 'å®¡æ ¸æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤ï¼š0-æœªåˆ é™¤ 1-å·²åˆ é™¤',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_audited_at` (`audited_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·å®žåè®¤è¯è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_real_name_auth`
--

LOCK TABLES `user_real_name_auth` WRITE;
/*!40000 ALTER TABLE `user_real_name_auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_real_name_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_security`
--

DROP TABLE IF EXISTS `user_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_security` (
  `security_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'å®‰å…¨ID',
  `user_id` bigint unsigned NOT NULL COMMENT 'ç”¨æˆ·ID',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ç™»å½•å¯†ç ï¼ˆåŠ å¯†ï¼‰',
  `password_salt` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¯†ç ç›å€¼',
  `password_changed_at` datetime DEFAULT NULL COMMENT 'å¯†ç ä¿®æ”¹æ—¶é—´',
  `password_need_change` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'éœ€ä¿®æ”¹å¯†ç ï¼š0-å¦ 1-æ˜¯',
  `pay_password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¯ä»˜å¯†ç ï¼ˆåŠ å¯†ï¼‰',
  `pay_password_salt` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¯ä»˜å¯†ç ç›å€¼',
  `pay_password_set` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'å·²è®¾ç½®æ”¯ä»˜å¯†ç ï¼š0-å¦ 1-æ˜¯',
  `last_login_at` datetime DEFAULT NULL COMMENT 'æœ€åŽç™»å½•æ—¶é—´',
  `last_login_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æœ€åŽç™»å½•IP',
  `login_count` int unsigned NOT NULL DEFAULT '0' COMMENT 'ç´¯è®¡ç™»å½•æ¬¡æ•°',
  `login_fail_count` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'ç™»å½•å¤±è´¥æ¬¡æ•°',
  `locked_until` datetime DEFAULT NULL COMMENT 'é”å®šåˆ°æœŸæ—¶é—´',
  `lock_reason` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”å®šåŽŸå› ',
  `two_factor_enabled` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'äºŒæ­¥éªŒè¯ï¼š0-å¦ 1-æ˜¯',
  `two_factor_secret` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'äºŒæ­¥éªŒè¯å¯†é’¥ï¼ˆåŠ å¯†ï¼‰',
  `two_factor_backup_codes` text COLLATE utf8mb4_unicode_ci COMMENT 'å¤‡ç”¨æ¢å¤ç ï¼ˆJSONåŠ å¯†ï¼‰',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`security_id`),
  UNIQUE KEY `idx_user_id` (`user_id`),
  KEY `idx_last_login_at` (`last_login_at`),
  KEY `idx_locked_until` (`locked_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·å®‰å…¨è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_security`
--

LOCK TABLES `user_security` WRITE;
/*!40000 ALTER TABLE `user_security` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_security` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_student_auth`
--

DROP TABLE IF EXISTS `user_student_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_student_auth` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint unsigned NOT NULL COMMENT 'ç”¨æˆ·ID',
  `student_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å­¦å·',
  `college` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å­¦é™¢',
  `major` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ä¸“ä¸š',
  `student_card_images` text COLLATE utf8mb4_unicode_ci COMMENT 'å­¦ç”Ÿè¯å›¾ç‰‡ï¼ˆJSONæ•°ç»„ï¼‰',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'è®¤è¯çŠ¶æ€ï¼š0-æœªè®¤è¯ 1-å®¡æ ¸ä¸­ 2-å·²è®¤è¯ 3-è®¤è¯å¤±è´¥',
  `reject_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¤è¯å¤±è´¥åŽŸå› ',
  `audited_by` bigint unsigned DEFAULT NULL COMMENT 'å®¡æ ¸äººID',
  `audited_at` datetime DEFAULT NULL COMMENT 'å®¡æ ¸æ—¶é—´',
  `enrollment_year` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å…¥å­¦å¹´ä»½',
  `graduation_year` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ¯•ä¸šå¹´ä»½',
  `education_level` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å­¦åŽ†å±‚æ¬¡ï¼šæœ¬ç§‘/ç¡•å£«/åšå£«',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤ï¼š0-æœªåˆ é™¤ 1-å·²åˆ é™¤',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_id` (`user_id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_status` (`status`),
  KEY `idx_college` (`college`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·å­¦ç”Ÿè®¤è¯è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_student_auth`
--

LOCK TABLES `user_student_auth` WRITE;
/*!40000 ALTER TABLE `user_student_auth` DISABLE KEYS */;
INSERT INTO `user_student_auth` VALUES (1,9,'2022035123005','asd','asd','[\"http://localhost:8080/api/image/3c2beaad-49a9-47d3-897c-86dbe1dc6094.png\",\"http://localhost:8080/api/image/a63a4748-3575-47ca-90d5-9033cc8e60d8.png\"]',2,NULL,1,'2026-03-09 13:36:50',NULL,NULL,NULL,'2026-03-06 21:43:25','2026-03-06 21:43:25',0);
/*!40000 ALTER TABLE `user_student_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_user_credit_info`
--

DROP TABLE IF EXISTS `v_user_credit_info`;
/*!50001 DROP VIEW IF EXISTS `v_user_credit_info`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user_credit_info` AS SELECT 
 1 AS `user_id`,
 1 AS `username`,
 1 AS `nickname`,
 1 AS `avatar`,
 1 AS `credit_score`,
 1 AS `credit_level`,
 1 AS `credit_level_text`,
 1 AS `last_active_time`,
 1 AS `total_positive_evaluations`,
 1 AS `total_neutral_evaluations`,
 1 AS `total_negative_evaluations`,
 1 AS `zhima_credit_score`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `worker_node`
--

DROP TABLE IF EXISTS `worker_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worker_node` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `host_name` varchar(64) NOT NULL COMMENT '主机名',
  `port` varchar(64) NOT NULL COMMENT '端口',
  `type` int NOT NULL COMMENT '节点类型: ACTUAL(1) CONTAINER(2)',
  `launch_date` date NOT NULL COMMENT '上线日期',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_host_port` (`host_name`,`port`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='DB WorkerID分配';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker_node`
--

LOCK TABLES `worker_node` WRITE;
/*!40000 ALTER TABLE `worker_node` DISABLE KEYS */;
/*!40000 ALTER TABLE `worker_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'XianQi'
--

--
-- Dumping routines for database 'XianQi'
--
/*!50003 DROP PROCEDURE IF EXISTS `update_user_last_active_ext` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_user_last_active_ext`(IN user_id_param BIGINT UNSIGNED)
BEGIN
  -- 确保 user_id 存在，然后更新
  INSERT INTO `user_credit_ext` (`user_id`, `last_active_time`, `updated_at`)
  VALUES (user_id_param, NOW(), NOW())
  ON DUPLICATE KEY UPDATE
    `last_active_time` = NOW(),
    `updated_at` = NOW();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `v_user_credit_info`
--

/*!50001 DROP VIEW IF EXISTS `v_user_credit_info`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_credit_info` AS select `u`.`user_id` AS `user_id`,`u`.`username` AS `username`,`u`.`nickname` AS `nickname`,`u`.`avatar` AS `avatar`,`u`.`credit_score` AS `credit_score`,coalesce(`ce`.`credit_level`,'normal') AS `credit_level`,(case when (`u`.`credit_score` >= 90) then '优秀' when (`u`.`credit_score` >= 80) then '良好' when (`u`.`credit_score` >= 70) then '一般' else '较差' end) AS `credit_level_text`,coalesce(`ce`.`last_active_time`,`u`.`update_time`) AS `last_active_time`,coalesce(`ce`.`total_positive_evaluations`,0) AS `total_positive_evaluations`,coalesce(`ce`.`total_neutral_evaluations`,0) AS `total_neutral_evaluations`,coalesce(`ce`.`total_negative_evaluations`,0) AS `total_negative_evaluations`,coalesce(`ce`.`zhima_credit_score`,0) AS `zhima_credit_score` from (`user` `u` left join `user_credit_ext` `ce` on((`u`.`user_id` = `ce`.`user_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-12 22:09:19
