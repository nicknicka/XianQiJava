@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

:: ============================================
:: XianQi 后端项目导入脚本（Windows 执行）
:: ============================================

echo ============================================
echo    XianQi 后端项目导入工具 (Windows)
echo ============================================
echo.

:: 配置变量
set DB_NAME=XianQi
set DB_USER=root
set DB_PASS=123456
set DB_HOST=localhost

:: 检查 MySQL
echo [1/5] 检查 MySQL...
where mysql >nul 2>&1
if %errorlevel% neq 0 (
    echo 错误: 未找到 mysql 命令
    echo 请确保 MySQL 已安装并添加到系统 PATH
    echo.
    echo 常见 MySQL 路径:
    echo   C:\Program Files\MySQL\MySQL Server 8.0\bin
    echo   C:\xampp\mysql\bin
    pause
    exit /b 1
)
echo ✓ MySQL 已找到

:: 检查 Redis
echo [2/5] 检查 Redis...
where redis-server >nul 2>&1
if %errorlevel% neq 0 (
    echo 警告: 未找到 redis-server 命令
    echo 请确保 Redis 已安装并添加到系统 PATH
    echo.
    echo 下载地址: https://github.com/tporadowski/redis/releases
    echo.
) else (
    echo ✓ Redis 已找到
)

:: 创建数据库
echo [3/5] 创建数据库...
mysql -h%DB_HOST% -u%DB_USER% -p%DB_PASS% -e "CREATE DATABASE IF NOT EXISTS %DB_NAME% CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>nul
if %errorlevel% neq 0 (
    echo 数据库密码可能不正确，请手动输入:
    set /p DB_PASS="请输入 MySQL root 密码: "
    mysql -h%DB_HOST% -u%DB_USER% -p%DB_PASS% -e "CREATE DATABASE IF NOT EXISTS %DB_NAME% CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
)
echo ✓ 数据库创建成功

:: 导入数据
echo [4/5] 导入数据库数据...
if exist "database\xianqi_database.sql" (
    mysql -h%DB_HOST% -u%DB_USER% -p%DB_PASS% %DB_NAME% < database\xianqi_database.sql
    if %errorlevel% neq 0 (
        echo 错误: 数据库导入失败
        pause
        exit /b 1
    )
    echo ✓ 数据库导入成功
) else (
    echo 错误: 未找到数据库文件 database\xianqi_database.sql
    pause
    exit /b 1
)

:: 复制上传文件
echo [5/5] 复制上传文件...
if exist "files\uploads" (
    if not exist "C:\uploads" mkdir "C:\uploads"
    xcopy /E /I /Y "files\uploads\*" "C:\uploads\"
    echo ✓ 上传文件复制成功
) else (
    echo ! 未找到上传文件目录，跳过
)

echo.
echo ============================================
echo    导入完成！
echo ============================================
echo.
echo 下一步操作:
echo 1. 进入 files\XianQiJava 目录
echo 2. 修改 application.yml 中的数据库密码（如果不同）
echo 3. 运行: mvnw.cmd spring-boot:run
echo.
echo 或者打包后运行:
echo    mvnw.cmd clean package
echo    java -jar target\XianQiJava-0.0.1-SNAPSHOT.jar
echo.
pause
