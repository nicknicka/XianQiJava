-- 校园位置表
CREATE TABLE IF NOT EXISTS `campus_location` (
  `location_id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '位置ID',
  `name` VARCHAR(50) NOT NULL COMMENT '位置名称',
  `code` VARCHAR(50) NOT NULL COMMENT '位置代码',
  `description` VARCHAR(200) DEFAULT NULL COMMENT '位置描述',
  `sort_order` INT DEFAULT 0 COMMENT '排序',
  `status` TINYINT DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT DEFAULT 0 COMMENT '逻辑删除标记（0=未删除，1=已删除）',
  PRIMARY KEY (`location_id`),
  UNIQUE KEY `uk_code` (`code`),
  KEY `idx_status` (`status`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='校园位置表';

-- 插入初始数据
INSERT INTO `campus_location` (`name`, `code`, `description`, `sort_order`, `status`) VALUES
('全校', 'all', '全校所有区域', 0, 1),
('南区', 'south', '校园南区', 1, 1),
('北区', 'north', '校园北区', 2, 1),
('东区', 'east', '校园东区', 3, 1),
('西区', 'west', '校园西区', 4, 1);
