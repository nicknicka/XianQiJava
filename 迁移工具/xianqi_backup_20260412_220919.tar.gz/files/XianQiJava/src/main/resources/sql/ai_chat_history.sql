-- AI 聊天历史表
-- 用于存储用户与 AI 助手的对话记录
-- 作者: Claude
-- 创建时间: 2026-03-23

CREATE TABLE IF NOT EXISTS `ai_chat_history` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `user_message` TEXT NOT NULL COMMENT '用户消息',
    `ai_response` TEXT NOT NULL COMMENT 'AI回复',
    `intent_type` VARCHAR(50) DEFAULT NULL COMMENT '意图类型：CUSTOMER_SERVICE-客服咨询, RECOMMENDATION-商品推荐, DESCRIPTION-描述优化, PRICING-定价建议, SAFETY-安全咨询, GREETING-问候语, GENERAL-一般咨询',
    `agent_type` VARCHAR(50) DEFAULT NULL COMMENT 'Agent类型：CustomerServiceAgent, ProductRecommendationAgent, ProductDescriptionAgent, PricingAdvisorAgent, TradeSafetyAgent',
    `session_id` VARCHAR(100) DEFAULT NULL COMMENT '会话ID（用于多轮对话）',
    `model_name` VARCHAR(50) DEFAULT NULL COMMENT '使用的模型名称',
    `tokens_used` INT DEFAULT 0 COMMENT '消耗的token数量',
    `response_time_ms` INT DEFAULT NULL COMMENT '响应时间（毫秒）',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`) COMMENT '用户ID索引',
    KEY `idx_created_at` (`created_at`) COMMENT '创建时间索引',
    KEY `idx_session_id` (`session_id`) COMMENT '会话ID索引',
    KEY `idx_intent_type` (`intent_type`) COMMENT '意图类型索引',
    KEY `idx_user_created` (`user_id`, `created_at`) COMMENT '用户+时间复合索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='AI聊天历史表';

-- 插入测试数据（可选）
-- INSERT INTO `ai_chat_history` (`user_id`, `user_message`, `ai_response`, `intent_type`, `agent_type`, `session_id`, `model_name`)
-- VALUES
-- (1, '推荐一些手机', '根据您的偏好，为您推荐以下手机...', 'RECOMMENDATION', 'ProductRecommendationAgent', 'session_001', 'glm-4-flash');
