-- 为 conversation 表添加 last_message_type 字段
-- 用于存储最后一条消息的类型，方便前端显示友好的提示

ALTER TABLE `conversation`
ADD COLUMN `last_message_type` INT DEFAULT NULL COMMENT '最后一条消息类型：1-文本，2-图片，3-商品卡片，4-订单卡片，5-系统通知，6-引用消息'
AFTER `last_message_time`;

-- 为已有的会话设置默认消息类型（根据历史数据推断）
-- 如果最后消息内容是 "[图片]"，则设置为 2
UPDATE `conversation`
SET `last_message_type` = 2
WHERE `last_message_content` = '[图片]' AND `last_message_content` IS NOT NULL;

-- 其他情况默认设置为 1（文本消息）
UPDATE `conversation`
SET `last_message_type` = 1
WHERE `last_message_type` IS NULL AND `last_message_content` IS NOT NULL;
