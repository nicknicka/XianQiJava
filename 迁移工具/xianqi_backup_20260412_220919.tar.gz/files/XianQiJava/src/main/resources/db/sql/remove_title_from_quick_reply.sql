-- 移除快捷回复表的title字段
-- 执行日期: 2026-03-05
-- 说明: 将title字段从quick_reply表中完全移除

USE Xianqi;

-- 1. 备份当前表结构和数据（可选，建议执行）
-- CREATE TABLE quick_reply_backup AS SELECT * FROM quick_reply;

-- 2. 删除title字段
ALTER TABLE quick_reply DROP COLUMN title;

-- 验证修改
DESC quick_reply;

-- 说明：
-- 执行此脚本后，quick_reply表将不再包含title字段
-- 实体类、VO、DTO和Service层代码也相应更新
