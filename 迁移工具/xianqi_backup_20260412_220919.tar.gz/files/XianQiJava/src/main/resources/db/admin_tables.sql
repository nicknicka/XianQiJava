-- ============================================
-- 管理员后台系统数据库表
-- 版本: v1.0
-- 创建时间: 2026-03-07
-- ============================================

-- ============================================
-- 1. 管理员表
-- ============================================
-- 先删除已存在的表（开发环境）
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` BIGINT NOT NULL COMMENT '管理员ID',
  `username` VARCHAR(50) NOT NULL COMMENT '用户名',
  `password` VARCHAR(100) NOT NULL COMMENT '密码(BCrypt加密)',
  `nickname` VARCHAR(50) COMMENT '昵称',
  `avatar` VARCHAR(255) COMMENT '头像',
  `is_active` TINYINT DEFAULT 1 COMMENT '是否启用 0-禁用 1-启用',
  `last_login_time` DATETIME COMMENT '最后登录时间',
  `last_login_ip` VARCHAR(50) COMMENT '最后登录IP',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员表';

-- ============================================
-- 2. 操作日志表
-- ============================================
CREATE TABLE IF NOT EXISTS `operation_log` (
  `id` BIGINT NOT NULL COMMENT '日志ID',
  `admin_id` BIGINT NOT NULL COMMENT '管理员ID',
  `admin_name` VARCHAR(50) NOT NULL COMMENT '管理员用户名',
  `module` VARCHAR(50) NOT NULL COMMENT '操作模块',
  `operation` VARCHAR(50) NOT NULL COMMENT '操作类型',
  `description` VARCHAR(500) NOT NULL COMMENT '操作描述',
  `method` VARCHAR(200) COMMENT '执行方法',
  `params` TEXT COMMENT '请求参数',
  `ip` VARCHAR(50) COMMENT 'IP地址',
  `location` VARCHAR(100) COMMENT 'IP归属地',
  `browser` VARCHAR(100) COMMENT '浏览器',
  `os` VARCHAR(100) COMMENT '操作系统',
  `status` TINYINT DEFAULT 1 COMMENT '状态 0-失败 1-成功',
  `error_msg` VARCHAR(500) COMMENT '错误信息',
  `duration` BIGINT COMMENT '执行耗时(毫秒)',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_module` (`module`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志表';

-- ============================================
-- 3. 登录日志表
-- ============================================
CREATE TABLE IF NOT EXISTS `admin_login_log` (
  `id` BIGINT NOT NULL COMMENT '日志ID',
  `admin_id` BIGINT COMMENT '管理员ID',
  `username` VARCHAR(50) NOT NULL COMMENT '用户名',
  `login_time` DATETIME NOT NULL COMMENT '登录时间',
  `ip` VARCHAR(50) COMMENT 'IP地址',
  `location` VARCHAR(100) COMMENT 'IP归属地',
  `browser` VARCHAR(100) COMMENT '浏览器',
  `os` VARCHAR(100) COMMENT '操作系统',
  `status` TINYINT DEFAULT 1 COMMENT '登录状态 0-失败 1-成功',
  `message` VARCHAR(255) COMMENT '提示信息',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_status` (`status`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员登录日志表';

-- ============================================
-- 4. 数据导出记录表
-- ============================================
CREATE TABLE IF NOT EXISTS `export_log` (
  `id` BIGINT NOT NULL COMMENT '导出ID',
  `admin_id` BIGINT NOT NULL COMMENT '管理员ID',
  `admin_name` VARCHAR(50) NOT NULL COMMENT '管理员用户名',
  `report_type` VARCHAR(50) NOT NULL COMMENT '报表类型: user/order/product',
  `file_name` VARCHAR(255) NOT NULL COMMENT '文件名',
  `file_path` VARCHAR(500) NOT NULL COMMENT '文件路径',
  `row_count` INT NOT NULL COMMENT '数据行数',
  `file_size` BIGINT NOT NULL COMMENT '文件大小(字节)',
  `start_time` DATETIME NOT NULL COMMENT '开始时间',
  `end_time` DATETIME NOT NULL COMMENT '结束时间',
  `duration` BIGINT COMMENT '导出耗时(毫秒)',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_report_type` (`report_type`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据导出记录表';

-- ============================================
-- 5. 热门标签表
-- ============================================
CREATE TABLE IF NOT EXISTS `hot_tag` (
  `id` BIGINT NOT NULL COMMENT '标签ID',
  `keyword` VARCHAR(50) NOT NULL COMMENT '搜索关键词',
  `click_count` INT DEFAULT 0 COMMENT '点击次数',
  `sort_order` INT DEFAULT 0 COMMENT '排序值（越小越靠前）',
  `is_active` TINYINT DEFAULT 1 COMMENT '是否启用：0-禁用 1-启用',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='热门搜索标签表';

-- ============================================
-- 6. 系统异常日志表
-- ============================================
CREATE TABLE IF NOT EXISTS `error_log` (
  `id` BIGINT NOT NULL COMMENT '异常ID',
  `level` VARCHAR(10) NOT NULL COMMENT '异常级别：ERROR/WARN/INFO',
  `message` TEXT NOT NULL COMMENT '异常信息',
  `exception_type` VARCHAR(100) COMMENT '异常类型',
  `stack_trace` TEXT COMMENT '堆栈跟踪',
  `request_url` VARCHAR(500) COMMENT '请求URL',
  `request_method` VARCHAR(10) COMMENT '请求方法',
  `request_params` TEXT COMMENT '请求参数',
  `user_id` BIGINT COMMENT '操作用户ID',
  `user_type` TINYINT COMMENT '用户类型：1-普通用户 2-管理员',
  `ip` VARCHAR(50) COMMENT 'IP地址',
  `occur_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '发生时间',
  PRIMARY KEY (`id`),
  KEY `idx_level` (`level`),
  KEY `idx_occur_time` (`occur_time`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统异常日志表';

-- ============================================
-- 7. 管理员在线会话表
-- ============================================
CREATE TABLE IF NOT EXISTS `admin_session` (
  `id` BIGINT NOT NULL COMMENT '会话ID',
  `admin_id` BIGINT NOT NULL COMMENT '管理员ID',
  `token` VARCHAR(500) NOT NULL COMMENT 'JWT Token',
  `ip` VARCHAR(50) COMMENT 'IP地址',
  `user_agent` VARCHAR(500) COMMENT 'User-Agent',
  `login_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '登录时间',
  `last_active_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后活跃时间',
  `status` TINYINT DEFAULT 1 COMMENT '状态：0-已退出 1-在线',
  PRIMARY KEY (`id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_token` (`token`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员在线会话表';

-- ============================================
-- 8. 数据统计缓存表
-- ============================================
CREATE TABLE IF NOT EXISTS `statistics_cache` (
  `id` BIGINT NOT NULL COMMENT '缓存ID',
  `cache_key` VARCHAR(100) NOT NULL COMMENT '缓存键',
  `cache_data` JSON NOT NULL COMMENT '缓存数据',
  `expire_time` DATETIME NOT NULL COMMENT '过期时间',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cache_key` (`cache_key`),
  KEY `idx_expire_time` (`expire_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据统计缓存表';

-- ============================================
-- 初始化数据
-- ============================================

-- 插入默认管理员账号 (忽略重复)
-- 密码: 123456 (BCrypt加密)
INSERT IGNORE INTO `admin` (`id`, `username`, `password`, `nickname`, `is_active`)
VALUES (1, 'admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5E', '超级管理员', 1);

-- 插入默认热门标签 (忽略重复)
INSERT IGNORE INTO `hot_tag` (`id`, `keyword`, `sort_order`, `is_active`) VALUES
(1, 'iPhone', 1, 1),
(2, 'iPad', 2, 1),
(3, 'MacBook', 3, 1),
(4, '自行车', 4, 1),
(5, '教材', 5, 1);

-- ============================================
-- 创建索引优化查询性能
-- ============================================

-- 注意：复合索引已在表创建时定义，无需额外添加
