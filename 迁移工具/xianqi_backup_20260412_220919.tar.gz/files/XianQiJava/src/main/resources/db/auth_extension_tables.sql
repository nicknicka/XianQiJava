-- ========================================
-- 用户认证表分离迁移脚本（扩展表方案）
-- 只创建认证表，不修改user表
-- ========================================

-- 1. 创建实名认证表
CREATE TABLE IF NOT EXISTS `user_real_name_auth` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
  `real_name` VARCHAR(50) NOT NULL COMMENT '真实姓名',
  `id_card` VARCHAR(100) NOT NULL COMMENT '身份证号（加密）',
  `status` TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '认证状态：0-未认证 1-审核中 2-已认证 3-认证失败',
  `reject_reason` VARCHAR(500) DEFAULT NULL COMMENT '认证失败原因',
  `audited_by` BIGINT UNSIGNED DEFAULT NULL COMMENT '审核人ID',
  `audited_at` DATETIME DEFAULT NULL COMMENT '审核时间',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_audited_at` (`audited_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户实名认证表';

-- 2. 创建学生认证表
CREATE TABLE IF NOT EXISTS `user_student_auth` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
  `student_id` VARCHAR(50) NOT NULL COMMENT '学号',
  `college` VARCHAR(100) NOT NULL COMMENT '学院',
  `major` VARCHAR(100) NOT NULL COMMENT '专业',
  `student_card_images` TEXT DEFAULT NULL COMMENT '学生证图片（JSON数组）',
  `status` TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '认证状态：0-未认证 1-审核中 2-已认证 3-认证失败',
  `reject_reason` VARCHAR(500) DEFAULT NULL COMMENT '认证失败原因',
  `audited_by` BIGINT UNSIGNED DEFAULT NULL COMMENT '审核人ID',
  `audited_at` DATETIME DEFAULT NULL COMMENT '审核时间',
  `enrollment_year` VARCHAR(10) DEFAULT NULL COMMENT '入学年份',
  `graduation_year` VARCHAR(10) DEFAULT NULL COMMENT '毕业年份',
  `education_level` VARCHAR(20) DEFAULT NULL COMMENT '学历层次：本科/硕士/博士',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_id` (`user_id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_status` (`status`),
  KEY `idx_college` (`college`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户学生认证表';

-- ========================================
-- 说明：
--
-- 本脚本只创建认证相关的扩展表，不修改user表。
--
-- 认证状态说明：
-- status 字段值：
--   0 - 未认证
--   1 - 审核中
--   2 - 已认证
--   3 - 认证失败
--
-- User表保持原有结构不变，通过 LEFT JOIN 关联查询获取认证状态。
--
-- 使用方式：
-- 1. 获取用户认证状态时，关联查询 user_real_name_auth 和 user_student_auth 表
-- 2. 不需要在 user 表中存储冗余的认证状态字段
-- 3. 认证状态完全从认证表中获取
--
-- ========================================
