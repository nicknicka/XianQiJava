-- 为 order 表添加订单流程时间字段
-- 用于支持订单自动关闭、自动完成等定时任务

ALTER TABLE `order`
ADD COLUMN `pay_time` DATETIME DEFAULT NULL COMMENT '支付时间'
AFTER `remark`,
ADD COLUMN `ship_time` DATETIME DEFAULT NULL COMMENT '发货时间'
AFTER `pay_time`,
ADD COLUMN `deliver_time` DATETIME DEFAULT NULL COMMENT '送达时间'
AFTER `ship_time`,
ADD COLUMN `finish_time` DATETIME DEFAULT NULL COMMENT '完成时间'
AFTER `deliver_time`,
ADD COLUMN `cancel_reason` VARCHAR(255) DEFAULT NULL COMMENT '取消原因'
AFTER `finish_time`;

-- 为时间字段添加索引以优化查询性能
CREATE INDEX `idx_order_pay_time` ON `order`(`pay_time`);
CREATE INDEX `idx_order_ship_time` ON `order`(`ship_time`);
CREATE INDEX `idx_order_deliver_time` ON `order`(`deliver_time`);
