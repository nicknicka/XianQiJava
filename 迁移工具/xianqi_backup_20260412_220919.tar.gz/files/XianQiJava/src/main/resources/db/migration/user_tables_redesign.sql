-- User 相关表结构重新设计迁移脚本
-- 执行前请先备份数据库！
-- 创建时间：2026-03-12

-- ===================================================================
-- 第一步：创建新的表结构
-- ===================================================================

-- 1. 创建新的 user 表
CREATE TABLE `user_new` (
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `username` VARCHAR(50) NULL COMMENT '用户名',
  `password` VARCHAR(255) NOT NULL COMMENT '登录密码（BCrypt加密）',
  `pay_password` VARCHAR(255) NULL COMMENT '支付密码（BCrypt加密）',
  `nickname` VARCHAR(50) NOT NULL COMMENT '昵称',
  `avatar` VARCHAR(500) NULL COMMENT '头像URL',
  `phone` VARCHAR(20) NOT NULL COMMENT '手机号',
  `phone_verified` TINYINT NOT NULL DEFAULT 0 COMMENT '手机号是否已验证：0-否，1-是',

  -- 第三方登录
  `wechat_openid` VARCHAR(100) NULL COMMENT '微信OpenID',
  `wechat_unionid` VARCHAR(100) NULL COMMENT '微信UnionID',
  `qq_openid` VARCHAR(100) NULL COMMENT 'QQ OpenID',

  -- 用户状态
  `status` TINYINT NOT NULL DEFAULT 0 COMMENT '账号状态：0-正常，1-封禁，2-冻结',
  `status_reason` VARCHAR(255) NULL COMMENT '状态原因（封禁/冻结说明）',

  -- 隐私设置
  `phone_search_enabled` TINYINT NOT NULL DEFAULT 0 COMMENT '允许手机号搜索：0-否，1-是',
  `location_enabled` TINYINT NOT NULL DEFAULT 1 COMMENT '显示位置信息：0-否，1-是',

  -- 系统字段
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-正常，1-已删除',

  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uk_username` (`username`),
  UNIQUE KEY `uk_phone` (`phone`),
  KEY `idx_wechat_openid` (`wechat_openid`),
  KEY `idx_wechat_unionid` (`wechat_unionid`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 2. 创建 user_profile 表
CREATE TABLE `user_profile` (
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `real_name` VARCHAR(50) NULL COMMENT '真实姓名（用于展示，非认证信息）',
  `gender` TINYINT NULL COMMENT '性别：0-未知，1-男，2-女',
  `birthday` DATE NULL COMMENT '生日',
  `bio` VARCHAR(200) NULL COMMENT '个人简介',
  `location` VARCHAR(100) NULL COMMENT '位置展示（如：北京市海淀区）',
  `homepage` VARCHAR(200) NULL COMMENT '个人主页',
  `tags` VARCHAR(500) NULL COMMENT '个人标签（JSON数组）',

  -- 统计数据
  `followers_count` INT NOT NULL DEFAULT 0 COMMENT '粉丝数',
  `following_count` INT NOT NULL DEFAULT 0 COMMENT '关注数',
  `products_count` INT NOT NULL DEFAULT 0 COMMENT '发布商品数',
  `favorites_count` INT NOT NULL DEFAULT 0 COMMENT '收藏数',

  -- 系统字段
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

  PRIMARY KEY (`user_id`),
  KEY `idx_location` (`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户资料扩展表';

-- 3. 重建 user_realname_auth 表
DROP TABLE IF EXISTS `user_real_name_auth_new`;
CREATE TABLE `user_real_name_auth_new` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `real_name` VARCHAR(50) NOT NULL COMMENT '真实姓名',
  `id_card` VARCHAR(100) NOT NULL COMMENT '身份证号（AES加密）',
  `id_card_front` VARCHAR(500) NULL COMMENT '身份证正面图片',
  `id_card_back` VARCHAR(500) NULL COMMENT '身份证背面图片',

  -- 认证状态
  `status` TINYINT NOT NULL DEFAULT 0 COMMENT '认证状态：0-未认证，1-审核中，2-已认证，3-认证失败',
  `reject_reason` VARCHAR(255) NULL COMMENT '认证失败原因',

  -- 审核信息
  `audited_by` BIGINT NULL COMMENT '审核人ID',
  `audited_at` DATETIME NULL COMMENT '审核时间',

  -- 第三方认证
  `auth_provider` VARCHAR(50) NULL COMMENT '认证提供商：alipay/wechat/manual',
  `auth_transaction_id` VARCHAR(100) NULL COMMENT '第三方认证流水号',

  -- 系统字段
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '提交时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-正常，1-已删除',

  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户实名认证表';

-- 4. 重建 user_student_auth 表
DROP TABLE IF EXISTS `user_student_auth_new`;
CREATE TABLE `user_student_auth_new` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `student_id` VARCHAR(50) NOT NULL COMMENT '学号',
  `college` VARCHAR(100) NOT NULL COMMENT '学院',
  `major` VARCHAR(100) NOT NULL COMMENT '专业',
  `enrollment_year` CHAR(4) NULL COMMENT '入学年份',
  `graduation_year` CHAR(4) NULL COMMENT '毕业年份',
  `education_level` TINYINT NULL COMMENT '学历层次：1-专科，2-本科，3-硕士，4-博士',

  -- 认证材料
  `student_card_images` JSON NULL COMMENT '学生证图片（JSON数组）',
  `enrollment_certificate` VARCHAR(500) NULL COMMENT '录取通知书/学信网截图',

  -- 认证状态
  `status` TINYINT NOT NULL DEFAULT 0 COMMENT '认证状态：0-未认证，1-审核中，2-已认证，3-认证失败',
  `reject_reason` VARCHAR(255) NULL COMMENT '认证失败原因',

  -- 审核信息
  `audited_by` BIGINT NULL COMMENT '审核人ID',
  `audited_at` DATETIME NULL COMMENT '审核时间',

  -- 系统字段
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '提交时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-正常，1-已删除',

  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_id` (`user_id`),
  UNIQUE KEY `uk_student_id` (`student_id`),
  KEY `idx_college_major` (`college`, `major`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户学生认证表';

-- 5. 重建 user_credit_ext 表
DROP TABLE IF EXISTS `user_credit_ext_new`;
CREATE TABLE `user_credit_ext_new` (
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `credit_score` INT NOT NULL DEFAULT 100 COMMENT '信用分数（默认100分）',
  `credit_level` VARCHAR(20) NOT NULL DEFAULT 'C' COMMENT '信用等级：S/A/B/C/D',

  -- 评价统计
  `total_positive` INT NOT NULL DEFAULT 0 COMMENT '好评数',
  `total_neutral` INT NOT NULL DEFAULT 0 COMMENT '中评数',
  `total_negative` INT NOT NULL DEFAULT 0 COMMENT '差评数',
  `total_evaluations` INT NOT NULL DEFAULT 0 COMMENT '总评价数',

  -- 交易统计
  `total_orders` INT NOT NULL DEFAULT 0 COMMENT '总订单数',
  `completed_orders` INT NOT NULL DEFAULT 0 COMMENT '已完成订单数',
  `cancelled_orders` INT NOT NULL DEFAULT 0 COMMENT '已取消订单数',
  `dispute_orders` INT NOT NULL DEFAULT 0 COMMENT '纠纷订单数',

  -- 信用分变动
  `last_credit_change` DATETIME NULL COMMENT '最后信用分变动时间',
  `last_credit_decay` DATETIME NULL COMMENT '上次信用分衰减时间',

  -- 第三方信用
  `zhima_credit_score` INT NULL COMMENT '芝麻信用分',
  `zhima_auth_time` DATETIME NULL COMMENT '芝麻信用授权时间',

  -- 系统字段
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

  PRIMARY KEY (`user_id`),
  KEY `idx_credit_score` (`credit_score`),
  KEY `idx_credit_level` (`credit_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户信用扩展表';

-- 6. 重建 login_device 表
DROP TABLE IF EXISTS `login_device_new`;
CREATE TABLE `login_device_new` (
  `device_id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '设备ID',
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `device_name` VARCHAR(100) NULL COMMENT '设备名称（如：iPhone 13）',
  `device_type` VARCHAR(20) NOT NULL COMMENT '设备类型：ios/android/web/miniapp',
  `platform` VARCHAR(50) NULL COMMENT '平台标识（如：iOS 15.0）',
  `device_identifier` VARCHAR(100) NOT NULL COMMENT '设备唯一标识',

  -- 登录信息
  `login_ip` VARCHAR(50) NOT NULL COMMENT '登录IP',
  `login_location` VARCHAR(100) NULL COMMENT '登录地点',
  `last_login_time` DATETIME NOT NULL COMMENT '最后登录时间',

  -- 设备状态
  `is_current` TINYINT NOT NULL DEFAULT 0 COMMENT '是否为当前设备：0-否，1-是',

  -- 系统字段
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '首次登录时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-正常，1-已移除',

  PRIMARY KEY (`device_id`),
  UNIQUE KEY `uk_user_device` (`user_id`, `device_identifier`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_last_login` (`last_login_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='登录设备表';

-- 7. 重建 user_preference 表
DROP TABLE IF EXISTS `user_preference_new`;
CREATE TABLE `user_preference_new` (
  `user_id` BIGINT NOT NULL COMMENT '用户ID',

  -- 外观设置
  `theme` VARCHAR(20) NOT NULL DEFAULT 'auto' COMMENT '主题：light-浅色，dark-深色，auto-跟随系统',
  `font_size` INT NOT NULL DEFAULT 16 COMMENT '字体大小（px）',

  -- 通知设置
  `notification_enabled` TINYINT NOT NULL DEFAULT 1 COMMENT '是否启用通知：0-关闭，1-开启',
  `sound_enabled` TINYINT NOT NULL DEFAULT 1 COMMENT '是否启用提示音：0-关闭，1-开启',
  `vibration_enabled` TINYINT NOT NULL DEFAULT 1 COMMENT '是否启用振动：0-关闭，1-开启',

  -- 隐私设置
  `show_online_status` TINYINT NOT NULL DEFAULT 1 COMMENT '显示在线状态：0-否，1-是',
  `allow_stranger_message` TINYINT NOT NULL DEFAULT 1 COMMENT '允许陌生人私信：0-否，1-是',

  -- 其他设置
  `extra_settings` JSON NULL COMMENT '其他扩展设置',

  -- 系统字段
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户偏好设置表';

-- 8. 重建 user_address 表
DROP TABLE IF EXISTS `user_address_new`;
CREATE TABLE `user_address_new` (
  `address_id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '地址ID',
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `contact_name` VARCHAR(50) NOT NULL COMMENT '联系人姓名',
  `contact_phone` VARCHAR(20) NOT NULL COMMENT '联系电话',
  `province` VARCHAR(50) NOT NULL COMMENT '省份',
  `city` VARCHAR(50) NOT NULL COMMENT '城市',
  `district` VARCHAR(50) NOT NULL COMMENT '区/县',
  `detail_address` VARCHAR(200) NOT NULL COMMENT '详细地址',
  `postal_code` VARCHAR(10) NULL COMMENT '邮政编码',

  -- 标签和默认
  `tag` VARCHAR(20) NULL COMMENT '标签：家/公司/学校',
  `is_default` TINYINT NOT NULL DEFAULT 0 COMMENT '是否默认地址：0-否，1-是',

  -- 地理坐标
  `longitude` DECIMAL(10, 7) NULL COMMENT '经度',
  `latitude` DECIMAL(10, 7) NULL COMMENT '纬度',

  -- 系统字段
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-正常，1-已删除',

  PRIMARY KEY (`address_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_is_default` (`is_default`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户地址表';

-- 9. 重建 user_follow 表
DROP TABLE IF EXISTS `user_follow_new`;
CREATE TABLE `user_follow_new` (
  `follow_id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '关注ID',
  `follower_id` BIGINT NOT NULL COMMENT '关注者ID（主动关注的人）',
  `following_id` BIGINT NOT NULL COMMENT '被关注者ID（被关注的人）',

  -- 系统字段
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '关注时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-正常，1-已取消关注',

  PRIMARY KEY (`follow_id`),
  UNIQUE KEY `uk_follow` (`follower_id`, `following_id`, `deleted`),
  KEY `idx_following_id` (`following_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户关注表';

-- 10. 重建 blacklist 表
DROP TABLE IF EXISTS `blacklist_new`;
CREATE TABLE `blacklist_new` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` BIGINT NOT NULL COMMENT '用户ID（拉黑者）',
  `blocked_user_id` BIGINT NOT NULL COMMENT '被拉黑的用户ID',
  `reason` VARCHAR(255) NULL COMMENT '拉黑原因',

  -- 系统字段
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '拉黑时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-正常，1-已解除拉黑',

  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_blocked` (`user_id`, `blocked_user_id`, `deleted`),
  KEY `idx_blocked_user_id` (`blocked_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户黑名单表';


-- ===================================================================
-- 第二步：迁移数据
-- ===================================================================

-- 1. 迁移 user 表数据
INSERT INTO `user_new` (
  user_id, username, password, pay_password, nickname, avatar, phone,
  wechat_openid, wechat_unionid, qq_openid,
  status, phone_search_enabled, location_enabled,
  created_at, updated_at, deleted
)
SELECT
  user_id, username, password, pay_password, nickname, avatar, phone,
  wechat_openid, wechat_unionid, qq_openid,
  status, phone_search_enabled, location_enabled,
  createTime, updateTime, deleted
FROM `user`
WHERE deleted = 0;

-- 2. 初始化 user_profile 数据
INSERT INTO `user_profile` (
  user_id, real_name, followers_count, following_count,
  products_count, favorites_count, created_at, updated_at
)
SELECT
  user_id, realName, 0, 0, 0, 0, createTime, NOW()
FROM `user`
WHERE deleted = 0;

-- 3. 迁移 user_realname_auth 数据
INSERT INTO `user_real_name_auth_new` (
  user_id, real_name, id_card, status, reject_reason,
  audited_by, audited_at, created_at, updated_at, deleted
)
SELECT
  user_id, realName, idCard,
  CASE
    WHEN status = 0 THEN 0  -- 未认证
    WHEN status = 1 THEN 1  -- 审核中
    WHEN status = 2 THEN 2  -- 已认证
    ELSE 3  -- 认证失败
  END,
  rejectReason, auditedBy, auditedAt,
  createTime, updateTime, 0
FROM `user_real_name_auth`
WHERE deleted = 0;

-- 4. 迁移 user_student_auth 数据
INSERT INTO `user_student_auth_new` (
  user_id, student_id, college, major, enrollment_year, graduation_year,
  education_level, student_card_images, status, reject_reason,
  audited_by, audited_at, created_at, updated_at, deleted
)
SELECT
  user_id, studentId, college, major, enrollmentYear, graduationYear,
  CASE educationLevel
    WHEN '专科' THEN 1
    WHEN '本科' THEN 2
    WHEN '硕士' THEN 3
    WHEN '博士' THEN 4
    ELSE NULL
  END,
  studentCardImages,
  CASE
    WHEN status = 0 THEN 0
    WHEN status = 1 THEN 1
    WHEN status = 2 THEN 2
    ELSE 3
  END,
  rejectReason, auditedBy, auditedAt,
  createTime, updateTime, 0
FROM `user_student_auth`
WHERE deleted = 0;

-- 5. 迁移 user_credit_ext 数据
INSERT INTO `user_credit_ext_new` (
  user_id, credit_score, credit_level,
  total_positive, total_neutral, total_negative, total_evaluations,
  zhima_credit_score, zhima_auth_time, created_at, updated_at
)
SELECT
  user_id, creditScore, creditLevel,
  totalPositiveEvaluations, totalNeutralEvaluations, totalNegativeEvaluations,
  totalPositiveEvaluations + totalNeutralEvaluations + totalNegativeEvaluations,
  zhimaCreditScore, zhimaAuthTime, createdAt, updatedAt
FROM `user_credit_ext`;

-- 6. 迁移 login_device 数据
INSERT INTO `login_device_new` (
  user_id, device_name, device_type, platform, device_identifier,
  login_ip, last_login_time, is_current,
  created_at, updated_at, deleted
)
SELECT
  user_id, deviceName, deviceType, platform, deviceIdentifier,
  lastLoginIp, lastLoginTime, isCurrent,
  createTime, updateTime,
  CASE WHEN status = 1 THEN 1 ELSE 0 END
FROM `login_device`
WHERE deleted = 0;

-- 7. 迁移 user_preference 数据
INSERT INTO `user_preference_new` (
  user_id, theme, font_size,
  notification_enabled, sound_enabled, vibration_enabled,
  show_online_status, allow_stranger_message, created_at, updated_at
)
SELECT
  user_id,
  CASE
    WHEN autoDarkMode = 1 THEN 'auto'
    ELSE theme
  END,
  fontSize,
  notificationEnabled, soundEnabled, vibrationEnabled,
  1, 1, createTime, updateTime
FROM `user_preference`;

-- 8. 迁移 user_address 数据
INSERT INTO `user_address_new` (
  user_id, contact_name, contact_phone, province, city, district,
  detail_address, postal_code, tag, is_default,
  longitude, latitude, created_at, updated_at, deleted
)
SELECT
  user_id, contactName, contactPhone, province, city, district,
  detailAddress, postalCode, tag, isDefault,
  longitude, latitude, createTime, updateTime,
  CASE WHEN status = 1 THEN 1 ELSE 0 END
FROM `user_address`
WHERE deleted = 0;

-- 9. 迁移 user_follow 数据
INSERT INTO `user_follow_new` (
  follower_id, following_id, created_at, updated_at, deleted
)
SELECT
  followerId, followingId, createTime, NOW(), 0
FROM `user_follow`;

-- 10. 迁移 blacklist 数据
INSERT INTO `blacklist_new` (
  user_id, blocked_user_id, reason, created_at, updated_at, deleted
)
SELECT
  userId, blockedUserId, reason, createTime, NOW(), 0
FROM `blacklist`
WHERE deleted = 0;


-- ===================================================================
-- 第三步：切换表名（谨慎执行！）
-- ===================================================================

-- 备份旧表
RENAME TABLE `user` TO `user_backup_20260312`;
RENAME TABLE `user_real_name_auth` TO `user_real_name_auth_backup_20260312`;
RENAME TABLE `user_student_auth` TO `user_student_auth_backup_20260312`;
RENAME TABLE `user_credit_ext` TO `user_credit_ext_backup_20260312`;
RENAME TABLE `login_device` TO `login_device_backup_20260312`;
RENAME TABLE `user_preference` TO `user_preference_backup_20260312`;
RENAME TABLE `user_address` TO `user_address_backup_20260312`;
RENAME TABLE `user_follow` TO `user_follow_backup_20260312`;
RENAME TABLE `blacklist` TO `blacklist_backup_20260312`;

-- 启用新表
RENAME TABLE `user_new` TO `user`;
RENAME TABLE `user_real_name_auth_new` TO `user_real_name_auth`;
RENAME TABLE `user_student_auth_new` TO `user_student_auth`;
RENAME TABLE `user_credit_ext_new` TO `user_credit_ext`;
RENAME TABLE `login_device_new` TO `login_device`;
RENAME TABLE `user_preference_new` TO `user_preference`;
RENAME TABLE `user_address_new` TO `user_address`;
RENAME TABLE `user_follow_new` TO `user_follow`;
RENAME TABLE `blacklist_new` TO `blacklist`;


-- ===================================================================
-- 第四步：数据验证（执行后检查）
-- ===================================================================

-- 检查用户数量是否一致
SELECT 'user' AS table_name, COUNT(*) AS count FROM `user`
UNION ALL
SELECT 'user_backup', COUNT(*) FROM `user_backup_20260312`;

-- 检查认证数据
SELECT 'user_real_name_auth' AS table_name, COUNT(*) AS count FROM `user_real_name_auth`
UNION ALL
SELECT 'user_student_auth', COUNT(*) FROM `user_student_auth`;

-- 检查关联数据
SELECT 'login_device' AS table_name, COUNT(*) AS count FROM `login_device`
UNION ALL
SELECT 'user_preference', COUNT(*) FROM `user_preference`
UNION ALL
SELECT 'user_address', COUNT(*) FROM `user_address`
UNION ALL
SELECT 'user_follow', COUNT(*) FROM `user_follow`
UNION ALL
SELECT 'blacklist', COUNT(*) FROM `blacklist`;


-- ===================================================================
-- 回滚脚本（如果需要回滚，请执行以下语句）
-- ===================================================================

/*
-- 删除新表
DROP TABLE IF EXISTS `user`;
DROP TABLE IF EXISTS `user_real_name_auth`;
DROP TABLE IF EXISTS `user_student_auth`;
DROP TABLE IF EXISTS `user_credit_ext`;
DROP TABLE IF EXISTS `login_device`;
DROP TABLE IF EXISTS `user_preference`;
DROP TABLE IF EXISTS `user_address`;
DROP TABLE IF EXISTS `user_follow`;
DROP TABLE IF EXISTS `blacklist`;
DROP TABLE IF EXISTS `user_profile`;

-- 恢复旧表
RENAME TABLE `user_backup_20260312` TO `user`;
RENAME TABLE `user_real_name_auth_backup_20260312` TO `user_real_name_auth`;
RENAME TABLE `user_student_auth_backup_20260312` TO `user_student_auth`;
RENAME TABLE `user_credit_ext_backup_20260312` TO `user_credit_ext`;
RENAME TABLE `login_device_backup_20260312` TO `login_device`;
RENAME TABLE `user_preference_backup_20260312` TO `user_preference`;
RENAME TABLE `user_address_backup_20260312` TO `user_address`;
RENAME TABLE `user_follow_backup_20260312` TO `user_follow`;
RENAME TABLE `blacklist_backup_20260312` TO `blacklist`;
*/
