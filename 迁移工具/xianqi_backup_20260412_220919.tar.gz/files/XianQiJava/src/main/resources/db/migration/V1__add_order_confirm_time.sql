-- 添加订单确认时间字段
-- 用于记录买家确认收货的时间
-- Author: Claude
-- Date: 2026-03-31

ALTER TABLE `order` ADD COLUMN `confirm_time` DATETIME COMMENT '确认收货时间' AFTER `finish_time`;

-- 添加索引（用于定时任务查询和统计分析）
CREATE INDEX idx_confirm_time ON `order`(confirm_time);

-- 为已有的已完成订单填充确认时间（如果有完成时间，则使用完成时间作为确认时间）
UPDATE `order`
SET `confirm_time` = `finish_time`
WHERE `status` = 2 AND `finish_time` IS NOT NULL AND `confirm_time` IS NULL;
