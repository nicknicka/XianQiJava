-- ====================================
-- 系统配置初始化数据脚本
-- 说明：用于初始化系统配置表的默认数据
-- 作者：校园二手交易平台
-- 日期：2026-03-09
-- ====================================

-- 清空现有数据（可选，谨慎使用）
-- TRUNCATE TABLE system_config;

-- ====================================
-- 基础配置 (basic)
-- ====================================
INSERT INTO system_config (config_key, config_value, config_type, group_name, is_public, is_system, description, sort_order) VALUES
('appName', '校园二手交易平台', 'string', 'basic', 1, 1, '应用名称', 1),
('appVersion', '1.0.0', 'string', 'basic', 1, 1, '应用版本号', 2),
('icp', '京ICP备XXXXXXXX号', 'string', 'basic', 1, 1, 'ICP备案号', 3),
('companyName', '校园二手交易平台', 'string', 'basic', 1, 1, '公司名称', 4),
('contactEmail', 'admin@xianqi.com', 'string', 'basic', 1, 1, '联系邮箱', 5),
('contactPhone', '400-000-0000', 'string', 'basic', 1, 1, '联系电话', 6);

-- ====================================
-- 上传配置 (upload)
-- ====================================
INSERT INTO system_config (config_key, config_value, config_type, group_name, is_public, is_system, description, sort_order) VALUES
('maxUploadSize', '5', 'number', 'upload', 1, 1, '最大文件大小（MB）', 1),
('allowedTypes', 'jpg,png,gif,webp', 'string', 'upload', 1, 1, '允许的文件类型（图片）', 2),
('maxFileCount', '9', 'number', 'upload', 1, 1, '单次最大上传文件数', 3),
('avatarMaxSize', '2', 'number', 'upload', 1, 1, '头像最大大小（MB）', 4),
('documentMaxSize', '10', 'number', 'upload', 1, 1, '文档最大大小（MB）', 5);

-- ====================================
-- 支付配置 (payment)
-- ====================================
INSERT INTO system_config (config_key, config_value, config_type, group_name, is_public, is_system, description, sort_order) VALUES
('alipayEnabled', 'false', 'boolean', 'payment', 0, 1, '是否启用支付宝支付', 1),
('alipayAppId', '', 'string', 'payment', 0, 1, '支付宝应用ID', 2),
('wechatPayEnabled', 'false', 'boolean', 'payment', 0, 1, '是否启用微信支付', 3),
('wechatPayAppId', '', 'string', 'payment', 0, 1, '微信支付应用ID', 4),
('paymentTimeout', '30', 'number', 'payment', 0, 1, '支付超时时间（分钟）', 5);

-- ====================================
-- 邮件配置 (email)
-- ====================================
INSERT INTO system_config (config_key, config_value, config_type, group_name, is_public, is_system, description, sort_order) VALUES
('emailEnabled', 'false', 'boolean', 'email', 0, 1, '是否启用邮件服务', 1),
('emailHost', 'smtp.qq.com', 'string', 'email', 0, 1, 'SMTP服务器地址', 2),
('emailPort', '587', 'number', 'email', 0, 1, 'SMTP端口', 3),
('emailUsername', '', 'string', 'email', 0, 1, '发件人邮箱', 4),
('emailPassword', '', 'string', 'email', 0, 1, '邮箱密码或授权码', 5),
('emailFromName', '校园二手交易平台', 'string', 'email', 0, 1, '发件人名称', 6);

-- ====================================
-- 短信配置 (sms)
-- ====================================
INSERT INTO system_config (config_key, config_value, config_type, group_name, is_public, is_system, description, sort_order) VALUES
('smsEnabled', 'false', 'boolean', 'sms', 0, 1, '是否启用短信服务', 1),
('smsProvider', 'aliyun', 'string', 'sms', 0, 1, '短信服务商（aliyun/tencent）', 2),
('smsAccessKeyId', '', 'string', 'sms', 0, 1, '短信服务AccessKey ID', 3),
('smsAccessKeySecret', '', 'string', 'sms', 0, 1, '短信服务AccessKey Secret', 4),
('smsSignName', '校园二手交易平台', 'string', 'sms', 0, 1, '短信签名', 5),
('smsTemplateCode', 'SMS_XXXXXXXX', 'string', 'sms', 0, 1, '短信模板代码', 6);

-- ====================================
-- 安全配置 (security)
-- ====================================
INSERT INTO system_config (config_key, config_value, config_type, group_name, is_public, is_system, description, sort_order) VALUES
('passwordMinLength', '6', 'number', 'security', 0, 1, '密码最小长度', 1),
('passwordMaxLength', '20', 'number', 'security', 0, 1, '密码最大长度', 2),
('tokenExpiration', '24', 'number', 'security', 0, 1, 'Token过期时间（小时）', 3),
('refreshTokenExpiration', '168', 'number', 'security', 0, 1, '刷新Token过期时间（小时）', 4),
('maxLoginAttempts', '5', 'number', 'security', 0, 1, '最大登录尝试次数', 5),
('loginLockTime', '30', 'number', 'security', 0, 1, '登录锁定时间（分钟）', 6);

-- ====================================
-- 业务配置 (business)
-- ====================================
INSERT INTO system_config (config_key, config_value, config_type, group_name, is_public, is_system, description, sort_order) VALUES
('productMaxImages', '9', 'number', 'business', 1, 1, '商品最大图片数', 1),
('orderTimeout', '30', 'number', 'business', 0, 1, '订单超时时间（分钟）', 2),
('shareMaxDays', '30', 'number', 'business', 0, 1, '共享物品最大借用天数', 3),
('autoConfirmDays', '7', 'number', 'business', 0, 1, '自动确认收货天数', 4),
('commentTimeout', '7', 'number', 'business', 0, 1, '评价超时时间（天）', 5),
('refundDays', '7', 'number', 'business', 0, 1, '退款申请期限（天）', 6);

-- ====================================
-- 内容审核 (content)
-- ====================================
INSERT INTO system_config (config_key, config_value, config_type, group_name, is_public, is_system, description, sort_order) VALUES
('contentAuditEnabled', 'false', 'boolean', 'content', 0, 1, '是否启用内容审核', 1),
('sensitiveWordFilterEnabled', 'true', 'boolean', 'content', 0, 1, '是否启用敏感词过滤', 2),
('imageAuditEnabled', 'false', 'boolean', 'content', 0, 1, '是否启用图片审核', 3),
('autoAuditProduct', 'true', 'boolean', 'content', 0, 1, '是否自动审核商品', 4),
('autoAuditComment', 'true', 'boolean', 'content', 0, 1, '是否自动审核评论', 5);

-- ====================================
-- 其他配置 (other)
-- ====================================
INSERT INTO system_config (config_key, config_value, config_type, group_name, is_public, is_system, description, sort_order) VALUES
('siteClosed', 'false', 'boolean', 'other', 1, 1, '站点是否关闭', 1),
('closeReason', '系统维护中，请稍后访问', 'string', 'other', 1, 1, '站点关闭原因', 2),
('registerEnabled', 'true', 'boolean', 'other', 1, 1, '是否允许注册', 3),
('realNameAuthRequired', 'true', 'boolean', 'other', 1, 1, '是否需要实名认证', 4),
('studentIdAuthRequired', 'true', 'boolean', 'other', 1, 1, '是否需要学号认证', 5);

-- ====================================
-- 查看初始化结果
-- ====================================
SELECT
    group_name AS '配置分组',
    COUNT(*) AS '配置数量',
    GROUP_CONCAT(config_key ORDER BY sort_order SEPARATOR ', ') AS '配置项'
FROM system_config
GROUP BY group_name
ORDER BY group_name;

-- 查看所有配置
SELECT
    config_id AS 'ID',
    config_key AS '配置键',
    config_value AS '配置值',
    config_type AS '类型',
    group_name AS '分组',
    is_public AS '公开',
    is_system AS '系统',
    sort_order AS '排序',
    description AS '说明'
FROM system_config
ORDER BY group_name, sort_order;
