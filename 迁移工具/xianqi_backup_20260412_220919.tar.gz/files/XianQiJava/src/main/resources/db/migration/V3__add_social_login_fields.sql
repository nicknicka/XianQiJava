-- 添加社交登录字段到用户表
ALTER TABLE `user`
ADD COLUMN `wechat_openid` VARCHAR(100) NULL COMMENT '微信OpenID' AFTER `location_enabled`,
ADD COLUMN `wechat_unionid` VARCHAR(100) NULL COMMENT '微信UnionID' AFTER `wechat_openid`,
ADD COLUMN `qq_openid` VARCHAR(100) NULL COMMENT 'QQ OpenID' AFTER `wechat_unionid`;

-- 添加索引以提高查询性能
ALTER TABLE `user`
ADD INDEX `idx_wechat_openid` (`wechat_openid`),
ADD INDEX `idx_wechat_unionid` (`wechat_unionid`),
ADD INDEX `idx_qq_openid` (`qq_openid`);
